﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CtsWebCoreOutward.ViewModel
{
    public class GLAUserManagerViewModel
    {
        public class UserInfo
        {
            [Key]
            public Int16 UserInfoID { get; set; }
            public string UserName { get; set; }
            public string UserPWD { get; set; }
            public string PhBRNo { get; set; }
            public Nullable<Int32> GroupID { get; set; }
            public string LoginName { get; set; }
            public string MobileNo { get; set; }

            public string UserGroupName { get; set; }
        }
        public class UserGroup
        {
            [Key]
            public Int32 UserGroupID { get; set; }
            public string UserGroupName { get; set; }
            public string UserGroupDescription { get; set; }
        }

        

        public class AddUserInfo
        {
            public Int16 UserInfoID { get; set; }
            public IList<UserInfo> UserInfoList { get; set; }
            public Nullable<int> iFuntionNo { get; set; }
            public IList<UserGroup> GroupList { get; set; }

            [Display(Name = "User Name")]
            public string UserName { get; set; }

            [Display(Name = "User Password")]
            public string UserPWD { get; set; }

            [Display(Name = "PhBRNo")]
            public string PhBRNo { get; set; }

            [Display(Name = "User Group")]
            public Nullable<Int32> UserGroupID { get; set; }
            public string UserGroupName { get; set; }

            [Display(Name = "Login Name")]
            public string LoginName { get; set; }

            [Display(Name = "Group Name")]
            public string GroupName { get; set; }

            [Display(Name = "Mobile No.")]
            public string MobileNo { get; set; }

            //Constructor
            public AddUserInfo()
            {
                //Create Objects
            }
        }

        public class TransactionCodeMaster
        {
            [Key]
            public string stNo { get; set; }
        }
    }
}