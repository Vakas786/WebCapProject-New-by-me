﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class DataEntryViewModel
    {
        public class CheckDetails
        {
            public string stBatchNo { get; set; }
            [Key]
            public Int32 stSequenceNo { get; set; }
            public string stChequeNo { get; set; }
            public string stSortCode { get; set; }
            public string stBaseNo { get; set; }
            public string stTC { get; set; }
            public string stUKD { get; set; }
        }

        public class DataEntry
        {
            public DataEntry()
            {
                stChequeNo = "000000";
                stCityNo = "000";
                stBankNo = "000";
                stBranchNo = "000";
                stBaseNo = "000000";
                stTCNo = "00";
            }
            [Key]
            public string stChequeNo { get; set; }
            public string stCityNo { get; set; }
            public string stBankNo { get; set; }
            public string stBranchNo { get; set; }
            public string stBaseNo { get; set; }
            public string stTCNo { get; set; }
        }

        public class BatchGridColumns
        {
            [Key]
            public string stFieldName { get; set; }
            public string stWidth { get; set; }
            public string stDisplayCaption { get; set; }
        }

        public class ModuleFields
        {
            public Int32 FunctionNumber { get; set; }
            [Key]
            public string FieldName { get; set; }
            public string Caption { get; set; }
            public Int32 Pos { get; set; }
            public Int32 Length { get; set; }
            public Int32 MinLength { get; set; }
            public Int32 Width { get; set; }
            public string FieldDesc { get; set; }
            public string Mask { get; set; }
            public string OnKeyPress { get; set; }
            public string Onkeyup { get; set; }
            public string isDropDownField { get; set; }
            public string DropDownViewName { get; set; }
            public Int32 RectypeID { get; set; }
            public Int32 isReadOnly { get; set; }

        }

        public class ReturnReasonMaster
        {
            [Key]
            public string ReturnCode { get; set; }
            public string ReturnReason { get; set; }
        }

        public class BatchGridColumnsString
        {
            [Key]
            public string GridDisplayColumns { get; set; }
        }

        public class WrapperDataEntry
        {
            //public string sCall_Controller { get; set; }
            public string sCall_Action { get; set; }
            public string sController { get; set; }

            public List<ModuleFields> loModuleFieldsList { get; set; }
            public string stReturnCodeValue { get; set; }
            public string stRecordTypeValue { get; set; }
            public BatchDetails loBatchDetails { get; set; }

            //public List<SelectListItem> loRecordTypeList { get; set; }

            public IList<RecordTypeFromDB> loRecordTypeList { get; set; }

            public DataEntry loDataEntry { get; set; }

            public Nullable<int> iFuntionNo { get; set; }
            public List<BatchGridColumns> loBatchGridColumnsList { get; set; }
            public IList<ReturnReasonMaster> loReturnReasonList { get; set; }
            // public List<CheckDetails> loCheckDetailsList { get; set; }
            public IEnumerable<dynamic> loCheckDetailsList { get; set; }
            public List<string> loCityMasterList { get; set; }
            public List<string> loBankMasterList { get; set; }
            public List<string> loBranchMasterList { get; set; }
            public List<string> loTransactionCodeMasterList { get; set; }
            public List<string> loTempList { get; set; }
            public List<string> loRejectReasonList { get; set; }
            public List<RecordTypeValidationDetails> loRecordTypeValidationDetailList { get; set; }
        }

        public class BatchDetails
        {
            public string stBlockNo { get; set; }
            public string stBatchNo { get; set; }
            public string stSorterNo { get; set; }
            [Key]
            public Int32 stInstrumentMainID { get; set; }
        }

        public class RecordTypeFromDB
        {
            [Key]
            public int inRecType { get; set; }
            public string stName { get; set; }
            public string stAmountField { get; set; }
            public int inRecTypeID { get; set; }
        }

        public class CityMaster
        {
            [Key]
            public string stCityNo { get; set; }
        }

        public class BankMaster
        {
            [Key]
            public string stBankNo { get; set; }
        }

        public class BranchMaster
        {
            [Key]
            public string stBranchNo { get; set; }
        }

        public class TransactionCodeMaster
        {
            [Key]
            public string stTCNo { get; set; }
        }

        public class ChequeImage
        {
            [Key]
            public byte[] stImage { get; set; }
            // public byte[] stGrImage { get; set; }
        }

        public class AllChequeImage
        {
            [Key]
            public byte[] BFImage { get; set; }
            public byte[] BRImage { get; set; }
            public byte[] GFImage { get; set; }
        }

        public class NextBatchDetails
        {
            [Key]
            public string stBatchNo { get; set; }
            public Int32 tInstrumentMainID { get; set; }
        }

        public class RecordTypeValidationDetails
        {
            public Int32 inRecTypeDtlID { get; set; }
            public Int32 inRecTypeID { get; set; }
            [Key]
            public string stFieldName { get; set; }
            public string stCaption { get; set; }
            public bool FlgIsActive { get; set; }
            public Int32 inFieldLength { get; set; }
            public Int32 inDisplaySeqNo { get; set; }
            public string stValidateScheme { get; set; }
            public string stOnKeyPress { get; set; }
        }

        public class BatchCurrentStatus
        {
            //[NotMapped]
            public Int16 inLockStatus { get; set; }
            [Key]
            public string stBatchNo { get; set; }
        }

        public class DocSearchCriteria
        {
            public int Pos { get; set; }
            public int Length { get; set; }
            [Key]
            public string FieldName { get; set; }
            public string Caption { get; set; }
            public string FieldDescription { get; set; }
            public string Mask { get; set; }
            public string OnKeyPress { get; set; }
            public Nullable<int> IsDropdownField { get; set; }
            public string DropDownViewName { get; set; }
            public Nullable<int> RangeRequired { get; set; }
            public Nullable<int> isdateField { get; set; }
        }

        /* Batch Selection */
        public class BatchSelection
        {
            [Key]
            public string BatchNo { get; set; }
            public string SorterNo { get; set; }
            public Int32 BlockNo { get; set; }
            public string CD { get; set; }
            public string LastUser { get; set; }
            public string LockStatus { get; set; }
        }

        public class BatchSelectionGridColumns
        {
            [Key]
            public string stFieldName { get; set; }
            public string stWidth { get; set; }
            public string stDisplayCaption { get; set; }
        }

        public class BatchSelectionGridColumnsString
        {
            [Key]
            public string BatchGridDisplayColumns { get; set; }
        }

        public class WrapperBatchSelection
        {
            public Nullable<int> iFuntionNumber { get; set; }
            public List<BatchSelectionGridColumns> loBatchSelectionGridColumnsList { get; set; }
            //public string sCall_Controller { get; set; }
            public string sCall_Action { get; set; }
            [Key]
            public string sController { get; set; }
            public IEnumerable<dynamic> loBatchSelectionList { get; set; }
        }
        public class FuntionSP
        {
            [Key]
            public string SPName { get; set; }
            public string ModuleName { get; set; }
        }
        public class VerifierUpdate
        {
            [Key]
            public string stChequeNo { get; set; }
        }
        public class AccountDetails
        {
            
            public string stAccNo { get; set; }
            [Key]
            public string stAccName { get; set; }
            
        }

    }

    public class PermissionMaster
    {
        [Key]
        public string Controller { get; set; }
        public Int32 FunctionNumber { get; set; }
        // public string Call_Controller { get; set; }
        public string Call_action { get; set; }

    }
}