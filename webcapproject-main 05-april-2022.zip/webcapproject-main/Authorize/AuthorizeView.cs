﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.ViewModel;
using CtsWebCoreOutward.Models;

namespace CtsWebCoreOutward.Authorize
{
    public static class AuthorizeView
    {
        //public static bool UserInRole(string stController)
        //{
        //    try
        //    {
        //        #region Check for if logged in user has access to view

        //        Int16 inUserInfoID = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).inUserInfoID;
        //        int inGroupID = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).inGroupID;

        //        List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();

        //        string stPermissionMasterCacheKey = inUserInfoID.ToString() + "PermissionMaster";
        //        object loPermissionMasterCache = HttpContext.Current.Cache[stPermissionMasterCacheKey];
        //        if (loPermissionMasterCache == null)
        //        {
        //            GenericDataContext loGenericDataContext = new GenericDataContext();
        //            loPermissionMasterList = new List<PermissionMaster>();

        //            loPermissionMasterList = loGenericDataContext.getUserPermissionByGroupID(inGroupID);
        //            HttpContext.Current.Cache.Insert(stPermissionMasterCacheKey, loPermissionMasterList, null, DateTime.Now.AddMinutes(240), System.Web.Caching.Cache.NoSlidingExpiration);
        //        }
        //        else
        //        {
        //            loPermissionMasterList = (List<PermissionMaster>)HttpContext.Current.Cache[stPermissionMasterCacheKey];
        //        }

        //        bool flgIsPermission = false;
        //        if (loPermissionMasterList.Where(x => x.Controller.ToLower() == stController.ToLower()).Any())
        //        {
        //            flgIsPermission = true;
        //        }
        //        else
        //        {
        //            flgIsPermission = false;
        //        }

        //        return flgIsPermission;

        //        #endregion
        //    }
        //    catch {

        //        return false;
        //    }
         
        //}

        //public static string getModuleName(string stController)
        //{
        //    try
        //    {
        //        #region Check for if logged in user has access to view

        //        Int16 inUserInfoID = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).inUserInfoID;
        //        int inGroupID = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).inGroupID;

        //        List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();

        //        string stPermissionMasterCacheKey = inUserInfoID.ToString() + "PermissionMaster";
        //        object loPermissionMasterCache = HttpContext.Current.Cache[stPermissionMasterCacheKey];
        //        if (loPermissionMasterCache == null)
        //        {
        //            GenericDataContext loGenericDataContext = new GenericDataContext();
        //            loPermissionMasterList = new List<PermissionMaster>();

        //            loPermissionMasterList = loGenericDataContext.getUserPermissionByGroupID(inGroupID);
        //            HttpContext.Current.Cache.Insert(stPermissionMasterCacheKey, loPermissionMasterList, null, DateTime.Now.AddMinutes(240), System.Web.Caching.Cache.NoSlidingExpiration);
        //        }
        //        else
        //        {
        //            loPermissionMasterList = (List<PermissionMaster>)HttpContext.Current.Cache[stPermissionMasterCacheKey];
        //        }

        //        string stModuleName = loPermissionMasterList.Where(x => x.Controller.ToLower() == stController.ToLower()).Select(x => x.Name).FirstOrDefault();

        //        return stModuleName;

        //        #endregion
        //    }
        //    catch (Exception)
        //    {

        //        return "";
        //    }
           
        //}

        //public static int getModuleFuntionNumber(string stController)
        //{

        //    try
        //    {
        //        #region Check for if logged in user has access to view

        //        Int16 inUserInfoID = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).inUserInfoID;
        //        int inGroupID = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).inGroupID;

        //        List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();

        //        string stPermissionMasterCacheKey = inUserInfoID.ToString() + "PermissionMaster";
        //        object loPermissionMasterCache = HttpContext.Current.Cache[stPermissionMasterCacheKey];
        //        if (loPermissionMasterCache == null)
        //        {
        //            GenericDataContext loGenericDataContext = new GenericDataContext();
        //            loPermissionMasterList = new List<PermissionMaster>();

        //            loPermissionMasterList = loGenericDataContext.getUserPermissionByGroupID(inGroupID);
        //            HttpContext.Current.Cache.Insert(stPermissionMasterCacheKey, loPermissionMasterList, null, DateTime.Now.AddMinutes(240), System.Web.Caching.Cache.NoSlidingExpiration);
        //        }
        //        else
        //        {
        //            loPermissionMasterList = (List<PermissionMaster>)HttpContext.Current.Cache[stPermissionMasterCacheKey];
        //        }

        //        int iFuntionNumber = loPermissionMasterList.Where(x => x.Controller.ToLower() == stController.ToLower()).Select(x => x.FunctionNumber).FirstOrDefault();

        //        return iFuntionNumber;

        //        #endregion
        //    }
        //    catch (Exception)
        //    {

        //        return 0;
        //    }
            
        //}
    }
}