﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CtsWebCoreOutward.Models
{
    public class FinvergeCaptureSystem
    {

        public string BatchNo { get; set; }
        public string BlockNo { get; set; }
        public string SorterNo { get; set; }
        public string Bofd { get; set; }
        public string ChequeCount { get; set; }
        public string SlipCount { get; set; }
    }
}
