﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class SODViewModel
    {
        public class WrapperSOD
        {
            [Key]
            public string Status { get; set; }
            public string SODDate { get; set; }
            public string Msg { get; set; }
        }
        public class PermissionMaster
        {           
            
            public string Controller { get; set; }
            public string Call_Action { get; set; }
            [Key]
            public string Name { get; set; }
            public Int32 FunctionNumber { get; set; }


        }
    }
}