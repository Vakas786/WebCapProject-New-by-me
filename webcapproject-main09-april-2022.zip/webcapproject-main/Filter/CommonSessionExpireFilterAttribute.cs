﻿using CtsWebCoreOutward.ViewModel;
using FACoreDAC;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.ComonUtility;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CtsWebCoreOutward.Filter
{
    public class CommonSessionExpireFilterAttribute : ActionFilterAttribute
    {
        //public override void OnActionExecuting(ActionExecutingContext filterContext)
        //{
        //    if (HttpContext.Current.Session["WebCTSAdmin"] == null)
        //    {
        //        filterContext.Result = new RedirectToRouteResult("Login",
        //        new RouteValueDictionary { { "controller", "Login" }, { "action", "dologin" } });

        //    }
        //    else
        //    {
        //        DataTable dataTable = new DataTable();
        //        dataTable = MsSQL.GetDataTable("SELECT loginKey FROM UserInfo WHERE UserName='" + ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).stUserName.ToString() + "';", CommonFunctions.ConStr, HttpContext.Current.Server.MapPath("~/_Logs/" + HttpContext.Current.Request.Url.AbsolutePath.Replace('.', '-') + "_" + System.Reflection.MethodBase.GetCurrentMethod().Name));
        //        string appLoginKey = ((AdminLoginViewModel)HttpContext.Current.Session["WebCTSAdmin"]).loginKey.ToString();
        //        string dbLoginKey = dataTable.Rows[0]["loginKey"].ToString();
        //        if (appLoginKey != dbLoginKey)
        //        {
        //            HttpContext.Current.Session["WebCTSAdmin"] = null;
        //            filterContext.Result = new RedirectToRouteResult("Login", new RouteValueDictionary { { "controller", "Login" }, { "action", "LogOut" } });
        //        }
        //    }
        //    base.OnActionExecuting(filterContext);
        //}

    }
}