﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    // [CommonSessionExpireFilterAttribute]
    public class StatusViewerController : Controller
    {
        SqlConnection conn;
        private readonly StatusViewerDataContext _DBContext;
        public StatusViewerController(StatusViewerDataContext dbContext) { _DBContext = dbContext; }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public ActionResult StatusViewer(int? id)
        {
            //StatusViewerDataContext loStatusViewerDataContext = new StatusViewerDataContext();

            StatusViewerViewModel.WrapperStatusViewer loWrapperStatusViewer = new StatusViewerViewModel.WrapperStatusViewer();

            StatusViewerViewModel.StatusViewerGridColumnsString loStatusViewerGridColumnsString = new StatusViewerViewModel.StatusViewerGridColumnsString();
            loStatusViewerGridColumnsString = getStatusViewerGridDisplayColumns();


            loWrapperStatusViewer.loStatusViewerGridColumnsList = new List<StatusViewerViewModel.StatusViewerGridColumns>();
            string[] lsGridColumnMainArray = loStatusViewerGridColumnsString.BatchGridDisplayColumns.Split('|');
            foreach (var loData in lsGridColumnMainArray)
            {
                string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

                StatusViewerViewModel.StatusViewerGridColumns loStatusViewerGridColumns = new StatusViewerViewModel.StatusViewerGridColumns();
                loStatusViewerGridColumns.stFieldName = lsGridValues[0];
                loStatusViewerGridColumns.stWidth = lsGridValues[1];
                loStatusViewerGridColumns.stDisplayCaption = lsGridValues[2];

                loWrapperStatusViewer.loStatusViewerGridColumnsList.Add(loStatusViewerGridColumns);
            }
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            //string sBOFD = ((AdminLoginViewModel)Session["WebCTSAdmin"]).stPhBRNo;
            loWrapperStatusViewer.loStatusViewerList = getStatusViewerList(Convert.ToInt16(id), appUserInfo.stPhBRNo);

            return View(loWrapperStatusViewer);
        }

        //public ActionResult loaddata()
        //{
        //    StatusViewerDataContext loStatusViewerDataContext = new StatusViewerDataContext();
        //    StatusViewerViewModel.WrapperStatusViewer loWrapperStatusViewer = new StatusViewerViewModel.WrapperStatusViewer();
        //    StatusViewerViewModel.StatusViewerGridColumnsString loStatusViewerGridColumnsString = new StatusViewerViewModel.StatusViewerGridColumnsString();

        //    loStatusViewerGridColumnsString = loStatusViewerDataContext.getStatusViewerGridDisplayColumns();
        //    loWrapperStatusViewer.loStatusViewerGridColumnsList = new List<StatusViewerViewModel.StatusViewerGridColumns>();
        //    string[] lsGridColumnMainArray = loStatusViewerGridColumnsString.BatchGridDisplayColumns.Split('|');
        //    foreach (var loData in lsGridColumnMainArray)
        //    {
        //        string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

        //        StatusViewerViewModel.StatusViewerGridColumns loStatusViewerGridColumns = new StatusViewerViewModel.StatusViewerGridColumns();
        //        loStatusViewerGridColumns.stFieldName = lsGridValues[0];
        //        loStatusViewerGridColumns.stWidth = lsGridValues[1];
        //        loStatusViewerGridColumns.stDisplayCaption = lsGridValues[2];

        //        loWrapperStatusViewer.loStatusViewerGridColumnsList.Add(loStatusViewerGridColumns);
        //    }



        //    loWrapperStatusViewer.loStatusViewerList = loStatusViewerDataContext.getStatusViewerList(400);
        //    var data =  loWrapperStatusViewer.loStatusViewerList;
        //    return Json(new { data = data }, JsonRequestBehavior.AllowGet);

        //}

        public StatusViewerViewModel.StatusViewerGridColumnsString getStatusViewerGridDisplayColumns()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_StatusViewerGridColumnsString.FromSql("getStatusViewerGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }


        public IEnumerable<dynamic> getStatusViewerList(int iFunctionNo, string sBOFD)
        {
            conn = _DBContext.Database.GetDbConnection() as SqlConnection;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandText = "EXEC USP_StatusViewer '" + sBOFD + "'";
            using (var reader = cmd.ExecuteReader())
            {
                var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
                return model;
            }
        }

    }
}
