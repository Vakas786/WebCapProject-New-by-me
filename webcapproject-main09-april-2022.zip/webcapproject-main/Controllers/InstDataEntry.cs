﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Controllers
{
     [AuthorizeRole]
    public class InstDataEntryController : Controller
    {

        private readonly DataEntryDataContext _DBContext;
        public InstDataEntryController(DataEntryDataContext dbContext) { _DBContext = dbContext; }

        public ActionResult DataEntry(int? id)
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
            ViewBag.sToday = appUserInfo.sToday;

            DataEntryViewModel.WrapperDataEntry loWrapperDataEntry = new DataEntryViewModel.WrapperDataEntry();

            int iFuntionNumber = 100;
            if (id != null)
            {
                iFuntionNumber = Convert.ToInt16(id);
            }
            
            DataEntryViewModel.FuntionSP loFucntionSP = new DataEntryViewModel.FuntionSP();
            loFucntionSP = GetFunctionSpName(iFuntionNumber);
            ViewBag.sSP = loFucntionSP.SPName;
            ViewBag.Title = loFucntionSP.ModuleName;

            loWrapperDataEntry.loCheckDetailsList = getChequeList(iFuntionNumber.ToString(), loFucntionSP.SPName, appUserInfo.stLoginName);
            
            loWrapperDataEntry.iFuntionNo = iFuntionNumber;

            loWrapperDataEntry.loModuleFieldsList = getModuleFieldsList(iFuntionNumber.ToString());
            
            DataEntryViewModel.BatchGridColumnsString loBatchGridColumnsString = new DataEntryViewModel.BatchGridColumnsString();
            loBatchGridColumnsString = getGridDisplayColumns(iFuntionNumber);

            loWrapperDataEntry.loBatchGridColumnsList = new List<DataEntryViewModel.BatchGridColumns>();
            string[] lsGridColumnMainArray = loBatchGridColumnsString.GridDisplayColumns.Split('|');

            foreach (var loData in lsGridColumnMainArray)
            {
                string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

                DataEntryViewModel.BatchGridColumns BatchGridColumns = new DataEntryViewModel.BatchGridColumns();
                BatchGridColumns.stFieldName = lsGridValues[0];
                BatchGridColumns.stWidth = lsGridValues[1];
                BatchGridColumns.stDisplayCaption = lsGridValues[2];

                loWrapperDataEntry.loBatchGridColumnsList.Add(BatchGridColumns);
            }

            loWrapperDataEntry.loDataEntry = new DataEntryViewModel.DataEntry();
            loWrapperDataEntry.loCityMasterList = new List<string>();
            loWrapperDataEntry.loBankMasterList = new List<string>();
            loWrapperDataEntry.loBranchMasterList = new List<string>();
            loWrapperDataEntry.loTransactionCodeMasterList = new List<string>();

            List<DataEntryViewModel.CityMaster> loCityMasterList = new List<DataEntryViewModel.CityMaster>();
            loCityMasterList = getCityList();

            List<DataEntryViewModel.BankMaster> loBankMasterList = new List<DataEntryViewModel.BankMaster>();
            loBankMasterList = getBankList();

            List<DataEntryViewModel.BranchMaster> loBranchMasterList = new List<DataEntryViewModel.BranchMaster>();
            loBranchMasterList = getBranchList();

            List<DataEntryViewModel.TransactionCodeMaster> loTransactionCodeMasterList = new List<DataEntryViewModel.TransactionCodeMaster>();
            loTransactionCodeMasterList = getTransactionCodeList();

            loWrapperDataEntry.loCityMasterList = loCityMasterList.Select(x => x.stCityNo).ToList();
            loWrapperDataEntry.loBankMasterList = loBankMasterList.Select(x => x.stBankNo).ToList();
            loWrapperDataEntry.loBranchMasterList = loBranchMasterList.Select(x => x.stBranchNo).ToList();
            loWrapperDataEntry.loTransactionCodeMasterList = loTransactionCodeMasterList.Select(x => x.stTCNo).ToList();

            // List<DataEntryViewModel.RecordTypeFromDB> loRecordTypeFromDBList = new List<DataEntryViewModel.RecordTypeFromDB>();
            //loRecordTypeFromDBList = getRecordTypeForDropdown();

            //loWrapperDataEntry.loRecordTypeList = getRecordTypeForDropdown();
            loWrapperDataEntry.loRecordTypeValidationDetailList = getRecordTypeByRecType(2);

            //List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();
            //loPermissionMasterList = getUserPermissionByFunctionNumber(Convert.ToInt32(id));
            //loWrapperDataEntry.sCall_Action = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_action).FirstOrDefault();
            //loWrapperDataEntry.sController = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Controller).FirstOrDefault();

            return View(loWrapperDataEntry);

        }
        public ActionResult BackMenu(string fsSp, string fsFunctionNo)
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            string fsUserName = appUserInfo.stLoginName;
            string sUnlockSP = fsSp.Split('~')[2];
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));

            _DBContext.DBSet_TransactionCodeMaster.FromSql(sUnlockSP.getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

            //return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
            return Json(new { response = "true" });
        }
        public ActionResult saveChequeDetails(string fsSp, string fsUDKID, string fsParamList, string fsParamValue, string fsFunctionNo,string fsDETYPE)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            string fsUserName = appUserInfo.stLoginName;

            string sUpdateSP = fsSp.Split('~')[1];

            string[] lstParam = fsParamList.Split('|');
            string[] lstParamVal = fsParamValue.Split('|');
            for (int i = 0; i < lstParam.Length; i++)
            {
                loSqlParameters.Add(new SqlParameter("st" + lstParam[i].ToString(), lstParamVal[i].ToString().handleDBNull()));
            }

            loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stDETYPE", fsDETYPE.handleDBNull()));

            _DBContext.DBSet_TransactionCodeMaster.FromSql(sUpdateSP.getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

            return Json(new { response = "true" });
        }

        public ActionResult getChequeImageByImageType(string fsImageType, string fsUDKID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("iUDK", fsUDKID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iType", fsImageType.handleDBNull()));
            var loChequeImage = _DBContext.DBSet_ChequeImage.FromSql("WebProc_GetChequeImageByType".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault(); ;

            string lsImage = string.Empty;
            if (loChequeImage != null)
            {
                if ((fsImageType == "2") || (fsImageType == "3"))
                {
                    loChequeImage.stImage = CommonFunctions.ConvertTiffToJpeg(loChequeImage.stImage);
                }
                lsImage = Convert.ToBase64String(loChequeImage.stImage);
            }

            return Json(new { response = lsImage });

        }
        public ActionResult getAccountName(string fsAccNo)
        {
            List<DataEntryViewModel.AccountDetails> loAccountDetailsList = new List<DataEntryViewModel.AccountDetails>();
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stAccNo", fsAccNo.handleDBNull()));
            loAccountDetailsList = _DBContext.DBSet_AccountDetails.FromSql("getAccountDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            return Json(new { loAccountDetailsList });
        }
        public List<DataEntryViewModel.ModuleFields> getModuleFieldsList(string fsFunctionNo)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("stFunction", fsFunctionNo.handleDBNull()));
                return _DBContext.DBSet_ModuleFields.FromSql("getModuleFields".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.CityMaster> getCityList()
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                return _DBContext.DBSet_CityMaster.FromSql("getCityList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.BankMaster> getBankList()
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                return _DBContext.DBSet_BankMaster.FromSql("getBankList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.BranchMaster> getBranchList()
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                return _DBContext.DBSet_BranchMaster.FromSql("getBranchList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.TransactionCodeMaster> getTransactionCodeList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_TransactionCodeMaster.FromSql("getTransactionCodeList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public bool setUDKDeleteUndelete(string fsUDK, bool fbIsDelete)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stUDK", fsUDK.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("flgIsDelete", fbIsDelete.handleDBNull()));

            _DBContext.DBSet_TransactionCodeMaster.FromSql("setUDKDeleteUndelete".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

            return true;
        }

        public DataEntryViewModel.BatchGridColumnsString getGridDisplayColumns(Int32 iFunctionNo)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("FunctionNo", iFunctionNo.handleDBNull()));
            return _DBContext.DBSet_BatchGridColumnsString.FromSql("USP_GetGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }

        public IEnumerable<dynamic> getChequeList(string FunctionNbr, string fsSP, string fsloginName)
        {
            string sgetSp = fsSP.Split('~')[0].ToString();
            //using (var ctx = new DataEntryDataContext())
            var cmd = new SqlCommand();
            var con = new SqlConnection(CommonFunctions.ConStr);
            cmd.Connection = con;
            //cmd.CommandText = "WebProc_InstDataEntry";
            cmd.CommandText = sgetSp;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter param = cmd.CreateParameter();
            param.ParameterName = "stLoginName";
            param.DbType = DbType.String;
            param.Direction = ParameterDirection.Input;
            param.Value = fsloginName;
            cmd.Parameters.Add(param);

            DbParameter param2 = cmd.CreateParameter();
            param2.ParameterName = "stFunctionNo";
            param2.DbType = DbType.Int16;
            param2.Direction = ParameterDirection.Input;
            param2.Value = FunctionNbr;
            cmd.Parameters.Add(param2);
            
            con.Open();
            using (var reader = cmd.ExecuteReader())
            {
                var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
                return model;
            }
        }

        public List<DataEntryViewModel.RecordTypeValidationDetails> getRecordTypeByRecType(Int32 fiRecTypeID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("inRecTypeID", fiRecTypeID.handleDBNull()));
            return _DBContext.DBSet_RecordTypeValidationDetails.FromSql("getRecordTypeByRecTypeID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }
        public FuntionSP GetFunctionSpName(Int32 iFunctionNumber)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("functionNumber", iFunctionNumber.handleDBNull()));
            return _DBContext.DBSet_FuntionSP.FromSql("USP_GetSpByFunctionNumber".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }
        public bool UnlockItems(int functionNbr)
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("iSqlAction", "UNLOCK-CHEQUES"));
            loSqlParameters.Add(new SqlParameter("iUserId", appUserInfo.inUserInfoID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iFunctionNbr", functionNbr.handleDBNull()));

            _DBContext.DBSet_TransactionCodeMaster.FromSql("WebProc_InstDataEntryUnlockItems".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

            return true;
        }
    }
}
