﻿using FACoreDAC;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Web;

namespace CtsWebCoreOutward.ComonUtility
{
    public static class CommonFunctions
    {
        public static string GetAppKey()
        {
            var config = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
            return config["CustomAppSettings:appKey"].ToString();
        }
        public static string GetConStr()
        {
            var config = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
            return config["ConnectionStrings:MsSqlConStr"].ToString();
        }
        public static string ConStr = GetConStr();
        public static string AppKey = GetAppKey();
        public static string AppRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
        public static string AppDownloadPath = Path.Combine(AppRootPath, "Downloads");
        public static string AppTempPath = Path.Combine(AppRootPath, "Uploads", "TMP");
        public static string AppDataPath = Path.Combine(AppRootPath, "App_Data");
        public static string AppLogPath = Path.Combine(AppRootPath, "_Logs");
        public static string AppReportPath = Path.Combine(AppRootPath, "Reports");

        //public static void writeEmailLog(string fsMessage)
        //{
        //    try
        //    {
        //        StreamWriter loStreamWriter = new StreamWriter(System.Web.HttpContext.Current.Server.MapPath(@"~//Logs//Error.txt"), true);
        //        if (fsMessage != null)
        //            loStreamWriter.Write(DateTime.Now.ToString() + ": " + fsMessage + "\r\n");
        //        loStreamWriter.Dispose();
        //        loStreamWriter.Close();
        //    }
        //    catch (Exception)
        //    {
        //    }
        //}

        public static List<SelectListItem> getPrimaryLanguageList()
        {
            List<SelectListItem> loLanguages = new List<SelectListItem>();

            loLanguages.Add(new SelectListItem { Value = "Afrikaans", Text = "Afrikaans" });
            loLanguages.Add(new SelectListItem { Value = "Albanian", Text = "Albanian" });
            loLanguages.Add(new SelectListItem { Value = "Arabic", Text = "Arabic" });
            loLanguages.Add(new SelectListItem { Value = "Armenian", Text = "Armenian" });
            loLanguages.Add(new SelectListItem { Value = "Azerbaijani", Text = "Azerbaijani" });
            loLanguages.Add(new SelectListItem { Value = "Basque", Text = "Basque" });
            loLanguages.Add(new SelectListItem { Value = "Belarusian", Text = "Belarusian" });
            loLanguages.Add(new SelectListItem { Value = "Bengali", Text = "Bengali" });
            loLanguages.Add(new SelectListItem { Value = "Bosnian", Text = "Bosnian" });
            loLanguages.Add(new SelectListItem { Value = "Bulgarian", Text = "Bulgarian" });
            loLanguages.Add(new SelectListItem { Value = "Catalan", Text = "Catalan" });
            loLanguages.Add(new SelectListItem { Value = "Cebuano", Text = "Cebuano" });
            loLanguages.Add(new SelectListItem { Value = "Chichewa", Text = "Chichewa" });
            loLanguages.Add(new SelectListItem { Value = "Chinese (Simplified)", Text = "Chinese (Simplified)" });
            loLanguages.Add(new SelectListItem { Value = "Chinese (Traditional)", Text = "Chinese (Traditional)" });
            loLanguages.Add(new SelectListItem { Value = "Croatian", Text = "Croatian" });
            loLanguages.Add(new SelectListItem { Value = "Czech", Text = "Czech" });
            loLanguages.Add(new SelectListItem { Value = "Danish", Text = "Danish" });
            loLanguages.Add(new SelectListItem { Value = "Dutch", Text = "Dutch" });
            loLanguages.Add(new SelectListItem { Value = "English", Text = "English", Selected = true });
            loLanguages.Add(new SelectListItem { Value = "Esperanto", Text = "Esperanto" });
            loLanguages.Add(new SelectListItem { Value = "Estonian", Text = "Estonian" });
            loLanguages.Add(new SelectListItem { Value = "Filipino", Text = "Filipino" });
            loLanguages.Add(new SelectListItem { Value = "Finnish", Text = "Finnish" });
            loLanguages.Add(new SelectListItem { Value = "French", Text = "French" });
            loLanguages.Add(new SelectListItem { Value = "Galician", Text = "Galician" });
            loLanguages.Add(new SelectListItem { Value = "Georgian", Text = "Georgian" });
            loLanguages.Add(new SelectListItem { Value = "German", Text = "German" });
            loLanguages.Add(new SelectListItem { Value = "Greek", Text = "Greek" });
            loLanguages.Add(new SelectListItem { Value = "Gujarati", Text = "Gujarati" });
            loLanguages.Add(new SelectListItem { Value = "Haitian Creole", Text = "Haitian Creole" });
            loLanguages.Add(new SelectListItem { Value = "Hausa", Text = "Hausa" });
            loLanguages.Add(new SelectListItem { Value = "Hebrew", Text = "Hebrew" });
            loLanguages.Add(new SelectListItem { Value = "Hindi", Text = "Hindi" });
            loLanguages.Add(new SelectListItem { Value = "Hmong", Text = "Hmong" });
            loLanguages.Add(new SelectListItem { Value = "Hungarian", Text = "Hungarian" });
            loLanguages.Add(new SelectListItem { Value = "Icelandic", Text = "Icelandic" });
            loLanguages.Add(new SelectListItem { Value = "Igbo", Text = "Igbo" });
            loLanguages.Add(new SelectListItem { Value = "Indonesian", Text = "Indonesian" });
            loLanguages.Add(new SelectListItem { Value = "Irish", Text = "Irish" });
            loLanguages.Add(new SelectListItem { Value = "Italian", Text = "Italian" });
            loLanguages.Add(new SelectListItem { Value = "Japanese", Text = "Japanese" });
            loLanguages.Add(new SelectListItem { Value = "Javanese", Text = "Javanese" });
            loLanguages.Add(new SelectListItem { Value = "Kannada", Text = "Kannada" });
            loLanguages.Add(new SelectListItem { Value = "Kazakh", Text = "Kazakh" });
            loLanguages.Add(new SelectListItem { Value = "Khmer", Text = "Khmer" });
            loLanguages.Add(new SelectListItem { Value = "Korean", Text = "Korean" });
            loLanguages.Add(new SelectListItem { Value = "Lao", Text = "Lao" });
            loLanguages.Add(new SelectListItem { Value = "Latin", Text = "Latin" });
            loLanguages.Add(new SelectListItem { Value = "Latvian", Text = "Latvian" });
            loLanguages.Add(new SelectListItem { Value = "Lithuanian", Text = "Lithuanian" });
            loLanguages.Add(new SelectListItem { Value = "Macedonian", Text = "Macedonian" });
            loLanguages.Add(new SelectListItem { Value = "Malagasy", Text = "Malagasy" });
            loLanguages.Add(new SelectListItem { Value = "Malay", Text = "Malay" });
            loLanguages.Add(new SelectListItem { Value = "Malayalam", Text = "Malayalam" });
            loLanguages.Add(new SelectListItem { Value = "Maltese", Text = "Maltese" });
            loLanguages.Add(new SelectListItem { Value = "Maori", Text = "Maori" });
            loLanguages.Add(new SelectListItem { Value = "Marathi", Text = "Marathi" });
            loLanguages.Add(new SelectListItem { Value = "Mongolian", Text = "Mongolian" });
            loLanguages.Add(new SelectListItem { Value = "Myanmar (Burmese)", Text = "Myanmar (Burmese)" });
            loLanguages.Add(new SelectListItem { Value = "Nepali", Text = "Nepali" });
            loLanguages.Add(new SelectListItem { Value = "Norwegian", Text = "Norwegian" });
            loLanguages.Add(new SelectListItem { Value = "Persian", Text = "Persian" });
            loLanguages.Add(new SelectListItem { Value = "Polish", Text = "Polish" });
            loLanguages.Add(new SelectListItem { Value = "Portuguese", Text = "Portuguese" });
            loLanguages.Add(new SelectListItem { Value = "Punjabi", Text = "Punjabi" });
            loLanguages.Add(new SelectListItem { Value = "Romanian", Text = "Romanian" });
            loLanguages.Add(new SelectListItem { Value = "Russian", Text = "Russian" });
            loLanguages.Add(new SelectListItem { Value = "Serbian", Text = "Serbian" });
            loLanguages.Add(new SelectListItem { Value = "Sesotho", Text = "Sesotho" });
            loLanguages.Add(new SelectListItem { Value = "Sinhala", Text = "Sinhala" });
            loLanguages.Add(new SelectListItem { Value = "Slovak", Text = "Slovak" });
            loLanguages.Add(new SelectListItem { Value = "Slovenian", Text = "Slovenian" });
            loLanguages.Add(new SelectListItem { Value = "Somali", Text = "Somali" });
            loLanguages.Add(new SelectListItem { Value = "Spanish", Text = "Spanish" });
            loLanguages.Add(new SelectListItem { Value = "Sundanese", Text = "Sundanese" });
            loLanguages.Add(new SelectListItem { Value = "Swahili", Text = "Swahili" });
            loLanguages.Add(new SelectListItem { Value = "Swedish", Text = "Swedish" });
            loLanguages.Add(new SelectListItem { Value = "Tajik", Text = "Tajik" });
            loLanguages.Add(new SelectListItem { Value = "Tamil", Text = "Tamil" });
            loLanguages.Add(new SelectListItem { Value = "Telugu", Text = "Telugu" });
            loLanguages.Add(new SelectListItem { Value = "Thai", Text = "Thai" });
            loLanguages.Add(new SelectListItem { Value = "Turkish", Text = "Turkish" });
            loLanguages.Add(new SelectListItem { Value = "Ukrainian", Text = "Ukrainian" });
            loLanguages.Add(new SelectListItem { Value = "Urdu", Text = "Urdu" });
            loLanguages.Add(new SelectListItem { Value = "Uzbek", Text = "Uzbek" });
            loLanguages.Add(new SelectListItem { Value = "Vietnamese", Text = "Vietnamese" });
            loLanguages.Add(new SelectListItem { Value = "Welsh", Text = "Welsh" });
            loLanguages.Add(new SelectListItem { Value = "Yiddish", Text = "Yiddish" });
            loLanguages.Add(new SelectListItem { Value = "Yoruba", Text = "Yoruba" });
            loLanguages.Add(new SelectListItem { Value = "Zulu", Text = "Zulu" });

            return loLanguages;
        }

        public static List<SelectListItem> getTimeZoneList()
        {
            List<SelectListItem> loTimeZones = new List<SelectListItem>();
            loTimeZones.Add(new SelectListItem { Value = "0", Text = "Select" });

            // AssessTEAMDataContext loAssessTEAMDataContext = new AssessTEAMDataContext();
            //var loTimeZoneList = loGaryPlattDataContext.tblTimeZone.ToList();

            //foreach (var loTimeZone in loTimeZoneList)
            //    loTimeZones.Add(new SelectListItem { Text = loTimeZone.stTimeZone, Value = loTimeZone.stTimeZone });

            return loTimeZones;
        }
        public static List<SelectListItem> GetDDList(string EntityId, string StoreProcedure)
        {
            List<SelectListItem> DDList = new List<SelectListItem>();
            SqlParameter[] parm = new SqlParameter[] {
                                    new SqlParameter("@EntityId", EntityId)
                            };
            DDList.Add(new SelectListItem { Value = "0", Text = "--Select--" });
            foreach (DataRow row in MsSQL.GetDataTable(StoreProcedure, parm, ConStr, Path.Combine(CommonFunctions.AppLogPath, MethodBase.GetCurrentMethod().Name)).Rows)
            {
                DDList.Add(new SelectListItem { Value = row["_Value"].ToString(), Text = row["_Text"].ToString() });
            }
            return DDList;
        }

        #region DateTime Formats

        public static string DateTimeFormat = "{0:MM/dd/yyyy hh:mm:ss tt}";

        public static string DateFormat = "{0:MM/dd/yyyy}";

        public static string getFormattedDMH(double fdMinutes)
        {
            string lsGetFormattedDMH = string.Empty;

            if (fdMinutes > 0)
            {
                TimeSpan loTimeSpan = TimeSpan.FromMinutes(fdMinutes);
                if (loTimeSpan.Days > 0)
                    lsGetFormattedDMH += loTimeSpan.Days + (loTimeSpan.Days == 1 ? " day" : " days");
                if (loTimeSpan.Hours > 0)
                    lsGetFormattedDMH += " " + loTimeSpan.Hours + (loTimeSpan.Hours == 1 ? " hr" : " hrs");
                if (loTimeSpan.Minutes > 0)
                    lsGetFormattedDMH += " " + loTimeSpan.Minutes + (loTimeSpan.Minutes == 1 ? " min" : " mins");
            }

            if (string.IsNullOrEmpty(lsGetFormattedDMH))
                lsGetFormattedDMH = "0 min";

            return lsGetFormattedDMH.Trim();
        }

        public static string getHoursMinutesFromMinutes(double fdMinutes)
        {
            TimeSpan loTimeSpan = TimeSpan.FromMinutes(fdMinutes);
            string loResult = "0 min";
            if (loTimeSpan.Hours > 0 && loTimeSpan.Minutes > 0)
            {
                if (loTimeSpan.Hours == 1 && loTimeSpan.Minutes > 0)
                    loResult = string.Format("{0} hr and {1} mins", loTimeSpan.Hours, loTimeSpan.Minutes);
                else if (loTimeSpan.Hours > 0 && loTimeSpan.Minutes == 0)
                    loResult = string.Format("{0} hrs and {1} min", loTimeSpan.Hours, loTimeSpan.Minutes);
                else if (loTimeSpan.Hours == 1 && loTimeSpan.Minutes == 1)
                    loResult = string.Format("{0} hr and {1} min", loTimeSpan.Hours, loTimeSpan.Minutes);
                else
                    loResult = string.Format("{0} hrs and {1} mins", loTimeSpan.Hours, loTimeSpan.Minutes);
            }
            else if (loTimeSpan.Hours > 0 && loTimeSpan.Minutes == 0)
            {
                if (loTimeSpan.Hours > 1)
                    loResult = string.Format("{0} hrs", loTimeSpan.Hours);
                else
                    loResult = string.Format("{0} hr", loTimeSpan.Hours);
            }
            else if (loTimeSpan.Hours == 0 && loTimeSpan.Minutes > 0)
            {
                if (loTimeSpan.Minutes > 1)
                    loResult = string.Format("{0} mins", loTimeSpan.Minutes);
                else
                    loResult = string.Format("{0} min", loTimeSpan.Minutes);
            }
            return loResult;
        }

        public static List<SelectListItem> getCardYears()
        {
            List<SelectListItem> loCardYear = new List<SelectListItem>();

            loCardYear.Add(new SelectListItem { Value = "0", Text = "Year" });

            for (int liCounter = 0; liCounter < 15; liCounter++)
            {
                string lsYear = DateTime.Now.AddYears(liCounter).Year.ToString();
                loCardYear.Add(new SelectListItem { Value = lsYear, Text = lsYear });
            }

            return loCardYear;
        }

        public static List<SelectListItem> getCardMonths()
        {
            List<SelectListItem> loMonths = new List<SelectListItem>();

            loMonths.Add(new SelectListItem { Value = "0", Text = "Month" });
            loMonths.Add(new SelectListItem { Value = "1", Text = "Jan" });
            loMonths.Add(new SelectListItem { Value = "2", Text = "Feb" });
            loMonths.Add(new SelectListItem { Value = "3", Text = "Mar" });
            loMonths.Add(new SelectListItem { Value = "4", Text = "Apr" });
            loMonths.Add(new SelectListItem { Value = "5", Text = "May" });
            loMonths.Add(new SelectListItem { Value = "6", Text = "Jun" });
            loMonths.Add(new SelectListItem { Value = "7", Text = "Jul" });
            loMonths.Add(new SelectListItem { Value = "8", Text = "Aug" });
            loMonths.Add(new SelectListItem { Value = "9", Text = "Sep" });
            loMonths.Add(new SelectListItem { Value = "10", Text = "Oct" });
            loMonths.Add(new SelectListItem { Value = "11", Text = "Nov" });
            loMonths.Add(new SelectListItem { Value = "12", Text = "Dec" });

            return loMonths;
        }

        public static List<SelectListItem> getDurationForAlert()
        {
            List<SelectListItem> loDurations = new List<SelectListItem>();

            loDurations.Add(new SelectListItem { Value = "2", Text = "Every 2 hours" });
            loDurations.Add(new SelectListItem { Value = "4", Text = "Every 4 hours" });
            loDurations.Add(new SelectListItem { Selected = true, Value = "6", Text = "Every 6 hours" });
            loDurations.Add(new SelectListItem { Value = "12", Text = "Every 12 hours" });
            loDurations.Add(new SelectListItem { Value = "24", Text = "Every 24 hours" });

            return loDurations;
        }

        #endregion DateTime Formats

        #region Encryption
        public static string Encrypt(string lstValue)
        {
            string lstnewsting = "";
            try
            {
                if (!string.IsNullOrEmpty(lstValue))
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(lstValue);
                    int lilength = 8;
                    StringBuilder buffer = new StringBuilder(lilength);
                    buffer.Append(System.Convert.ToBase64String(bytes));

                    while (buffer.Length < lilength)
                    {
                        buffer.Append('=');
                    }
                    lstnewsting = buffer.ToString();
                }
            }
            catch (Exception)
            {

            }
            return lstnewsting;
        }

        public static string Decrypt(string lstValue)
        {
            string lstnewsting = "";
            try
            {
                if (!string.IsNullOrEmpty(lstValue))
                {
                    int index = lstValue.IndexOf('=');
                    if (index > 0)
                    {
                        lstValue = lstValue.Substring(0, ((index + 3) / 4) * 4);
                    }
                    byte[] bytes = System.Convert.FromBase64String(lstValue);
                    lstnewsting = System.Text.Encoding.UTF8.GetString(bytes);
                }
            }
            catch (Exception)
            {
                lstValue = string.Empty;
            }
            return lstnewsting;

        }
        #endregion

        public static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        public static string getSuperScript(string fstNumber)
        {
            int liNumber = 0;
            int.TryParse(fstNumber, out liNumber);
            string lstReturn = "";
            int liFirst = liNumber % 10;
            double liTens = Math.Floor(liNumber / (double)10) % 10;
            if (liTens == 1)
                lstReturn = "th";
            else
            {
                switch (liFirst)
                {
                    case 1:
                        lstReturn = "st"; break;
                    case 2:
                        lstReturn = "nd"; break;
                    case 3:
                        lstReturn = "rd"; break;
                    default:
                        lstReturn = "th"; break;
                }
            }
            return lstReturn;
        }

        public static DateTime ToClientTime(int? fitimeOffSet)
        {
            DateTime ldtTime = DateTime.UtcNow;

            if (fitimeOffSet.HasValue)
            {
                var looffset = fitimeOffSet.Value;
                ldtTime = ldtTime.AddMinutes(-1 * looffset);

                return ldtTime;
            }

            // if there is no offset in session return the datetime in server timezone
            return ldtTime.ToLocalTime();
        }

        public static DateTime?[] setLogDuration(string fsFromDate, string fsToDate, string fsLogDuration, int? fiOffSet)
        {
            DateTime?[] loDates = new DateTime?[2];
            loDates[0] = null;
            loDates[1] = null;
            if ((fsLogDuration == "4" || fsLogDuration == "3") && (!string.IsNullOrEmpty(fsFromDate) || !string.IsNullOrEmpty(fsToDate)))//For Custom Dates
            {
                if (!string.IsNullOrEmpty(fsFromDate))
                    loDates[0] = DateTime.Parse(fsFromDate);
                if (!string.IsNullOrEmpty(fsToDate))
                    loDates[1] = DateTime.Parse(fsToDate);
            }
            else
            {
                DateTime ldtClientDate = ToClientTime(fiOffSet);

                switch (fsLogDuration)
                {
                    case "0"://For Today
                        loDates[0] = ldtClientDate.Date;
                        loDates[1] = ldtClientDate.Date;
                        break;
                    case "1"://For Yesterday
                        loDates[0] = ldtClientDate.Date.AddDays(-1).Date;
                        loDates[1] = ldtClientDate.Date.AddDays(-1).Date;
                        break;
                    case "2"://For Weekly
                        if (Convert.ToString(ldtClientDate.DayOfWeek) != "Monday")
                            loDates[0] = ldtClientDate.AddDays(1 + (-(int)ldtClientDate.DayOfWeek)).Date;
                        else
                            loDates[0] = ldtClientDate.Date;

                        loDates[1] = loDates[0].Value.AddDays(6).Date;
                        break;
                    case "3"://For Monthly
                        loDates[0] = new DateTime(ldtClientDate.Year, ldtClientDate.Month, 1);
                        loDates[1] = new DateTime(ldtClientDate.Year, ldtClientDate.Month, DateTime.DaysInMonth(ldtClientDate.Year, ldtClientDate.Month));
                        break;
                    case "5": // For Last 7 Days
                        loDates[0] = ldtClientDate.Date.AddDays(-7).Date;
                        loDates[1] = ldtClientDate.Date;
                        break;

                }
            }
            return loDates;
        }

        #region JSON serilazation and deserialization
        public static string Serialize<T>(T obj)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
            MemoryStream ms = new MemoryStream();
            serializer.WriteObject(ms, obj);
            string retVal = Encoding.UTF8.GetString(ms.ToArray());
            return retVal;
        }

        public static T Deserialize<T>(string json)
        {
            T obj = Activator.CreateInstance<T>();
            MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(json));
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
            obj = (T)serializer.ReadObject(ms);
            ms.Close();
            return obj;
        }
        #endregion

        //end

        ////added by Balar on 11/02/2015
        //public static string getJson(object foObj)
        //{
        //    StringBuilder lsOutput = new StringBuilder();
        //    JavaScriptSerializer serializer = new JavaScriptSerializer();
        //    serializer.Serialize(foObj, lsOutput);
        //    return lsOutput.ToString();
        //}
        ////end

        public static string getFullAddress(string fsAddress1, string fsAddress2, string fsAddress3, string fsCity, string fsState, string fsZip)
        {
            string lsFullAddress = string.Empty;

            if (!string.IsNullOrEmpty(fsAddress1))
                lsFullAddress += fsAddress1 + ", ";

            if (!string.IsNullOrEmpty(fsAddress2))
                lsFullAddress += fsAddress2 + ", ";

            if (!string.IsNullOrEmpty(fsAddress3))
                lsFullAddress += fsAddress3 + ", ";

            if (!string.IsNullOrEmpty(fsCity))
                lsFullAddress += fsCity + ", ";

            if (!string.IsNullOrEmpty(fsState))
                lsFullAddress += fsState + ", ";

            if (!string.IsNullOrEmpty(fsZip))
                lsFullAddress += fsZip;


            if (lsFullAddress.EndsWith(", "))
                lsFullAddress = lsFullAddress.Substring(0, lsFullAddress.Length - 2);

            return lsFullAddress;
        }

        public static string getFullAddress(string fsAddress1, string fsAddress2, string fsAddress3)
        {
            string lsFullAddress = string.Empty;

            if (!string.IsNullOrEmpty(fsAddress1))
                lsFullAddress += fsAddress1 + ", ";

            if (!string.IsNullOrEmpty(fsAddress2))
                lsFullAddress += fsAddress2 + ", ";

            if (!string.IsNullOrEmpty(fsAddress3))
                lsFullAddress += fsAddress3 + ", ";

            if (lsFullAddress.EndsWith(", "))
                lsFullAddress = lsFullAddress.Substring(0, lsFullAddress.Length - 2);

            return lsFullAddress;
        }

        //public static void redirectPermanent(String fsURL)
        //{
        //    try
        //    {
        //        HttpContext.Current.Response.Clear();
        //        HttpContext.Current.Response.StatusCode = 301;
        //        HttpContext.Current.Response.Status = "301 Moved Permanently";
        //        HttpContext.Current.Response.AddHeader("Location", fsURL);
        //        HttpContext.Current.ApplicationInstance.CompleteRequest();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public static string getDateInFormatYYYYMMDD(DateTime? fdtDate)
        {
            if (fdtDate.HasValue)
                return string.Format("{0:yyyy-MM-dd}", fdtDate);
            else
                return string.Empty;
        }

        public static string getDateInFormat(DateTime? fdtDate)
        {
            if (fdtDate.HasValue)
                return string.Format("{0:d-MMM-yyyy}", fdtDate);
            else
                return string.Empty;
        }

        public static string getDateTimeInFormat(DateTime? fdtDate)
        {
            if (fdtDate.HasValue)
                return string.Format("{0:MMM dd,yyyy hh:mm tt}", fdtDate);
            else
                return string.Empty;
        }

        public static string getAmountInFormat(decimal? fdAmount)
        {
            if (fdAmount.HasValue)
                return "$" + string.Format("{0:###,###,###,##0.00}", fdAmount);
            else
                return "$" + string.Format("{0:###,###,###,##0.00}", 0);
        }

        public static int getPageNum(int liRowCount, int liPageSize, int liCurrentPageIndex)
        {
            int inPegeNum = liRowCount / liPageSize;
            return inPegeNum;
        }

        public static string GetTimesheetDateFormat(DateTime loDate)
        {

            var dt = loDate;

            string suffix;

            if (new[] { 11, 12, 13 }.Contains(dt.Day))
            {
                suffix = "th";
            }
            else if (dt.Day % 10 == 1)
            {
                suffix = "st";
            }
            else if (dt.Day % 10 == 2)
            {
                suffix = "nd";
            }
            else if (dt.Day % 10 == 3)
            {
                suffix = "rd";
            }
            else
            {
                suffix = "th";
            }

            return dt.Day + suffix + " " + dt.Date.ToString("MMM");
        }

        public static string GetTimesheetMonthFormat(DateTime loDate)
        {
            return loDate.Date.ToString("MMMM") + " " + loDate.Date.Year;
        }

        public static string getTimeSheetHeaderDateFormat(DateTime? fdtDate)
        {
            if (fdtDate.HasValue)
                return string.Format("{0:d MMM yyyy}", fdtDate);
            else
                return string.Empty;
        }

        public static double convertTimeSheetHoursToDouble(string fsHours)
        {
            string[] stArrary = fsHours.Split(':');

            int inHours = 0;
            if (stArrary[0] != null)
            {
                inHours = Convert.ToInt32(stArrary[0]);
            }
            int inMinutes = 0;
            if (stArrary.Length > 1 && stArrary[1] != null && stArrary[1] != string.Empty)
            {
                inMinutes = Convert.ToInt32(stArrary[1]);
            }
            TimeSpan loTimeSpan = new TimeSpan(inHours, inMinutes, 0);
            return loTimeSpan.TotalHours;
        }

        //public static double convertDoubleToHours()
        //{
        //    double dcHoursFromDecimal = 0;


        //    var timeSpan = TimeSpan.FromHours(dcHoursFromDecimal);
        //    int hh = timeSpan.Hours;
        //    int mm = timeSpan.Minutes;
        //    int ss = timeSpan.Seconds;

        //    convertDoubleToHours(dcHoursFromDecimal);

        //    return dcHoursFromDecimal;

        //}

        public static string convertDoubleToHours(double num)
        {
            double hours = Math.Floor(num); //take integral part
            double minutes = (num - hours) * 60.0; //multiply fractional part with 60
            //double seconds = (minutes - Math.Floor(minutes)) * 60.0;  //add if you want seconds
            double H = (double)Math.Floor(hours);
            double M = (double)Math.Floor(Math.Round(minutes));
            //int S = (int)Math.Floor(seconds);   //add if you want seconds
            return H.ToString() + ":" + M.ToString(); //+":" + S.ToString(); //add if you want seconds
        }

        public static int getMonthDifference(DateTime startDate, DateTime endDate)
        {
            int monthsApart = 12 * (startDate.Year - endDate.Year) + startDate.Month - endDate.Month;
            return Math.Abs(monthsApart) + 1;
        }

        public static string getImageToBase64String(string fsCompanyLogoImagePath)
        {
            byte[] imageArray = System.IO.File.ReadAllBytes(fsCompanyLogoImagePath);
            return Convert.ToBase64String(imageArray);
        }
        public static byte[] ConvertTiffToJpeg(byte[] bTiffImage)
        {

            Byte[] jpegBytes;

            using (MemoryStream inStream = new MemoryStream(bTiffImage))
            using (MemoryStream outStream = new MemoryStream())
            {
                System.Drawing.Bitmap.FromStream(inStream).Save(outStream, System.Drawing.Imaging.ImageFormat.Jpeg);
                jpegBytes = outStream.ToArray();
            }
            return jpegBytes;
        }

        public static List<Dictionary<string, object>> getDynamicDataFromDB(DbDataReader reader)
        {
            List<Dictionary<string, object>> expandolist = new List<Dictionary<string, object>>();
            foreach (var item in reader)
            {
                IDictionary<string, object> expando = new ExpandoObject();
                foreach (PropertyDescriptor propertyDescriptor in TypeDescriptor.GetProperties(item))
                {
                    var obj = propertyDescriptor.GetValue(item);
                    expando.Add(propertyDescriptor.Name, obj);
                }
                expandolist.Add(new Dictionary<string, object>(expando));
            }
            return expandolist;
        }

        #region HTML to PDF
        /// <summary>
        /// Convert HTML FIle to PDF from Live URI.
        /// </summary>
        /// <param name="fsHTMLFilePath">Pass Live HTML URI</param>
        /// <param name="fsPDFFilePath">Pass PDF File Path</param>
        /// <returns></returns>
        //public static int generateWkhtmltopdf(string fsHTMLFilePath, string fsPDFFilePath, bool fbIsPortraitOrientation, string fsHTMLFooterFilePath = "", 
        //    string fsHTMLHeaderFilePath = "")
        //{
        //    string sPageNo = @"""Page [page] of [toPage]"""; // @"[page] / [toPage]"
        //    int liSuccess = 0;
        //    string lsArguments = " --image-dpi 600 --margin-top 10 --margin-left 05 --margin-right 05";
        //    lsArguments += !string.IsNullOrEmpty(fsHTMLFooterFilePath) ? " --margin-bottom 20 --footer-html " + fsHTMLFooterFilePath : string.Empty;
        //    lsArguments += " --footer-right " + sPageNo;

        //    lsArguments += !string.IsNullOrEmpty(fsHTMLHeaderFilePath) ? " --header-html " + fsHTMLHeaderFilePath : string.Empty;
        //    lsArguments += " --orientation " + (fbIsPortraitOrientation ? "Portrait" : "Landscape");
        //    lsArguments += " " + fsHTMLFilePath + " " + HttpContext.Current.Server.MapPath(fsPDFFilePath);

        //    //lsArguments += " --header - right = '[page]/[toPage]'";

        //    if (!string.IsNullOrEmpty(fsHTMLFilePath) && !string.IsNullOrEmpty(fsPDFFilePath))
        //    {
        //        /// Use ProcessStartInfo class to add more arguments
        //        System.Diagnostics.ProcessStartInfo loProcessStartInfo = new System.Diagnostics.ProcessStartInfo();
        //        loProcessStartInfo.CreateNoWindow = true;
        //        loProcessStartInfo.UseShellExecute = false;
        //        loProcessStartInfo.FileName = ConfigurationManager.AppSettings["HtmlToPdfExe"];
        //        loProcessStartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
        //        //loProcessStartInfo.Arguments = " --image-dpi 600 --margin-bottom 20" + (!string.IsNullOrEmpty(fsHTMLFooterFilePath) ? " --footer-html " + fsHTMLFooterFilePath : string.Empty) + " --orientation " + (fbIsPortraitOrientation ? "Portrait" : "Landscape") + " " + fsHTMLFilePath + " " + HttpContext.Current.Server.MapPath(fsPDFFilePath);
        //        loProcessStartInfo.Arguments = lsArguments;
        //        //loProcessStartInfo.RedirectStandardOutput = true;
        //        //loProcessStartInfo.RedirectStandardError = true; ///Causes issue while large PDF generating..
        //        //loProcessStartInfo.RedirectStandardInput = true;

        //        // Start the process with the info we specified. Call WaitForExit and then the using statement will close.
        //        using (System.Diagnostics.Process loExeProcess = System.Diagnostics.Process.Start(loProcessStartInfo))
        //        {
        //            loExeProcess.WaitForExit();
        //            loExeProcess.Close();
        //            loExeProcess.Dispose();
        //        }
        //        if (File.Exists(HttpContext.Current.Server.MapPath(fsPDFFilePath)))
        //            liSuccess = 1;
        //    }
        //    return liSuccess;
        //}

        public static void removeTemporaryHTMlFile(string fsFilePath)
        {
            if (System.IO.File.Exists(fsFilePath))
                System.IO.File.Delete(fsFilePath);
        }

        //public static string getApplicationHostURI(HttpRequestBase foObject)
        //{
        //    return (foObject.Url.Scheme + "://"
        //            + foObject.Url.Host
        //            + (foObject.Url.Port == 80 ? "" : ":" + Convert.ToString(foObject.Url.Port))
        //            //+ (string.IsNullOrEmpty(foObject.ApplicationPath) ? "" : (foObject.ApplicationPath.EndsWith("/") ? foObject.ApplicationPath : foObject.ApplicationPath + "/"))
        //            );
        //}
        #endregion

        #region SMS Functions
        /// <summary>
        /// Send SMS Function
        /// </summary>
        /// <param name="fsContactNo">number : Destination numbers ( Comma separated ) eg : 99XXXXXXXX,98XXXXXXXX</param>
        /// <param name="fsMessage">sms : SMS content ( Url encoded )</param>
        /// <param name="fiRouteType">route : Route you want to send SMS ( Promotional - 1, Transactional - 2, Sender ID - 3, International - 9, Trans2 - 10 )</param>
        /// <param name="fiMessageType">type : Message type ( Text - 1 , Flash - 2 , Unicode - 3 )</param>
        /// <returns>Success: 0: No, 1:Yes</returns>
        //public static int sendSMS(String fsContactNo, String fsMessage, int fiRouteType, int fiMessageType)
        //{
        //    int liResult = 0;

        //    string lsRequestAPI = "http://sms.parkentechnology.com/httpapi/httpapi?token="
        //                    + ConfigurationManager.AppSettings["SMSApiToken"]
        //                    + "&sender=" + ConfigurationManager.AppSettings["SMSSenderID"]
        //                    + "&number=" + fsContactNo
        //                    + "&route=" + fiRouteType
        //                    + "&type=" + fiMessageType
        //                    + "&sms=" + fsMessage;

        //    try
        //    {
        //        using (WebClient loWebClient = new WebClient())
        //        {
        //            loWebClient.DownloadString(new Uri(lsRequestAPI));
        //            liResult = 1;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        liResult = 0;
        //        throw ex;
        //    }

        //    return liResult;
        //}
        #endregion
    }
}