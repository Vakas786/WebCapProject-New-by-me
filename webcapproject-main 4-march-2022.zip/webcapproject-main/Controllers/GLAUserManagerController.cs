﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class GLAUserManagerController : Controller
    {
        private readonly GLAUserManagerDataContext _DBContext;
        public GLAUserManagerController(GLAUserManagerDataContext dbContext) { _DBContext = dbContext; }
        public ActionResult GLAUserManagerListMain(int? id)
        {
            try
            {
                GLAUserManagerViewModel.AddUserInfo loAddUserInfoEntry = new GLAUserManagerViewModel.AddUserInfo();
                //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();

                loAddUserInfoEntry.iFuntionNo = id;
                loAddUserInfoEntry.UserInfoList = GetUserInfoDataList();
         
                return View(loAddUserInfoEntry);
                //return View("~/Areas/GLAUserManager/Views/GLAUserManager/GLAUserManagerList.cshtml", loAddUserInfoEntry);
            }
            catch (Exception ex)
            {
                return View();
            }

        }

        public ActionResult GLAUserManager(int? id)
        {
            try
            {
                GLAUserManagerViewModel.AddUserInfo loAddUserInfoEntry = new GLAUserManagerViewModel.AddUserInfo();
                //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();

                loAddUserInfoEntry.iFuntionNo = id;


                loAddUserInfoEntry.GroupList = getUserGroupList();
               
                return View(loAddUserInfoEntry);

            }
            catch (Exception)
            {
                return View();
            }

        }

        public ActionResult GLAUserManagerEdit(int? id, int? UserInfoID)
        {
            try
            {
                GLAUserManagerViewModel.AddUserInfo loAddUserInfoEntry = new GLAUserManagerViewModel.AddUserInfo();
                //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();

                GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
                loGLAUserManagerViewModel.UserInfoList = getUserInfo_EditById(UserInfoID);
                loAddUserInfoEntry.iFuntionNo = id;
                
                loAddUserInfoEntry.UserInfoID = Convert.ToInt16(UserInfoID);

                if (loGLAUserManagerViewModel.UserInfoList != null && loGLAUserManagerViewModel.UserInfoList.Count > 0)
                {
                    loAddUserInfoEntry.GroupList = getUserGroupList();

                    loAddUserInfoEntry.UserInfoID = loGLAUserManagerViewModel.UserInfoList[0].UserInfoID;
                    loAddUserInfoEntry.UserName = loGLAUserManagerViewModel.UserInfoList[0].UserName;
                    loAddUserInfoEntry.UserPWD = loGLAUserManagerViewModel.UserInfoList[0].UserPWD;
                    loAddUserInfoEntry.PhBRNo = loGLAUserManagerViewModel.UserInfoList[0].PhBRNo;
                    loAddUserInfoEntry.UserGroupID = loGLAUserManagerViewModel.UserInfoList[0].GroupID;
                    loAddUserInfoEntry.LoginName = loGLAUserManagerViewModel.UserInfoList[0].LoginName;
                    loAddUserInfoEntry.MobileNo = loGLAUserManagerViewModel.UserInfoList[0].MobileNo;
                    
                }

                return View(loAddUserInfoEntry);

            }
            catch (Exception ex)
            {
                return View();
            }

        }

        public ActionResult InsertData(int? UserInfoID, string UserName, string UserPWD, string PhBRNo, int? GroupID, string LoginName, string MobileNo)
        {
            GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
            //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();
            loGLAUserManagerViewModel.UserInfoList = InsertDocumnetData(UserInfoID, UserName, UserPWD, PhBRNo, GroupID, LoginName, MobileNo);
            return View("~/Views/GLAUserManager/GLAUserManagerListMain.cshtml", loGLAUserManagerViewModel);

        }

        public ActionResult UpdateDetail(int? UserInfoID, string UserName, string UserPWD, string PhBRNo, int? GroupID, string LoginName, string MobileNo)
        {
            GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
            //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();
            loGLAUserManagerViewModel.UserInfoList = UpdateData(UserInfoID, UserName, UserPWD, PhBRNo, GroupID, LoginName, MobileNo);
            return View("~/Views/GLAUserManager/GLAUserManagerListMain.cshtml", loGLAUserManagerViewModel);

        }


        public ActionResult GETData(string UserName, string GroupName)
        {
            GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
           // GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();
            loGLAUserManagerViewModel.UserInfoList = GetUserInfoData(UserName, GroupName);
            return View("~/Views/GLAUserManager/GLAUserManagerList.cshtml", loGLAUserManagerViewModel);
        }

        public ActionResult GetUserList()
        {
            GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
            // GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();
            loGLAUserManagerViewModel.UserInfoList = GetUserInfoDataList();
            return View("~/Views/GLAUserManager/GLAUserManagerList.cshtml", loGLAUserManagerViewModel);
        }

        public ActionResult DeleteDetailByID(int? UserInfoID)
        {
            GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
            //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();
            loGLAUserManagerViewModel.UserInfoList = getUserInfo_DeleteById(UserInfoID);
            loGLAUserManagerViewModel.UserInfoList = GetUserInfoDataList();
            return View("~/Views/GLAUserManager/GLAUserManagerList.cshtml", loGLAUserManagerViewModel);
            
        }

        public ActionResult EditDetailByID(int? UserInfoID)
        {
            GLAUserManagerViewModel.AddUserInfo loGLAUserManagerViewModel = new GLAUserManagerViewModel.AddUserInfo();
            //GLAUserManagerDataContext loGLAUserManagerDataContext = new GLAUserManagerDataContext();
            loGLAUserManagerViewModel.UserInfoList = getUserInfo_EditById(UserInfoID);

            return Json(loGLAUserManagerViewModel.UserInfoList);
        }

        public List<GLAUserManagerViewModel.UserGroup> getUserGroupList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_UserGroup.FromSql("getUserGroupList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<GLAUserManagerViewModel.UserInfo> getUserInfo_DeleteById(int? UserInfoID)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("UserInfoID", UserInfoID.handleDBNull()));

            return _DBContext.DBSet_UserInfo.FromSql("DeleteUserInfo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<GLAUserManagerViewModel.UserInfo> getUserInfo_EditById(int? UserInfoID)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("UserInfoID", UserInfoID.handleDBNull()));

            return _DBContext.DBSet_UserInfo.FromSql("EditUserInfoID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }


        public List<GLAUserManagerViewModel.UserInfo> InsertDocumnetData(int? UserInfoID, string UserName, string UserPWD, string PhBRNo, int? GroupID, string LoginName, string MobileNo)
        {
            try
            {
                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("stUserInfoID", UserInfoID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserName", UserName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserPWD", UserPWD.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stPhBRNo", PhBRNo.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stGroupID", GroupID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stLoginName", LoginName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stMobileNo", MobileNo.handleDBNull()));

                _DBContext.Database.ExecuteSqlCommand("InsertUserInfoDetail ".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray());


                List<SqlParameter> loSqlParameters_List = new List<SqlParameter>();
                loSqlParameters_List.Add(new SqlParameter("stUserInfoID", UserInfoID.handleDBNull()));

                return _DBContext.DBSet_UserInfo.FromSql("GetUserInfoDetailByID".getSql(loSqlParameters_List), loSqlParameters_List.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<GLAUserManagerViewModel.UserInfo> UpdateData(int? UserInfoID, string UserName, string UserPWD, string PhBRNo, int? GroupID, string LoginName, string MobileNo)
        {
            try
            {

                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("stUserInfoID", UserInfoID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserName", UserName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserPWD", UserPWD.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stPhBRNo", PhBRNo.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stGroupID", GroupID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stLoginName", LoginName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stMobileNo", MobileNo.handleDBNull()));

                return _DBContext.DBSet_UserInfo.FromSql("UpdateUserInfoDetail".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }



        public List<GLAUserManagerViewModel.UserInfo> GetUserInfoData(string UserName, string GroupName)
        {
            try
            {

                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("stUserName", UserName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stGroupName", GroupName.handleDBNull()));

                return _DBContext.DBSet_UserInfo.FromSql("GetUserInfoDetail_Search".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<GLAUserManagerViewModel.UserInfo> GetUserInfoDataList()
        {
            try
            {

                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();

                return _DBContext.DBSet_UserInfo.FromSql("GetUserInfoDetail".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception ex)
            {
                return null;
            }
        }


        [HttpGet]
        public ActionResult FinvergeCaptureSystem()
        {
            return View();
        }
    }
}
