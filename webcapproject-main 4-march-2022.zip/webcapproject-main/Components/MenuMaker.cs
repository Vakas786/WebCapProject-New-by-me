﻿using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CtsWebCoreOutward.Components
{
    public class MenuMaker : ViewComponent
    {
        private readonly SODDataContext _DBContext;
        public MenuMaker(SODDataContext dbContext) { _DBContext = dbContext; }
        public IViewComponentResult Invoke()
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            var menuMaker = new ListMenuMakerViewModel();
            var sqlParm = new List<SqlParameter> { new SqlParameter("@GourpId", appUserInfo.inGroupID) };
            menuMaker.MenuList = _DBContext.DBSet_PermissionMaster.FromSql(@"
SELECT PM.FunctionNumber, PM.Controller, PM.Call_Action, MF.Name FROM PermissionMaster AS PM
LEFT JOIN ModuleFunctionTbl AS MF ON PM.FunctionNumber = MF.FunctionNumber
LEFT JOIN UserGroupDtl UG ON UG.FunctionNumber = MF.FunctionNumber
WHERE UG.UserGroupId = @GourpId
AND PM.Call_Action !='Dashboard' AND PM.Controller !='DocumentSearch'  ORDER BY PM.Position", sqlParm.ToArray()).ToList();
            return View(menuMaker);
        }
        public class ListMenuMakerViewModel
        {
            public List<SODViewModel.PermissionMaster> MenuList { get; set; }
        }
    }
}
