﻿using System;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using CtsWebCoreOutward.ComonUtility;
using Microsoft.EntityFrameworkCore;
using CtsWebCoreOutward.Filter;

namespace CtsWebCoreOutward.Models
{
    [Serializable()]
    class CXFGenerate
    {
        private SqlConnection sqlcon;
        
        #region SQL Function
        private void sqlClose()
        {
            if (sqlcon.State == ConnectionState.Open)
                sqlcon.Close();
        }
        private void sqlOpen()
        {
            try
            {
                if (sqlcon.State == ConnectionState.Closed)
                    sqlcon.Open();
            }
            catch (Exception)
            {
            }
        }
        public string GetConfigValues(string strConfigName)
        {
            string strConfigValue = "";
            try
            {
                string strQuery = string.Empty;
                strQuery = "select ISNULL(min(ConfigValue),' ') as COnfigValue from Configuration WITH (NOLOCK) WHERE ConfigName = '" + strConfigName + "'";
                object obj = ExecuteScalarStr(strQuery, "GetConfig");
                strConfigValue = (obj == null) ? "" : obj.ToString();
            }
            catch (Exception ex)
            {
                WriteLog("GETConfigValue" + " Error " + ex.Message);

            }
            return strConfigValue;
        }
        public int GetDocumentStatus(string sStatusName)
        {
            int iOutputStatus = 0;
            try
            {
                string strQuery = string.Empty;
                strQuery = "SELECT IsNull(Status, 0) As Status FROM InstrumentStatus WHERE StatusName = '" + sStatusName + "'";
                object obj = ExecuteScalarStr(strQuery, "GetDocumentStatus");
                iOutputStatus = (obj == null) ? 0 : Convert.ToInt16(obj.ToString());
            }
            catch (Exception ex)
            {
                WriteLog("GetDocumentStatus" + " Error " + ex.Message);

            }
            return iOutputStatus;
        }
        private object ExecuteScalarStr(string sSql, string sFunctionName4Log)
        {
            sqlcon = new SqlConnection(CommonFunctions.ConStr);
            sqlOpen();
            try
            {
                using (SqlCommand command = new SqlCommand(sSql, sqlcon))
                {
                    return command.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                WriteLog(sFunctionName4Log + " Error - " + ex.Message);
            }
            finally
            {
                sqlClose();
            }
            return null;
        }
        private DataTable GetDataTableFromSqlStr(string sSql, string sFunctionName4Log)
        {
            sqlcon = new SqlConnection(CommonFunctions.ConStr);
            sqlOpen();
            DataTable tmp = new DataTable();
            try
            {
                using (SqlDataAdapter a = new SqlDataAdapter(sSql, sqlcon))
                {
                    a.Fill(tmp);
                    return tmp;
                }
            }
            catch (Exception ex)
            {
                WriteLog(sFunctionName4Log + " Error " + ex.Message);
                return tmp;
            }
            finally
            {
                sqlClose();
            }
        }
        private void WriteLog(string sLogText)
        {
            string sLogSql = "INSERT INTO LogTbl(ModuleName, UserID, LogDate, LogText) " +
                "VALUES('DBConnect', 1, GETDATE(), '" + sLogText.Replace("'", "") + "')";
            ExecuteNonQueryStr(sLogSql, "WriteLog");
        }
        private int ExecuteNonQueryStr(string sSql, string sFunctionName4Log)
        {
            sqlcon = new SqlConnection(CommonFunctions.ConStr);
            sqlOpen();
            try
            {
                using (SqlCommand command = new SqlCommand(sSql, sqlcon))
                {
                    return command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                WriteLog(sFunctionName4Log + " Error " + ex.Message);
                return -1;
            }
            finally
            {
                sqlClose();
            }
        }
        #endregion
        private bool UpdatePhydocumenttblStatus(string sTBRNo, string sClearingType, string sUserName, string CHIBatchNo, string CXFileName, string CIBFFileName)
        {
            DataTable dtFileDetails = GetDataTableFromSqlStr("USP_UpdateCXFStatus '" + sTBRNo + "','" + sClearingType + "','" + sUserName + "','" + CHIBatchNo + "','" + CXFileName + "','" + CIBFFileName + "'", "USP_UpdateCXFStatus");
            return true;
        }
        private int GetMaxFileID()
        {
            DataTable dtGetMaxID = GetDataTableFromSqlStr("USP_GetMaxFileID ", "GetMaxFileID");
            if (dtGetMaxID.Rows.Count == 0)
                return 1;
            return Convert.ToInt16(dtGetMaxID.Rows[0][0]);
        }
        public bool CreateFiles(string sStatusName, string sClearingType, string sTBRNo, string OutputFolderPath, string sUserName, ref int iCXFCreatedItem)
        {
            #region Local Variable
            DataTable dtXML = GetDataTableFromSqlStr("USP_GetCXFDetails '" + sTBRNo + "','" + sClearingType + "','" + sUserName + "'", "USP_GetCXFDetails");
            int _batchCount = dtXML.Rows.Count;
            if (_batchCount == 0)
            {
                return false;
            }
            string sToday = GetConfigValues("Today");
            string sCXFArchivePath = GetConfigValues("CXFArchivePath");
            string strCurrentDate = string.Empty;
            string strCurrentTime = string.Empty;
            string strXmlFileLocation = string.Empty;
            string strUDK = string.Empty;
            string strImgRefData = string.Empty;
            string strImgName = string.Empty;
            int DigitalSignatureLength = 0;
            int DigitalSignatureLengthInCxf = 0;
            long lngDataLength = 0;
            long lngOffSet = 0;
            long DigitalSignatureDataOffSet = 0;
            string strImgQuality = string.Empty;
            int FileTotalCount = 0;
            string CxfFileVersion = "010005";
            MemoryStream ms, ms1;
            BinaryReader br;
            BinaryWriter bw;
            XmlTextWriter tw;
            StringBuilder sb = new StringBuilder();
            bool Return_Result = true;

            const string CreationDate = "CreationDate";
            const string CreationTime = "CreationTime";
            const string FileID = "FileID";
            const string FileIndicator = "TestFileIndicator";
            const string FileIndicatorValue = "P";
            const string ImgFileExtension = ".IMG";
            string ImgFilePrefix = "CIBF_";
            const string Urn = "urn:schemas-ncr-com:ECPIX:CXF:FileStructure:";
            const string VersionNo = "VersionNumber";
            const string XmlFileExtension = ".XML";
            const string XmlFileHeader = "FileHeader";
            string XmlFilePrefix = "CXF_";
            const string Xmlns = "xmlns";
            string Udk;
            #endregion
            IFormatProvider culture = new System.Globalization.CultureInfo("en-US", false);
            string CHIBatchNo = string.Empty;
            try
            {
                int _fileID = 0;
                if (!Directory.Exists(OutputFolderPath))
                    Directory.CreateDirectory(OutputFolderPath);

                #region Creating files as per naming convetion in RBI Specs
                _fileID = GetMaxFileID();
                strCurrentDate = DateTime.Now.ToString("ddMMyyyy", culture);
                strCurrentTime = DateTime.Now.ToString("HHmmss", culture);
                sb = sb.Remove(0, sb.Length);
                sb = sb.Append(sTBRNo).Append("_").Append(strCurrentDate).Append("_").Append(strCurrentTime);
                sb = sb.Append("_").Append(sClearingType).Append("_").Append(_fileID.ToString(culture));
                string XmlFileName = XmlFilePrefix + sb.ToString() + XmlFileExtension;
                //WriteLog(sWarning + "Creating the file " + XmlFileName);
                string ImageFileName = ImgFilePrefix + sb.ToString() + "_01" + ImgFileExtension;
                CHIBatchNo = _fileID.ToString(culture);
                #endregion
                #region CXF Header
                strXmlFileLocation = OutputFolderPath + @"\" + XmlFileName;
                tw = new XmlTextWriter(strXmlFileLocation, System.Text.Encoding.UTF8);
                tw.Formatting = Formatting.Indented;

                tw.WriteStartDocument();
                tw.WriteStartElement(XmlFileHeader);
                tw.WriteAttributeString(Xmlns, Urn.Trim() + CxfFileVersion.Trim());
                tw.WriteAttributeString(VersionNo, CxfFileVersion);
                tw.WriteAttributeString(FileIndicator, FileIndicatorValue);
                tw.WriteAttributeString(CreationDate, strCurrentDate);
                tw.WriteAttributeString(CreationTime, strCurrentTime);
                tw.WriteAttributeString(FileID, _fileID.ToString(culture));
                #endregion
                decimal TotalAmount = 0;
                FileStream objFileStream = new FileStream(OutputFolderPath + @"\" + ImageFileName, FileMode.Append);
                ms = new MemoryStream();
                DataTable dtImage;
                try
                {
                    for (int i = 0; i < dtXML.Rows.Count; i++)
                    {
                        strUDK = dtXML.Rows[i]["UDK"].ToString();
                        Udk = dtXML.Rows[i]["UDK"].ToString();
                        dtImage = GetDataTableFromSqlStr("USP_GetImageByUDK '" + strUDK + "'", "USP_GetImageByUDK");
                        if (dtImage.Rows.Count > 0)
                        {
                            #region Item Tag
                            tw.WriteStartElement("Item");
                            tw.WriteAttributeString("ItemSeqNo", dtXML.Rows[i]["ItemSeqNo"].ToString());
                            tw.WriteAttributeString("PayorBankRoutNo", dtXML.Rows[i]["SortCode"].ToString());
                            tw.WriteAttributeString("Amount", dtXML.Rows[i]["Amount"].ToString());
                            TotalAmount = Convert.ToDecimal(dtXML.Rows[i]["amount"], culture) + TotalAmount;
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["AccountNo"].ToString()))
                                tw.WriteAttributeString("AccountNo", dtXML.Rows[i]["AccountNo"].ToString());
                            tw.WriteAttributeString("SerialNo", dtXML.Rows[i]["ChequeNo"].ToString());
                            tw.WriteAttributeString("TransCode", dtXML.Rows[i]["TC"].ToString());
                            tw.WriteAttributeString("PresentingBankRoutNo", dtXML.Rows[i]["PresentingBankRNo"].ToString());
                            tw.WriteAttributeString("PresentmentDate", Convert.ToDateTime(dtXML.Rows[i]["PresentmentDate"], culture).ToString("ddMMyyyy", culture));
                            tw.WriteAttributeString("CycleNo", dtXML.Rows[i]["CycleNo"].ToString());
                            tw.WriteAttributeString("NumOfImageViews", "3");
                            tw.WriteAttributeString("ClearingType", sClearingType);
                            tw.WriteAttributeString("DocType", dtXML.Rows[i]["DocType"].ToString());
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["MICRRepairFlags"].ToString()))
                                tw.WriteAttributeString("MICRRepairFlags", dtXML.Rows[i]["MICRRepairFlags"].ToString());
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["SpecialHandling"].ToString()))
                                tw.WriteAttributeString("SpecialHandling", dtXML.Rows[i]["SpecialHandling"].ToString());
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["TruncatingRTNo"].ToString()))
                                tw.WriteAttributeString("TruncatingRTNo", dtXML.Rows[i]["TruncatingRTNo"].ToString());
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["UserField"].ToString().Trim()))
                                tw.WriteAttributeString("UserField", dtXML.Rows[i]["UserField"].ToString());
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["IgnoreIQA"].ToString()))
                                tw.WriteAttributeString("IQAIgnoreInd", Convert.ToInt32(dtXML.Rows[i]["IgnoreIQA"]).ToString());
                            tw.WriteAttributeString("CurrencyInd", "INR");
                            #endregion
                            #region AppendA Tag
                            tw.WriteStartElement("AddendA");
                            tw.WriteAttributeString("BOFDRoutNo", dtXML.Rows[i]["BOFDRoutNo"].ToString());
                            tw.WriteAttributeString("BOFDBusDate", Convert.ToDateTime(dtXML.Rows[i]["BOFDBusDate"]).ToString("ddMMyyyy"));
                            if (!string.IsNullOrEmpty(dtXML.Rows[i]["DepositorAcct"].ToString()))
                                tw.WriteAttributeString("DepositorAcct", dtXML.Rows[i]["DepositorAcct"].ToString());
                            tw.WriteAttributeString("IFSC", dtXML.Rows[i]["IFSC"].ToString());
                            tw.WriteEndElement();
                            #endregion
                            #region MICRDSTag
                            tw.WriteStartElement("MICRDS");
                            tw.WriteAttributeString("Source", dtXML.Rows[i]["Source"].ToString());
                            tw.WriteAttributeString("DigitalSignatureMethod", dtXML.Rows[i]["DigitalSignatureMethod"].ToString());
                            tw.WriteAttributeString("SecurityKeySize", dtXML.Rows[i]["SecurityKeySize"].ToString());
                            tw.WriteAttributeString("MICRFingerPrint", dtXML.Rows[i]["MICRFingerPrint"].ToString());
                            tw.WriteAttributeString("DigitalSignatureLength", dtXML.Rows[i]["SignatureData"].ToString().Length.ToString(culture));
                            tw.WriteAttributeString("SignatureData", dtXML.Rows[i]["SignatureData"].ToString());
                            if (dtXML.Rows[i]["SecurityOriginatorName"].ToString().Length <= 16)
                                tw.WriteAttributeString("SecurityOriginatorName", dtXML.Rows[i]["SecurityOriginatorName"].ToString());
                            else
                                tw.WriteAttributeString("SecurityOriginatorName", dtXML.Rows[i]["SecurityOriginatorName"].ToString().Substring(0, 15));
                            if (dtXML.Rows[i]["SecurityAuthenticatorName"].ToString().Length <= 16)
                                tw.WriteAttributeString("SecurityAuthenticatorName", dtXML.Rows[i]["SecurityAuthenticatorName"].ToString());
                            else
                                tw.WriteAttributeString("SecurityAuthenticatorName", dtXML.Rows[i]["SecurityAuthenticatorName"].ToString().Substring(0, 15));
                            if (dtXML.Rows[i]["SecurityKeyName"].ToString().Length <= 16)
                                tw.WriteAttributeString("SecurityKeyName", dtXML.Rows[i]["SecurityKeyName"].ToString());
                            else
                                tw.WriteAttributeString("SecurityKeyName", dtXML.Rows[i]["SecurityKeyName"].ToString().Substring(0, 15));
                            tw.WriteEndElement();
                            #endregion
                            #region Image
                            bw = new BinaryWriter(ms);
                            for (int j = 0; j < 3; j++)
                            {
                                #region Writing Images and DS to CIBF files
                                ms1 = new MemoryStream();
                                if (j == 0)
                                {
                                    ms1 = new MemoryStream((Byte[])dtImage.Rows[0]["BFImage"]);
                                    strImgRefData = strUDK + "BF";
                                }
                                if (j == 1)
                                {
                                    ms1 = new MemoryStream((Byte[])dtImage.Rows[0]["BRImage"]);
                                    strImgRefData = strUDK + "BR";
                                }
                                if (j == 2)
                                {
                                    ms1 = new MemoryStream((Byte[])dtImage.Rows[0]["GFImage"]);
                                    strImgRefData = strUDK + "GF";
                                }

                                br = new BinaryReader(ms1);
                                DigitalSignatureLength = Convert.FromBase64String(dtXML.Rows[i]["SignatureData"].ToString()).Length;
                                DigitalSignatureLengthInCxf = DigitalSignatureLength;
                                bw.Write(Convert.FromBase64String(dtXML.Rows[i]["SignatureData"].ToString()));
                                lngDataLength = ms1.Length;
                                bw.Write(br.ReadBytes((int)ms1.Length));
                                bw.Flush();
                                ms1.Flush();
                                ms1.Close();
                                br.Close();
                                br = null;
                                #endregion
                                #region ImageViewDetail Tag
                                tw.WriteStartElement("ImageViewDetail");
                                if (j == 0)
                                {
                                    tw.WriteAttributeString("ViewFormat", "TIFF");
                                    tw.WriteAttributeString("CompressionType", "G4");
                                    tw.WriteAttributeString("ViewSideIndicator", "Front BW");
                                }
                                else if (j == 1)
                                {
                                    tw.WriteAttributeString("ViewFormat", "TIFF");
                                    tw.WriteAttributeString("CompressionType", "G4");
                                    tw.WriteAttributeString("ViewSideIndicator", "Back BW");
                                }
                                else if (j == 2)
                                {
                                    tw.WriteAttributeString("ViewFormat", "JFIF");
                                    tw.WriteAttributeString("CompressionType", "JPEG");
                                    tw.WriteAttributeString("ViewSideIndicator", "Front Gray");
                                }
                                tw.WriteAttributeString("ViewDescriptor", "Full");
                                tw.WriteAttributeString("ImageAvailable", "Y");
                                tw.WriteAttributeString("ImageReproducable", "Y");
                                tw.WriteAttributeString("ReplacementDocIndicator", "N");
                                if (!string.IsNullOrEmpty(dtXML.Rows[i]["ImageCreatorRoutNo"].ToString()))
                                    tw.WriteAttributeString("ImageCreatorRoutNo", dtXML.Rows[i]["ImageCreatorRoutNo"].ToString());
                                tw.WriteAttributeString("ImageCreationDate", File.GetCreationTime(OutputFolderPath + @"\" + ImageFileName).ToString("ddMMyyyy"));
                                tw.WriteAttributeString("UserField", "String");
                                #endregion
                                #region ImageViewData Tag
                                tw.WriteStartElement("ImageViewData");
                                tw.WriteAttributeString("ImageDataLength", lngDataLength.ToString(culture));
                                lngOffSet += DigitalSignatureLength;
                                tw.WriteAttributeString("ImageDataOffset", lngOffSet.ToString(culture));
                                tw.WriteAttributeString("FileName", ImageFileName);
                                tw.WriteAttributeString("ImageReferenceKeyLength", strImgRefData.Length.ToString(culture));
                                tw.WriteAttributeString("ImageReferenceData", strImgRefData);
                                tw.WriteAttributeString("ClippingOrigin", "0");
                                tw.WriteEndElement();
                                #endregion
                                #region ImageDS Tag

                                tw.WriteStartElement("ImageDS");
                                tw.WriteAttributeString("Source", "Capture");
                                tw.WriteAttributeString("DigitalSignatureMethod", "RSA_with_SHA1");
                                tw.WriteAttributeString("SecurityKeySize", "1024");
                                tw.WriteAttributeString("StartOfProtectedData", lngOffSet.ToString(culture));
                                tw.WriteAttributeString("ProtectedDataLength", lngDataLength.ToString(culture));
                                tw.WriteAttributeString("DigitalSignatureDataOffset", DigitalSignatureDataOffSet.ToString(culture));
                                tw.WriteAttributeString("DigitalSignatureLength", DigitalSignatureLengthInCxf.ToString(culture));
                                tw.WriteAttributeString("FileName", ImageFileName);
                                tw.WriteAttributeString("SecurityOriginatorName", "CaptureCert1");
                                tw.WriteAttributeString("SecurityAuthenticatorName", "CaptureCert1");
                                tw.WriteAttributeString("SecurityKeyName", "127f");
                                tw.WriteEndElement();

                                lngOffSet += lngDataLength;
                                DigitalSignatureDataOffSet = lngOffSet;
                                #endregion
                                #region ImageViewAnalysis Tag

                                string ss = dtXML.Rows[i]["PartialImage"].ToString().Substring(j, 1) + dtXML.Rows[i]["ExcessiveImageSkew"].ToString().Substring(j, 1);


                                strImgQuality = dtXML.Rows[i]["PartialImage"].ToString().Substring(j, 1) + dtXML.Rows[i]["ExcessiveImageSkew"].ToString().Substring(j, 1) + dtXML.Rows[i]["PiggybackImage"].ToString().Substring(j, 1) + dtXML.Rows[i]["LightOrDark"].ToString().Substring(j, 1) + dtXML.Rows[i]["StreaksBands"].ToString().Substring(j, 1) + dtXML.Rows[i]["BelowMinimumImageSize"].ToString().Substring(j, 1) + dtXML.Rows[i]["ExceedsMaximumImageSize"].ToString().Substring(j, 1);
                                tw.WriteStartElement("ImageViewAnalysis");
                                tw.WriteAttributeString("Source", "Capture");

                                if (strImgQuality.Contains("1"))
                                    tw.WriteAttributeString("ImageQuality", "1");
                                else if (strImgQuality.Contains("2"))
                                    tw.WriteAttributeString("ImageQuality", "2");
                                else
                                    tw.WriteAttributeString("ImageQuality", "0");

                                tw.WriteAttributeString("ImageUsability", "0");
                                tw.WriteAttributeString("ImagingBankSpecificTest", "0");

                                tw.WriteAttributeString("PartialImage", dtXML.Rows[i]["PartialImage"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("ExcessiveImageSkew", dtXML.Rows[i]["ExcessiveImageSkew"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("PiggybackImage", dtXML.Rows[i]["PiggybackImage"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("LightOrDark", dtXML.Rows[i]["LightOrDark"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("Streaks-Bands", dtXML.Rows[i]["StreaksBands"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("BelowMinimumImageSize", dtXML.Rows[i]["BelowMinimumImageSize"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("ExceedsMaximumImageSize", dtXML.Rows[i]["ExceedsMaximumImageSize"].ToString().Substring(j, 1));
                                tw.WriteAttributeString("ImageEnabledPOD", "0");
                                tw.WriteAttributeString("SourceDocumentBad", "0");
                                tw.WriteAttributeString("DateUsability", "0");
                                tw.WriteAttributeString("PayeeUsability", "0");
                                tw.WriteAttributeString("ConvenienceAmountUsability", "0");
                                tw.WriteAttributeString("LegalAmountUsability", "0");
                                tw.WriteAttributeString("SignatureUsability", "0");
                                tw.WriteAttributeString("PayorNameAndAddressUsability", "0");
                                tw.WriteAttributeString("MICRLineUsability", "0");
                                tw.WriteAttributeString("MemoLineUsability", "0");
                                tw.WriteAttributeString("PayorBankNameAndAddressUsability", "0");
                                tw.WriteAttributeString("PayeeEndorsementUsability", "0");
                                tw.WriteAttributeString("BOFDEndorsementUsability", "0");
                                tw.WriteAttributeString("TransitEndorsementUsability", "0");
                                tw.WriteAttributeString("ImageAnalysisUserInformation", "0");
                                tw.WriteEndElement();
                                tw.WriteEndElement();
                                #endregion
                            }
                            #endregion
                            tw.WriteEndElement();
                            FileTotalCount++;
                        }
                        else
                        {
                            //WriteLog(sError + "Image not present for UDK :: " + Udk.ToString());
                        }
                    }
                    ms.WriteTo(objFileStream);
                    objFileStream.Flush();
                    objFileStream.Close();
                    ms.Flush();
                    ms.Close();
                }
                catch (Exception ex)
                {
                    //WriteLog(sError + "CreateFiles : " + ex.Message);
                    tw.Flush();
                    tw.Close();
                    ms.Close();
                    objFileStream.Flush();
                    objFileStream.Close();
                }
                #region FooterSummary
                tw.WriteStartElement("FileSummary");
                tw.WriteAttributeString("TotalItemCount", FileTotalCount.ToString(culture));
                tw.WriteAttributeString("TotalAmount", TotalAmount.ToString(culture));
                tw.WriteEndElement();
                tw.WriteEndDocument();
                tw.Flush();
                tw.Close();
                iCXFCreatedItem = FileTotalCount;
                if (FileTotalCount != _batchCount)
                {
                    if (File.Exists(OutputFolderPath + @"\" + XmlFileName))
                        File.Delete(OutputFolderPath + @"\" + XmlFileName);
                    if (File.Exists(OutputFolderPath + @"\" + ImageFileName))
                        File.Delete(OutputFolderPath + @"\" + ImageFileName);
                    Return_Result = false;
                }
                else
                {
                    if (UpdatePhydocumenttblStatus(sTBRNo, sClearingType, sUserName, CHIBatchNo, XmlFileName, ImageFileName))
                    {
                        FileStream objFs = new FileStream(OutputFolderPath + @"\" + XmlFileName + ".done", FileMode.Create, FileAccess.ReadWrite);
                        objFs.Close();
                        objFs = new FileStream(OutputFolderPath + @"\" + ImageFileName + ".done", FileMode.Create, FileAccess.ReadWrite);
                        objFs.Close();
                        Return_Result = true;
                        WriteLog("CXF File Created " + XmlFileName);
                        if (!Directory.Exists(sCXFArchivePath + sToday.Replace("/", "")))
                            Directory.CreateDirectory(sCXFArchivePath + sToday.Replace("/", ""));
                        string sCXFFileNameWithoutExtension = Path.GetFileNameWithoutExtension(XmlFileName);
                        if (CopyToArchivePath(sCXFFileNameWithoutExtension, OutputFolderPath, sCXFArchivePath + sToday.Replace("/", "")))
                        {
                            if (CopyToArchivePath(sCXFFileNameWithoutExtension.Replace("CXF", "CIBF"), OutputFolderPath, sCXFArchivePath + sToday.Replace("/", "")))
                            {
                                WriteLog(XmlFileName + "Copied on " + sCXFArchivePath);
                            }
                        }
                    }
                }
                #endregion
                return Return_Result;
            }
            catch (Exception exCXF)
            {
                WriteLog("Unable to create CXF " + exCXF.Message);
                iCXFCreatedItem = 0;
                return false;
            }
        }
        private bool CopyToArchivePath(string sCXFFileName, string sFilePath, string sCXFArchivePath)
        {
            string sFileNameOnly = Path.GetFileNameWithoutExtension(sFilePath + @"\" + sCXFFileName);
            string[] files = Directory.GetFiles(sFilePath, sFileNameOnly + "*.*");
            foreach (string file in files)
            {
                FileInfo file_info = new FileInfo(file);
                File.Copy(file, sCXFArchivePath + "\\" + file_info.Name);
            }
            return true;
        }
        private bool ValidateFileNamingConvention(bool bIsReturnFile, string sProcessFile)
        {
            string[] strFileParts = null;
            string[] strInnerParts = null;
            bool blnValidateResult = false;
            if (bIsReturnFile)
            {
                strFileParts = sProcessFile.Split('_');
                if (strFileParts.Length == 5)
                    blnValidateResult = true;
                else
                    blnValidateResult = false;
            }
            else
            {
                if (sProcessFile.ToUpper().EndsWith(".RES"))
                {
                    strFileParts = sProcessFile.Split('_');
                    if (strFileParts.Length == 6)
                    {
                        strInnerParts = strFileParts[strFileParts.Length - 1].Split('.');
                        if (strInnerParts.Length == 4)
                            blnValidateResult = true;
                        else
                            blnValidateResult = false;
                    }
                }
                else if (sProcessFile.ToUpper().EndsWith(".OACK"))
                {
                    strFileParts = sProcessFile.Split('_');
                    if (strFileParts.Length == 6)
                    {
                        strInnerParts = strFileParts[strFileParts.Length - 1].Split('.');
                        if (strInnerParts.Length == 5)
                            blnValidateResult = true;
                        else
                            blnValidateResult = false;
                    }
                }
            }
            return blnValidateResult;
        }
        private bool ValidateRESOACKFile(string sFileName)
        {
            DataTable dtFileProcess = GetDataTableFromSqlStr("USP_ValidateRESOACK '" + sFileName + "'", "ValidateRESOACKFile");
            return Convert.ToInt16(dtFileProcess.Rows[0]["FileProcessed"]) > 0;
        }
        public bool ProcessRES(string sFilePath, string sFileName, CHIGatewayOutwardDataContext _DBContext)
        {
            WriteLog("RES File Processing " + sFileName);
            //string strResponseFilePath = string.Empty;
            if (ValidateRESOACKFile(sFileName))
            {
                WriteLog(sFileName + " File is Already Processed...");
                return false;
            }
            DataSet dsetResponse = new DataSet();
            string strPresentmentDate = string.Empty;
            bool blnProcess = false;
            bool blnTrans = false;
            int IntRejectCount = 0;
            int IntRejectedItems = 0;
            string strUDK = string.Empty;
            int IntFtpStatus = 0;
            int IntProcessCount = 0;
            string strStatus = string.Empty;
            bool blnPhydoc = true;
            string strInputFileName = string.Empty;
            int IntIndex = 0;
            string strLogDescription = string.Empty;
            int IntCurrentFtpStatus = -1;
            DataTable dtXmlMapTbl = GetDataTableFromSqlStr("SELECT * FROM XMLConfigTbl WHERE ProcessType = 'RES'", "XMLConfigTbl_RES");

            string strFileStatus = string.Empty;
            try
            {
                if (ValidateFileNamingConvention(false, sFileName))
                {
                    DataTable dtReject = GetDataTableFromSqlStr("USP_RejectReasonStatus", "USP_RejectReasonStatus");

                    #region Downloading & Reading Response file
                    dsetResponse.ReadXml(sFilePath + sFileName);
                    if (dsetResponse.Tables["FileHeader"].Columns.Count < 6)
                    {
                        WriteLog("Invalid file. Unable to process the file " + sFileName);
                        return false;
                    }
                    IntIndex = sFileName.IndexOf('.', 0);
                    strInputFileName = sFileName.Substring(0, IntIndex + 1) + "XML";
                    #endregion

                    DataTable dtFPTStatus = GetDataTableFromSqlStr("USP_FTPStatus '" + strInputFileName + "'", "USP_FTPStatus");
                    if (dtFPTStatus.Rows.Count > 0)
                    {
                        IntRejectCount = Convert.ToInt32(dtFPTStatus.Rows[0]["rejectCount"]);
                        IntRejectedItems = Convert.ToInt32(dtFPTStatus.Rows[0]["RejectedItems"]);
                        IntCurrentFtpStatus = Convert.ToInt32(dtFPTStatus.Rows[0]["FTP_STATUS"]);
                    }
                    strFileStatus = dsetResponse.Tables["FileHeader"].Rows[0]["FileStatus"].ToString();
                    #region FileStatus = 0
                    if (strFileStatus == "0")
                    {
                        strStatus = "CHIACC";
                        blnProcess = true;
                        IntFtpStatus = 2;
                        strLogDescription = "CXF loaded successfully & all items passed validation";
                    }
                    #endregion
                    #region FileStatus = 1
                    else if (strFileStatus == "1")
                    {
                        if (IntRejectCount == 0)
                            strStatus = "CHIIFN";
                        else
                            strStatus = "CHIFRST";
                        IntFtpStatus = 4;
                        blnProcess = true;
                        strLogDescription = "CXF rejected due to invalid file name";
                    }
                    #endregion
                    #region FileStatus = 2
                    else if (strFileStatus == "2")
                    {
                        if (IntRejectCount == 0)
                            strStatus = "CHIIFF";
                        else
                            strStatus = "CHIFRST";
                        blnProcess = true;
                        IntFtpStatus = 4;
                        strLogDescription = "CXF rejected due to invalid file format";

                    }
                    #endregion
                    #region FileStatus = 3
                    else if (strFileStatus == "3")
                    {
                        if (IntRejectCount == 0)
                            strStatus = "CHIITIC";
                        else
                            strStatus = "CHIFRST";
                        blnProcess = true;
                        IntFtpStatus = 4;
                        strLogDescription = "CXF rejected due to invalid total item count";
                    }
                    #endregion
                    #region FileStatus = 4
                    else if (strFileStatus == "4")
                    {
                        if (IntRejectCount == 0)
                            strStatus = "CHIITA";
                        else
                            strStatus = "CHIFRST";
                        blnProcess = true;
                        IntFtpStatus = 4;
                        strLogDescription = "CXF rejected due to invalid amount";
                    }
                    #endregion
                    #region FileStatus = 5
                    else if (strFileStatus == "5")
                    {
                        if (IntRejectCount == 0)
                            strStatus = "CHIIIC";
                        else
                            strStatus = "CHIFRST";
                        blnProcess = true;
                        IntFtpStatus = 4;
                        strLogDescription = "CXF rejected due to invalid total no. of Image elements";
                    }
                    #endregion
                    #region FileStatus = 6
                    else if (strFileStatus == "6")
                    {
                        if (IntRejectCount == 0)
                            strStatus = "CHIIIFN";
                        else
                            strStatus = "CHIFRST";
                        IntFtpStatus = 4;
                        blnProcess = true;
                        strLogDescription = "CXF rejected due to invalid image file name";
                    }
                    #endregion
                    #region FileStatus = 7
                    else if (strFileStatus == "7")
                    {
                        blnPhydoc = false;
                        if (dsetResponse.Tables.Count >= 3)
                        {
                            if (dsetResponse.Tables["Item"].Rows.Count == Convert.ToInt32(dsetResponse.Tables["FileSummary"].Rows[0]["TotalItemCount"]))
                            {
                                string strInsertResponse = string.Empty;
                                blnProcess = true;
                                blnPhydoc = true;
                                strStatus = "CHIACC";
                                IntFtpStatus = 2;
                                #region Processing of Items in response file
                                for (int i = 0; i <= dsetResponse.Tables["Item"].Rows.Count - 1; i++)
                                {
                                    strPresentmentDate = dsetResponse.Tables["Item"].Rows[i]["PresentmentDate"].ToString();
                                    string sParamValue = string.Empty;
                                    string sParamName = string.Empty;
                                    List<SqlParameter> loSqlParametersRES = new List<SqlParameter>();

                                    foreach (DataRow drXMLMapping in dtXmlMapTbl.Rows)
                                    {
                                        if (dsetResponse.Tables[1].Columns.Contains(drXMLMapping["XMLFieldName"].ToString()))
                                        {
                                            sParamName = drXMLMapping["TableFieldName"].ToString();
                                            sParamValue = dsetResponse.Tables[1].Rows[0][drXMLMapping["XMLFieldName"].ToString()].ToString();
                                            loSqlParametersRES.Add(new SqlParameter(sParamName, sParamValue));
                                        }
                                    }
                                    loSqlParametersRES.Add(new SqlParameter("FileName", sFileName));

                                    _DBContext.Database.ExecuteSqlCommand("USP_RES_INSERT".getSql(loSqlParametersRES), loSqlParametersRES.Cast<object>().ToArray());

                                    //strInsertResponse = InsertQueryFromFile(i, sFileName);
                                    try
                                    {
                                        #region Insert into ResponseTbl
                                        //sqlcom1.CommandType = CommandType.Text;
                                        //sqlcom1.CommandText = strInsertResponse;
                                        //sqlcom1.ExecuteNonQuery();
                                        string strItemSeqNo;
                                        #endregion
                                        #region Update Phydocumenttbl status
                                        strUDK = dsetResponse.Tables["Item"].Rows[i]["PresentmentDate"].ToString() + dsetResponse.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString().PadLeft(9, '0') + dsetResponse.Tables["Item"].Rows[i]["CycleNo"].ToString().PadLeft(2, '0') + dsetResponse.Tables["Item"].Rows[i]["ItemSeqNo"].ToString().PadLeft(14, '0');
                                        strItemSeqNo = dsetResponse.Tables["Item"].Rows[i]["ItemSeqNo"].ToString().PadLeft(14, '0');
                                        DataRow[] drRejectReason = dtReject.Select("RejectReasonCode = " + Convert.ToInt32(dsetResponse.Tables["Item"].Rows[i]["RejectReason"]));
                                        string strRejectStatus = string.Empty;
                                        if (drRejectReason.Length > 0)
                                            strRejectStatus = drRejectReason[0]["Status"].ToString();
                                        else
                                            strRejectStatus = "CHIIRRC";
                                        

                                        strPresentmentDate = strPresentmentDate.Insert(2, "/");
                                        strPresentmentDate = strPresentmentDate.Insert(5, "/");
                                        //USP_UpdateRESStatus
                                        List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                                        loSqlParameters.Add(new SqlParameter("ItemSeqNo", strItemSeqNo.handleDBNull()));
                                        loSqlParameters.Add(new SqlParameter("UDK", strUDK.handleDBNull()));
                                        loSqlParameters.Add(new SqlParameter("RejectStatus", strRejectStatus.handleDBNull()));
                                        loSqlParameters.Add(new SqlParameter("PresentmentDate", strPresentmentDate.handleDBNull()));
                                        loSqlParameters.Add(new SqlParameter("FileName", sFileName.handleDBNull()));
                                        loSqlParameters.Add(new SqlParameter("CHICode", dsetResponse.Tables["Item"].Rows[i]["RejectReason"].ToString().handleDBNull()));
                                        loSqlParameters.Add(new SqlParameter("CXFileName", strInputFileName));
                                        loSqlParameters.Add(new SqlParameter("RESFileStatusID", "7"));
                                        _DBContext.Database.ExecuteSqlCommand("USP_UpdateRESStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                                    }
                                    catch (Exception exResp1)
                                    {
                                        WriteLog("Unable to process the file " + sFileName + " Error " + exResp1.Message);
                                        blnProcess = false;
                                        break;
                                    }
                                }
                                #endregion
                            }
                            else
                            {
                                WriteLog("TotalItemCount field in FileSummary does not match with the total count of all items in the file. \n\rUnable to process the file " + sFileName);
                                blnProcess = false;
                            }
                        }
                        else
                        {
                            WriteLog("Invalid response file format. Hence unable to process the file " + sFileName);
                            blnProcess = false;
                        }
                    }
                    #endregion
                    #region Updating Phydocumenttbl and ItemProcessDetailTbl table
                    if (blnPhydoc)
                    {
                        List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                        loSqlParameters.Add(new SqlParameter("ItemSeqNo", "0"));
                        loSqlParameters.Add(new SqlParameter("UDK", "0"));
                        loSqlParameters.Add(new SqlParameter("RejectStatus", strStatus.handleDBNull()));
                        loSqlParameters.Add(new SqlParameter("PresentmentDate", ""));
                        loSqlParameters.Add(new SqlParameter("FileName", sFileName.handleDBNull()));
                        loSqlParameters.Add(new SqlParameter("CHICode", "0"));
                        loSqlParameters.Add(new SqlParameter("CXFileName", strInputFileName));
                        loSqlParameters.Add(new SqlParameter("RESFileStatusID", "0"));
                        _DBContext.DBSet_ResProcessStatusUDK.FromSql("USP_UpdateRESStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                        #endregion
                    }
                    #endregion
                    #region Updating DownloadedFileSummary and FTP_Status table
                    if (blnProcess)
                    {

                        #region Update DownloadedFileSummary Table
                        if (strFileStatus == "7")
                            IntProcessCount = IntProcessCount + IntRejectedItems;
                        if (IntCurrentFtpStatus >= 3)
                            IntFtpStatus = IntCurrentFtpStatus;

                        List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                        loSqlParameters.Add(new SqlParameter("FileName", strInputFileName.handleDBNull()));
                        loSqlParameters.Add(new SqlParameter("TotalCount", IntProcessCount.handleDBNull()));
                        loSqlParameters.Add(new SqlParameter("FTPStatus", IntFtpStatus.handleDBNull()));
                        loSqlParameters.Add(new SqlParameter("RejectedItems", IntRejectedItems.handleDBNull()));
                        loSqlParameters.Add(new SqlParameter("RESFileStatusID", "0"));
                        _DBContext.DBSet_ResProcessStatusUDK.FromSql("USP_UpdateRESFileStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                        #endregion
                        WriteLog("Successfully processed the file " + sFileName);
                    }
                    #endregion
                }
                else
                {
                    WriteLog("Invalid file naming convetion. \n\rUnable to process the file " + sFileName);
                    blnProcess = false;
                }
            }
            catch (Exception exResp)
            {
                if (blnTrans)
                {
                    WriteLog("Exception occured data roll back done Error " + exResp.Message);
                }
                WriteLog("ProcessResponseFile Error " + exResp.Message);
            }
            finally
            {
                #region Moving files to Archive ResponseFile folder
                string ArchiveFolderPath = GetConfigValues("OUTPUTFILEPATH");
                try
                {
                    if (!Directory.Exists(ArchiveFolderPath + @"\ResponseFiles"))
                        Directory.CreateDirectory(ArchiveFolderPath + @"\ResponseFiles");
                    if (blnProcess)
                        File.Move(sFilePath + sFileName, ArchiveFolderPath + @"\ResponseFiles\" + sFileName + ".DONE." + DateTime.Now.ToString("ddMMyyyy") + "_" + DateTime.Now.ToString("HHmmss"));
                    else
                        File.Move(sFilePath + sFileName, ArchiveFolderPath + @"\ResponseFiles\" + sFileName + ".BAD." + DateTime.Now.ToString("ddMMyyyy") + "_" + DateTime.Now.ToString("HHmmss"));
                }
                catch (Exception ex)
                {
                    WriteLog("Unable to Create archive folder for ResponseFiles " + ArchiveFolderPath + "-" + ex.Message);
                }
                #endregion
            }
            return blnProcess;
        }
        public bool ProcessOACK(string sFilePath, string sFileName, CHIGatewayOutwardDataContext _DBContext)
        {
            int iErrorCode = 0;
            WriteLog("OACK Process " + sFileName);
            if (ValidateRESOACKFile(sFileName))
            {
                WriteLog(sFileName + " File is Already Processed...");
                return false;
            }
            string _DateFormat = "dd/MM/yyyy";
            DataSet dsetOACK = new DataSet();
            string strPresentmentDate = string.Empty;
            string strSettlmentDate = string.Empty;
            string strSessionDate = string.Empty;
            bool blnProcess = false;
            int IntProcessCount = 0;
            bool blnTrans = false;

            string strUDK = string.Empty;
            int IntIndex = 0;
            string sNewItemSeqNo = string.Empty;
            string strInputFileName = string.Empty;
            DataTable dtXmlMapTbl = GetDataTableFromSqlStr("SELECT * FROM XMLConfigTbl WHERE ProcessType = 'OACK'", "XMLConfigTbl_OACK");
            iErrorCode = 1;
            try
            {
                if (ValidateFileNamingConvention(false, sFileName))
                {
                    #region Reading the OACK file into dataset
                    dsetOACK.ReadXml(sFilePath + sFileName);
                    iErrorCode = 2;
                    IntIndex = sFileName.IndexOf('.', 0);
                    strInputFileName = sFileName.Substring(0, IntIndex + 1) + "XML";
                    #endregion
                    if (dsetOACK.Tables.Count >= 3)
                    {
                        iErrorCode = 3;
                        if (dsetOACK.Tables["Item"].Rows.Count == Convert.ToInt32(dsetOACK.Tables["FileSummary"].Rows[0]["TotalItemCount"]))
                        {
                            blnTrans = true;
                            string strInsertOACK = string.Empty;
                            strSessionDate = dsetOACK.Tables["FileHeader"].Rows[0]["SessionDate"].ToString().Substring(0, 2) + "/" + dsetOACK.Tables["FileHeader"].Rows[0]["SessionDate"].ToString().Substring(2, 2) + "/" + dsetOACK.Tables["FileHeader"].Rows[0]["SessionDate"].ToString().Substring(4);
                            strSettlmentDate = dsetOACK.Tables["FileHeader"].Rows[0]["SettlementDate"].ToString().Substring(0, 2) + "/" + dsetOACK.Tables["FileHeader"].Rows[0]["SettlementDate"].ToString().Substring(2, 2) + "/" + dsetOACK.Tables["FileHeader"].Rows[0]["SettlementDate"].ToString().Substring(4);
                            string sSessionNo = dsetOACK.Tables["FileHeader"].Rows[0]["SessionNumber"].ToString();
                            blnProcess = true;
                            iErrorCode = 4;
                            #region Processing of items in OACK file
                            for (int i = 0; i <= dsetOACK.Tables["Item"].Rows.Count - 1; i++)
                            {
                                strPresentmentDate = dsetOACK.Tables["Item"].Rows[i]["PresentmentDate"].ToString();
                                strPresentmentDate = strPresentmentDate.Insert(2, "/");
                                strPresentmentDate = strPresentmentDate.Insert(5, "/");
                                iErrorCode = 5;
                                List<SqlParameter> loSqlParametersRES = new List<SqlParameter>();
                                loSqlParametersRES.Add(new SqlParameter("ItemSeqNo", dsetOACK.Tables["Item"].Rows[i]["ItemSeqNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("PresentingBankRtNo", dsetOACK.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("PresentmentDate", strPresentmentDate));
                                loSqlParametersRES.Add(new SqlParameter("CycleNo", dsetOACK.Tables["Item"].Rows[i]["CycleNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("SessionNo", sSessionNo));
                                loSqlParametersRES.Add(new SqlParameter("SettlementDate", strSettlmentDate));
                                loSqlParametersRES.Add(new SqlParameter("SessionDate", strSessionDate));
                                loSqlParametersRES.Add(new SqlParameter("ItemStatus", dsetOACK.Tables["Item"].Rows[i]["ItemStatus"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("FileName", sFileName));
                                iErrorCode = 6;
                                _DBContext.Database.ExecuteSqlCommand("USP_OACK_INSERT".getSql(loSqlParametersRES), loSqlParametersRES.Cast<object>().ToArray());
                                iErrorCode = 7;

                                try
                                {
                                    #region Update Phydocumenttbl status
                                    strUDK = dsetOACK.Tables["Item"].Rows[i]["PresentmentDate"].ToString() + dsetOACK.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString().PadLeft(9, '0') + dsetOACK.Tables["Item"].Rows[i]["CycleNo"].ToString().PadLeft(2, '0') + dsetOACK.Tables["Item"].Rows[i]["ItemSeqNo"].ToString().PadLeft(14, '0');
                                    iErrorCode = 8;
                                    List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                                    loSqlParameters.Add(new SqlParameter("SessionID", Convert.ToInt32(dsetOACK.Tables["FileHeader"].Rows[0]["SessionNumber"].handleDBNull())));
                                    loSqlParameters.Add(new SqlParameter("SessionDate", DateTime.ParseExact(strSessionDate, _DateFormat, null)));
                                    loSqlParameters.Add(new SqlParameter("SettlementDate", DateTime.ParseExact(strSettlmentDate, _DateFormat, null)));
                                    loSqlParameters.Add(new SqlParameter("ItemStatus", dsetOACK.Tables["Item"].Rows[i]["ItemStatus"].ToString()));
                                    loSqlParameters.Add(new SqlParameter("UDK", strUDK.handleDBNull()));
                                    loSqlParameters.Add(new SqlParameter("ItemSeqNo", dsetOACK.Tables["Item"].Rows[i]["ItemSeqNo"].ToString()));
                                    loSqlParameters.Add(new SqlParameter("FileName", sFileName.handleDBNull()));
                                    iErrorCode = 9;
                                    _DBContext.Database.ExecuteSqlCommand("USP_UpdateOACKStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                                    iErrorCode = 10;
                                    #endregion
                                }
                                catch (Exception exOack1)
                                {
                                    WriteLog("Unable to process the file " + sFileName + " Error " + exOack1.Message + " Error Code " + iErrorCode.ToString());
                                    blnProcess = false;
                                    break;
                                }
                            }
                            #endregion
                            #region Updating DownloadedFileSummary & FTP_Status table
                            if (blnProcess)
                            {
                                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                                loSqlParameters.Add(new SqlParameter("FileName", sFileName.handleDBNull()));
                                loSqlParameters.Add(new SqlParameter("TotalCount", dsetOACK.Tables["Item"].Rows.Count));
                                loSqlParameters.Add(new SqlParameter("FTPStatus", "3"));
                                loSqlParameters.Add(new SqlParameter("AcceptedItems", IntProcessCount.handleDBNull()));
                                loSqlParameters.Add(new SqlParameter("RESFileStatusID", "0"));
                                _DBContext.Database.ExecuteSqlCommand("USP_UpdateOACKFileStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                                WriteLog("Successfully processed the file " + sFileName);
                            }
                            #endregion
                        }
                        else
                        {
                            WriteLog("TotalItemCount field in FileSummary does not match with the total count of all items in the file. \n\rUnable to process the file " + sFileName);
                            blnProcess = false;
                        }
                    }
                    else
                    {
                        WriteLog("Invalid OACK file format. Hence unable to process the file " + sFileName);
                        blnProcess = false;
                    }
                }
                else
                {
                    WriteLog("Invalid file naming convetion. Unable to process the file " + sFileName);
                    blnProcess = false;
                }
            }
            catch (Exception exOack)
            {
                WriteLog("ProcessOACKFile " + exOack.Message);
                blnProcess = false;
            }
            finally
            {
                #region Moving files to Archive OACKFile folder
                string ArchiveFolderPath = GetConfigValues("OUTPUTFILEPATH");
                try
                {
                    if (!Directory.Exists(ArchiveFolderPath + @"\OACKFiles"))
                        Directory.CreateDirectory(ArchiveFolderPath + @"\OACKFiles");
                    if (blnProcess)
                        File.Move(sFilePath + sFileName, ArchiveFolderPath + @"\OACKFiles\" + sFileName + ".DONE." + DateTime.Now.ToString("ddMMyyyy") + "_" + DateTime.Now.ToString("HHmmss"));
                    else
                        File.Move(sFilePath + sFileName, ArchiveFolderPath + @"\OACKFiles\" + sFileName + ".BAD." + DateTime.Now.ToString("ddMMyyyy") + "_" + DateTime.Now.ToString("HHmmss"));
                }
                catch (Exception ex)
                {
                    WriteLog("Unable to Create archive folder for OACKFiles " + ArchiveFolderPath + "-" + ex.Message);
                }
                #endregion
            }
            return blnProcess;
        }
        public bool ProcessRF(string sFilePath, string sFileName, CHIGatewayOutwardDataContext _DBContext)
        {
            int iErrorCode = 0;
            WriteLog("Return File Processing " + sFileName);
            if (ValidateRESOACKFile(sFileName))
            {
                WriteLog(sFileName + " File is Already Processed...");
                return false;
            }
            iErrorCode = 1;
            DataSet dsetRtn = new DataSet();
            DataSet dsetDownloadFile = new DataSet();
            //DataTable dtXmlMapTbl;
            string strPresentmentDate = string.Empty;
            string strBOFDBusDate = string.Empty;
            string strRtnFilePath = string.Empty;
            bool blnProcess = false;
            bool blnTrans = false;
            int iOutputStatus = 0;
            iOutputStatus = GetDocumentStatus("CHIRESTATUS");
            int iPaperStatus = 0;
            iPaperStatus = GetDocumentStatus("CHIREPAPER");
            try
            {
                iErrorCode = 2;
                if (ValidateFileNamingConvention(true, sFileName))
                {
                    iErrorCode = 3;
                    #region Reading Return file
                    strRtnFilePath = sFilePath + sFileName;
                    dsetDownloadFile.ReadXml(strRtnFilePath);
                    dsetRtn.ReadXml(strRtnFilePath);
                    #endregion
                    //Validating mandatory table in return files
                    if (dsetRtn.Tables.Count >= 4)
                    {
                        iErrorCode = 4;

                        //Validating total item count in the table with the value in the File summary item counts
                        if (dsetRtn.Tables["Item"].Rows.Count == Convert.ToInt32(dsetRtn.Tables["FileSummary"].Rows[0]["TotalItemCount"]))
                        {
                            blnTrans = true;
                            string strInsertRtn = string.Empty;
                            string strUDK = string.Empty;
                            string strDocType = string.Empty;
                            string sReturnReasonComment = string.Empty;
                            
                            blnProcess = true;                    
                            
                            string strItemSeqNo = string.Empty;
                            string strPresentingBankRtNo = string.Empty;
                            bool blnDuplicate = false;
                            string RetComments = string.Empty;
                            iErrorCode = 5;

                            #region Processsing of items in return file
                            for (int i = 0; i <= dsetRtn.Tables["Item"].Rows.Count - 1; i++)
                            {
                                strItemSeqNo = dsetRtn.Tables["Item"].Rows[i]["ItemSeqNo"].ToString().PadLeft(14, '0');
                                strPresentmentDate = dsetRtn.Tables["Item"].Rows[i]["PresentmentDate"].ToString();
                                strPresentmentDate = strPresentmentDate.Insert(2, "/");
                                strPresentmentDate = strPresentmentDate.Insert(5, "/");
                                strPresentingBankRtNo = dsetRtn.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString();

                                strBOFDBusDate = dsetRtn.Tables["AddendA"].Rows[i]["BOFDBusDate"].ToString();
                                strBOFDBusDate = strBOFDBusDate.Insert(2, "/");
                                strBOFDBusDate = strBOFDBusDate.Insert(5, "/");

                                string sParamValue = string.Empty;
                                string sParamName = string.Empty;
                                List<SqlParameter> loSqlParametersRES = new List<SqlParameter>();
 
                                iErrorCode = 6;

                                loSqlParametersRES.Add(new SqlParameter("ItemSeqNo", strItemSeqNo));
                                loSqlParametersRES.Add(new SqlParameter("PayorBankRtNo", dsetRtn.Tables["Item"].Rows[i]["PayorBankRoutNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("Amount", dsetRtn.Tables["Item"].Rows[i]["Amount"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("AccountNo", dsetRtn.Tables["Item"].Rows[i]["AccountNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("SerialNo", dsetRtn.Tables["Item"].Rows[i]["SerialNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("TransCode", dsetRtn.Tables["Item"].Rows[i]["TransCode"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("PresentingBankRtNo", dsetRtn.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("PresentmentDate", strPresentmentDate));
                                loSqlParametersRES.Add(new SqlParameter("CycleNo", dsetRtn.Tables["Item"].Rows[i]["CycleNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("ClearingType", dsetRtn.Tables["Item"].Rows[i]["ClearingType"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("ReturnReasonCode", dsetRtn.Tables["Item"].Rows[i]["ReturnReason"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("BOFDRtNo", dsetRtn.Tables["AddendA"].Rows[i]["BOFDRoutNo"].ToString()));
                                loSqlParametersRES.Add(new SqlParameter("BOFDBusDate", strBOFDBusDate));
                                loSqlParametersRES.Add(new SqlParameter("DepositorAcct", dsetRtn.Tables["AddendA"].Rows[i]["DepositorAcct"].ToString()));
                                sReturnReasonComment = string.Empty;
                                if (dsetRtn.Tables["AddendA"].Columns.Contains("ReturnReasonComment"))
                                {
                                    sReturnReasonComment = dsetRtn.Tables["AddendA"].Rows[i]["ReturnReasonComment"].ToString();
                                }
                                loSqlParametersRES.Add(new SqlParameter("ReturnReasonComment", sReturnReasonComment));
                                loSqlParametersRES.Add(new SqlParameter("FileName", sFileName));
                                iErrorCode = 7;

                                _DBContext.Database.ExecuteSqlCommand("USP_RF_INSERT".getSql(loSqlParametersRES), loSqlParametersRES.Cast<object>().ToArray());
                                iErrorCode = 8;

                                blnDuplicate = false;
                                blnProcess = false;
                                try
                                {
                                    iErrorCode = 9;

                                    strUDK = dsetRtn.Tables["Item"].Rows[i]["PresentmentDate"].ToString() + dsetRtn.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString().PadLeft(9, '0') + dsetRtn.Tables["Item"].Rows[i]["CycleNo"].ToString().PadLeft(2, '0') + dsetRtn.Tables["Item"].Rows[i]["ItemSeqNo"].ToString().PadLeft(14, '0');
                                    if (dsetRtn.Tables["Item"].Columns.Contains("ReturnReasonComment"))
                                        RetComments = Convert.ToString(dsetRtn.Tables["Item"].Rows[i]["ReturnReasonComment"]);
                                    string sReasonCode = dsetRtn.Tables["Item"].Rows[i]["ReturnReason"].ToString();
                                    List<SqlParameter> loSqlParametersRFStatus = new List<SqlParameter>();
                                    loSqlParametersRFStatus.Add(new SqlParameter("UDK", strUDK));
                                    loSqlParametersRFStatus.Add(new SqlParameter("ItemSeqNo", strItemSeqNo));
                                    loSqlParametersRFStatus.Add(new SqlParameter("ReasonCode", sReasonCode));
                                    loSqlParametersRFStatus.Add(new SqlParameter("ReturnReasonComment", RetComments));
                                    loSqlParametersRFStatus.Add(new SqlParameter("Status", iOutputStatus));
                                    loSqlParametersRFStatus.Add(new SqlParameter("PaperStatus", iPaperStatus));
                                    loSqlParametersRFStatus.Add(new SqlParameter("PresentmentDate", strPresentmentDate));
                                    loSqlParametersRFStatus.Add(new SqlParameter("PresentingBankRtNo", dsetRtn.Tables["Item"].Rows[i]["PresentingBankRoutNo"].ToString().PadLeft(9, '0')));
                                    loSqlParametersRFStatus.Add(new SqlParameter("FileName", sFileName));
                                    iErrorCode = 10;

                                    _DBContext.Database.ExecuteSqlCommand("USP_UpdateRFStatus".getSql(loSqlParametersRFStatus), loSqlParametersRFStatus.Cast<object>().ToArray());
                                    iErrorCode = 11;
                                    blnProcess = true;
                                }
                                catch (Exception exRtn1)
                                {
                                    WriteLog("Unable to process the file " + sFileName + " Error " + exRtn1.Message + " Error Code " + iErrorCode.ToString());
                                    blnProcess = false;
                                    break;
                                }
                            }
                            #endregion
                            #region Updating DownloadedFileSummary table
                            if (blnProcess)
                            {
                                #region Update DownloadedFileSummary Table
                                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                                loSqlParameters.Add(new SqlParameter("FileName", sFileName.handleDBNull()));
                                loSqlParameters.Add(new SqlParameter("TotalCount", dsetRtn.Tables["Item"].Rows.Count));
                                _DBContext.Database.ExecuteSqlCommand("USP_UpdateRFFileStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                                WriteLog("Successfully process the file " + sFileName);
                                #endregion
                            }
                            #endregion
                        }
                        else
                        {
                            WriteLog("Error: TotalItemCount field in FileSummary does not match with the total count of all items in the file. Unable to process the file " + sFileName);
                            blnProcess = false;
                        }
                    }
                    else
                    {
                        WriteLog("Error: Invalid return file format. Hence unable to process the file " + sFileName);
                        blnProcess = false;
                    }
                }
                else
                {
                    WriteLog("Error: Invalid file naming convetion. Unable to process the file " + sFileName);
                    blnProcess = false;
                }
            }
            catch (Exception exRtn)
            {
                WriteLog("ProcessReturnFile Error" + exRtn.Message);
                blnProcess = false;
            }
            finally
            {
                #region Moving Files to Archive ReturnFiles folder
                string ArchiveFolderPath = GetConfigValues("OUTPUTFILEPATH");
                try
                {
                    if (!Directory.Exists(ArchiveFolderPath + @"\ReturnFiles"))
                        Directory.CreateDirectory(ArchiveFolderPath + @"\ReturnFiles");
                    if (blnProcess)
                        File.Move(sFilePath + sFileName, ArchiveFolderPath + @"\ReturnFiles\" + sFileName + ".DONE." + DateTime.Now.ToString("ddMMyyyy") + "_" + DateTime.Now.ToString("HHmmss"));
                    else
                        File.Move(sFilePath + sFileName, ArchiveFolderPath + @"\ReturnFiles\" + sFileName + ".BAD." + DateTime.Now.ToString("ddMMyyyy") + "_" + DateTime.Now.ToString("HHmmss"));
                }
                catch (Exception ex)
                {
                    WriteLog("Unable to Create archive folder for ReturnFiles " + ArchiveFolderPath + "-" + ex.Message);
                }
                #endregion
            }
            return blnProcess;
        }
    }
}
