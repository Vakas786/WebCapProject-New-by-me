﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;
using CtsWebCoreOutward.ViewModel;
using Microsoft.EntityFrameworkCore;
using CtsWebCoreOutward.Filter;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Models
{
    public class DataEntryDataContext : DbContext
    {
        public DataEntryDataContext(DbContextOptions<DataEntryDataContext> options)
            : base(options)
        { }

        public DbSet<DataEntryViewModel.ModuleFields> DBSet_ModuleFields { get; set; }
        public DbSet<DataEntryViewModel.CityMaster> DBSet_CityMaster { get; set; }
        public DbSet<DataEntryViewModel.BankMaster> DBSet_BankMaster { get; set; }
        public DbSet<DataEntryViewModel.BranchMaster> DBSet_BranchMaster { get; set; }
        public DbSet<DataEntryViewModel.TransactionCodeMaster> DBSet_TransactionCodeMaster { get; set; }
        public DbSet<DataEntryViewModel.ChequeImage> DBSet_ChequeImage { get; set; }
        public DbSet<DataEntryViewModel.NextBatchDetails> DBSet_NextBatchDetails { get; set; }
        public DbSet<DataEntryViewModel.ReturnReasonMaster> DBSet_ReturnReasonMaster { get; set; }
        public DbSet<DataEntryViewModel.RecordTypeValidationDetails> DBSet_RecordTypeValidationDetails { get; set; }
        public DbSet<DataEntryViewModel.DocSearchCriteria> DBSet_DocSearchCriteria { get; set; }
        public DbSet<DataEntryViewModel.BatchCurrentStatus> DBSet_BatchCurrentStatus { get; set; }
        public DbSet<DataEntryViewModel.AllChequeImage> DBSet_AllChequeImage { get; set; }
        public DbSet<DataEntryViewModel.BatchDetails> DBSet_BatchDetails { get; set; }
        public DbSet<DataEntryViewModel.BatchGridColumns> DBSet_BatchGridColumns { get; set; }
        //public DbSet<DataEntryViewModel.WrapperDataEntry> DBSet_WrapperDataEntry { get; set; }
        public DbSet<DataEntryViewModel.BatchGridColumnsString> DBSet_BatchGridColumnsString { get; set; }
        public DbSet<DataEntryViewModel.RecordTypeFromDB> DBSet_RecordTypeFromDB { get; set; }
        public DbSet<DataEntryViewModel.CheckDetails> DBSet_CheckDetails { get; set; }
        public DbSet<PermissionMaster> DBSet_PermissionMaster { get; set; }

        public DbSet<BatchSelectionGridColumnsString> DBSet_BatchSelectionGridColumnsString { get; set; }

        public DbSet<FuntionSP> DBSet_FuntionSP { get; set; }
        public DbSet<VerifierUpdate> DBSet_Verifier { get; set; }

        public DbSet<DataEntryViewModel.AccountDetails> DBSet_AccountDetails { get; set; }
    }
}