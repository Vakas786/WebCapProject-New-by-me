﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.ScannerInfoViewModel ;

namespace CtsWebCoreOutward.Models
{
    public class ScannerInfoDataContext : DbContext
    {
        public ScannerInfoDataContext(DbContextOptions<ScannerInfoDataContext> options)
            : base(options)
        { }

        public DbSet<ScannerInfo> DBSet_Scanner { get; set; }

    }
}