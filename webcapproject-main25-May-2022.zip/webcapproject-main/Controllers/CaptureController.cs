﻿using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class CaptureController : Controller
    {
        
        public static IConfiguration _configuration;
        #region NORMAL VARIABLE
        DataTable dtPhyDoc4Show;
        DataTable dtPhyDocumentTbl;
        DataTable dtAppConfig = new DataTable();
        DataTable dtClearingType;
        DataTable dtBranchMaster;
        DataTable dtIQAFieldDefTbl;


        int iSeqStep = 10;
        int iSeqNo = 0;
        private byte[] bRequiredImg;
        private byte[] bNotRequiredImg;
        private byte[] bFailedImg;
        private byte[] bSuspectImg;
        public string sIQAStatus;
        private byte[] bDefaultImg;
        MemoryStream msDefaultImage = new MemoryStream();
        string sImgReCapture = string.Empty;
        string sReCapImg = string.Empty;
        bool bReCapture = false;
        bool bShowNewImage = false;
        //PROOFSET pSetCapture;
        //DOCUMENTINFO dInfoCapture;
        int iDefaultDistribution;

        string sPBRN;
        public static string sTBRN;
        public static string sBOFD;
        string sIFSC;
        string sPhBRNo;
        string sSolID;
        public static string sToday;
        public static string sRCFileExtension = "*.*";
        public static string sRCFilePath = "";
        public string sSorterID = string.Empty;
        public static string sSorter = string.Empty;
        private string sBatchNo = "0";
        private string sBlockNo = "0";
        int iPendingCaptureCount = 100;
        int iScannedCount = 0;
        int iSlipCount = 0;
        int iTotalCount = 0;
        bool bDuplInstFound = false;
        #endregion
        //
        // GET: /Capture/Capture/
        public CaptureController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public ActionResult Capture(int? id)
        {
            try
            {
                int iFuntionNumber = 10;
                if (id != null)
                {
                    iFuntionNumber = Convert.ToInt16(id);
                }
                return View();
            }
            catch (Exception)
            {
                return null;

            }
        }
        public JsonResult DataSendToRemotingServer(string sGFImg, string sBFImg, string sBRImg, string iUID, string sMICR)
        {
            var sSorterID = "HP-PC";
            //DataSendToRemotingServer DataSendToRemotingServerobj = new DataSendToRemotingServer();
            //DataSendToRemotingServerobj = JsonConvert.DeserializeObject<DataSendToRemotingServer>(data);

            DataTable dtSorterInfo = GetDataTableFromSqlStr("SELECT SorterNo FROM MachineInfo WITH(NOLOCK) WHERE SorterID = '" + sSorterID + "'", "SorterInfo");
            FinvergeCaptureSystem objfcs = new FinvergeCaptureSystem();
            if (dtSorterInfo.Rows.Count > 0)
            {
                sSorter = dtSorterInfo.Rows[0]["SorterNo"].ToString();
                DataTable dtBatchInfo = GetDataTableFromSP("CMSP_GetBatchInfo", "SorterNo", sSorter, "", "GetBatchInfo");
                if (dtBatchInfo.Rows.Count > 0)
                {
                    //objfcs.seqno = dtBatchInfo.Rows[0]["BatchNo"].ToString();
                    objfcs.iqa = "iqa";
                    objfcs.instrutype = "instr type";
                    objfcs.Chequenumber = "chequenumber";
                    objfcs.shortercode = "shortercode";
                    objfcs.basenumber = "basenumber";
                    objfcs.Tc = "tc";
                    objfcs.deleted = "deleted";
                }
            }
            //    if (sGFImg != null)
            //{
            //    return Json("Success");
            //}
            return Json(objfcs);
        }

        //public string DataSendToRemotingServer(string data)
        //{
        //    DataSendToRemotingServer DataSendToRemotingServerobj = new DataSendToRemotingServer();
        //    DataSendToRemotingServerobj = JsonConvert.DeserializeObject<DataSendToRemotingServer>(data);
        //    if (DataSendToRemotingServerobj != null)
        //    {

        //        return "Success";
        //    }

        //    return "There must be at least one country.";

        //}

        public JsonResult GetSorterNo(string sSorterID)
        {
            DataTable dtSorterInfo = GetDataTableFromSqlStr("SELECT SorterNo FROM MachineInfo WITH(NOLOCK) WHERE SorterID = '" + sSorterID + "'", "SorterInfo");
            FinvergeCaptureSystem objfcs = new FinvergeCaptureSystem();
            if (dtSorterInfo.Rows.Count > 0)
            {
                sSorter = dtSorterInfo.Rows[0]["SorterNo"].ToString();
                DataTable dtBatchInfo = GetDataTableFromSP("CMSP_GetBatchInfo", "SorterNo", sSorter, "", "GetBatchInfo");
                if (dtBatchInfo.Rows.Count > 0)
                {
                    objfcs.BatchNo = dtBatchInfo.Rows[0]["BatchNo"].ToString();
                    objfcs.BlockNo = dtBatchInfo.Rows[0]["BlockNo"].ToString();
                    objfcs.Bofd = dtBatchInfo.Rows[0]["BOFD"].ToString();
                    objfcs.ChequeCount = dtBatchInfo.Rows[0]["ChequeCount"].ToString();
                    objfcs.SlipCount = dtBatchInfo.Rows[0]["SlipCount"].ToString();
                    objfcs.SorterNo = sSorter;
                    //sPBRN = dtBatchInfo.Rows[0]["PBRN"].ToString();
                    //sTBRN = dtBatchInfo.Rows[0]["TBRN"].ToString();
                    //  DataRow[] drBranchName = ((DataTable)cmbBranch.DataSource).Select("BOFD= '" + dtBatchInfo.Rows[0]["BOFD"].ToString() + "'");
                    //if (drBranchName.Length > 0)
                    //{
                    //    int iIndex = cmbBranch.FindString(drBranchName[0]["BranchName"].ToString());
                    //    cmbBranch.SelectedIndex = iIndex;
                    //}


                    //txtChequeCount.Text = dtBatchInfo.Rows[0]["ChequeCount"].ToString();
                    //txtCTPBatchNo.Text = dtBatchInfo.Rows[0]["CTPBatchNo"].ToString();

                    //iScannedCount = Convert.ToInt16(dtBatchInfo.Rows[0]["CapturedCount"]);
                    //iTotalCount = Convert.ToInt16(dtBatchInfo.Rows[0]["ChequeCount"]);
                    //iSlipCount = Convert.ToInt16(dtBatchInfo.Rows[0]["SlipCount"]);
                }
                //ShowInfo();
                //PnlRC.Enabled = sBlockNo == "0";
                return Json(objfcs);

                //return "true";
            }
            else
            {
                // MessageBox.Show("Scanner Serial No is not configured..." + sSorterID);
            }
            return Json(objfcs);
        }

        public int GetInstrumentCount(string sSorterNo, string sBlockno, int iSeqNo)
        {
            object obj = null;
            int iInstCount = -1;
            string sToday = GetToday();
            string sql;
            try
            {
                iSeqNo = -1;
                sql = "SET DateFormat DMY ; SELECT IsNull(MAX(SequenceNo),0) As SeqNo " +
                        " FROM InstrumentDtl Phy WITH(NOLOCK) " +
                        " WHERE ChequeDate = '" + sToday + "'" +
                        " AND SorterNo = '" + sSorterNo + "'";
                obj = ExecuteScalarStrWithParam(sql, "", "", "GetInstrumentCount_1");
                iSeqNo = (obj == null) ? 0 : (Int32)obj;
                obj = null;
            }
            catch (Exception ex)
            {
                //Writelog(sError + "GetInstrumentCount for Sorter No[" + sSorterNo + "] AND Block No[" + sBlockno + "] Error : " + ex.Message);
            }
            return iInstCount;
        }
        public static DataTable GetDataTableFromSqlStr(string sSql, string sFunctionName4Log)
        {
            //sqlOpen();
            DataTable tmp = new DataTable();
            try
            {

                using (SqlDataAdapter a = new SqlDataAdapter(sSql, GetConnectionString()))
                {
                    a.Fill(tmp);
                    return tmp;
                }

            }
            catch (Exception ex)
            {
                return tmp;
            }
            finally
            {
                //sqlClose();
                tmp = null;
            }
        }

        private string GetUserBranchInfo(string sLoginName)
        {
            DataTable dtUserInfo = GetDataTableFromSqlStr("SELECT PhBRNo FROM UserInfo WITH(NOLOCK) WHERE LoginName = '" + sLoginName + "'", "GetUserBranchInfo");
            return dtUserInfo.Rows[0]["PHBRNo"].ToString();
        }
        public DataTable GetDataTableFromSP(string sSPName, string sParamName, string sParamValue, string sOutputParamName, string sFunctionName4Log)
        {
            string[] sParamNameList = sParamName.Split('|');
            string[] sParamValueList = sParamValue.Split('|');
            DataTable tmp = new DataTable();
            try
            {
                SqlConnection sqlCon = new SqlConnection(GetConnectionString());
                using (SqlCommand cmd = new SqlCommand(sSPName, sqlCon))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (sParamName != string.Empty)
                    {
                        for (int i = sParamNameList.GetLowerBound(0); i <= sParamNameList.GetUpperBound(0); i++)
                        {
                            cmd.Parameters.AddWithValue(sParamNameList[i], sParamValueList[i]);
                        }
                    }
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }

            }
            catch (Exception ex)
            {
                //WriteLog(sError + sFunctionName4Log + " Error " + ex.Message);
                return tmp;
            }
            finally
            {
                tmp = null;
            }
        }

        public static string GetConnectionString()
        {
            //return "server=" + "103.228.114.70" +
            //         ";Database=" + "KS_Sumerpur" +
            //         ";uid=" + "KS_Sumerpur" +
            //         ";pwd=" + "Fincube@41451" + ";Connection Lifetime=0;Min Pool Size=1;Max Pool Size=500;";
            string connectionstring = "";
            try
            {
                String sServer, sDataBase, sUid, sPwd;
                //  sTrustedConnection;
                // DataSet ds = new DataSet();
                // ds.ReadXml(AppDomain.CurrentDomain.BaseDirectory + "\\connection");
                sServer = _configuration["ConnectionstringNew:sServer"].ToString();
                sDataBase = _configuration["ConnectionstringNew:sDataBase"].ToString();
                sUid = _configuration["ConnectionstringNew:sUid"].ToString();
                sPwd = _configuration["ConnectionstringNew:sPwd"].ToString();
                // sTrustedConnection = ds.Tables["SQLConnection"].Rows[0]["TrustedConnection"].ToString();
                connectionstring = "Data Source=" + sServer + ";Initial Catalog=" + sDataBase + ";uid=" + sUid + ";pwd=" + sPwd + ";Trusted_connection=False;";
            }
            catch (Exception ex)
            {
                // MessageBox.Show("Unable to Connect Database " + ex.Message);
                throw ex;
            }
            return connectionstring;
        }

        public static object ExecuteScalarStrWithParam(string sSql, string sParamName, string sParamValue, string sFunctionName4Log)
        {
            string[] sParamNameList = sParamName.Split('|');
            string[] sParamValueList = sParamValue.Split('|');
            try
            {

                using (SqlConnection sqlCon = new SqlConnection(GetConnectionString()))
                {
                    sqlCon.Open();
                    using (SqlCommand command = new SqlCommand(sSql, sqlCon))
                    {
                        command.CommandType = CommandType.Text;
                        if (sParamName != string.Empty)
                        {
                            for (int i = sParamNameList.GetLowerBound(0); i <= sParamNameList.GetUpperBound(0); i++)
                            {
                                command.Parameters.AddWithValue("@" + sParamNameList[i], sParamValueList[i]);
                            }
                        }
                        return command.ExecuteScalar();
                    }
                }
            }
            catch (Exception ex)
            {
                //WriteLog(sError + sFunctionName4Log + " Error - " + ex.Message);
            }
            finally
            {
                //sqlClose();
            }
            return null;
        }


        public string GetToday()
        {
            object obj = ExecuteScalarStrWithParam("SELECT ConfigValue FROM Configuration WHERE ConfigName = 'Today'", "", "", "GetToday");
            return Convert.ToString(obj);
        }

        public string CheckForRC(string sSorterNo)
        {
            string sToday = GetToday();
            string StrCommand = "SET DATEFORMAT DMY ;SELECT BatchNo FROM InstrumentMain  WITH(NOLOCK) " +
             " WHERE ChequeDate = @ChequeDate" +
             " AND Status = @Status AND SorterNo = @SorterNo" +
             " AND BlockNo = (SELECT MAX(BlockNo) FROM InstrumentMain WITH(NOLOCK) WHERE ChequeDate = @ChequeDate" +
             " AND SorterNo = @SorterNo)" +
             " ORDER BY BatchNo DESC ";
            object obj = ExecuteScalarStrWithParam(StrCommand, "ChequeDate|Status|SorterNo", sToday + "|0|" + sSorterNo, "CheckForRC");
            return (obj == null) ? "0" : Convert.ToString(obj);


        }

        public int GetBlockNo(string sSorterNo)
        {
            string sToday = GetToday();
            string StrCommand = "SET DATEFORMAT DMY ; SELECT IsNull(MAX(BlockNo),0) As BlockNo FROM InstrumentMain  WITH(NOLOCK)  " +
             " WHERE SorterNo = @sSorterNo  " +
             " AND ChequeDate= @sToday " +
             " AND Deleted = 0";
            object obj = ExecuteScalarStrWithParam(StrCommand, "sSorterNo|sToday", sSorterNo + "|" + sToday, "GetBlockNo");
            return (obj == null) ? 0 : Convert.ToInt16(obj.ToString());
        }
        public int UpdatePhyBlockTbl(DataTable dtPhyBlock, string sToday, string sSorter)
        {
            string sBatchno = string.Empty;
            int iBlockNo = 0;
            string ChequeDate = string.Empty;
            try
            {
                iBlockNo = GetBlockNo(sSorter) + iSeqStep;
                dtPhyBlock.BeginInit();
                dtPhyBlock.Rows[0]["BlockNo"] = Convert.ToString(iBlockNo);

                //dtPhyBlock.Rows[0]["ChequeDate"] = DateTime.ParseExact(sToday,
                //    "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                //DateTime dt = DateTime.ParseExact(sToday, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                sBatchno = GetBatchNo(dtPhyBlock.Rows[0]["TBRN"].ToString(), dtPhyBlock.Rows[0]["BOFD"].ToString());

                dtPhyBlock.Rows[0]["BatchNo"] = sBatchno;

                dtPhyBlock.EndInit();

                using (SqlConnection connection = new SqlConnection(GetConnectionString()))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = new SqlCommand("SELECT * FROM InstrumentMain WITH(NOLOCK) WHERE 1=0", connection);
                    SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                    connection.Open();
                    builder.SetAllValues = false;
                    adapter.Update(dtPhyBlock);
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                //WriteLog("UpdatePhyBlockTbl : " + ex.Message);
            }
            return iBlockNo;
        }
        public string GetBatchNo(string sTBRNo, string sBOFD)
        {
            string sMaxValue = string.Empty;
            string StrCommand = string.Empty;
            string sToday = GetToday();
            StrCommand = "SET DATEFORMAT DMY ;SELECT ISNULL(MAX(BatchNo)," + sBOFD.Substring(4, 2) + "000" + ") As MaxBatchNo FROM InstrumentMain WITH(NOLOCK) ";
            StrCommand = StrCommand + " WHERE ChequeDate = @ChequeDate AND BOFD = @BOFD";
            object obj = ExecuteScalarStrWithParam(StrCommand, "ChequeDate|BOFD", sToday + "|" + sBOFD, "GetBatchNo");
            int iMaxBatchNo = Convert.ToInt32(obj) + 1;
            sMaxValue = iMaxBatchNo.ToString().PadLeft(6, '0');
            return sMaxValue;
        }


        [HttpGet]
        public ActionResult FinvergeCaptureSystem()
        {
            FinvergeCaptureSystem obj = new FinvergeCaptureSystem();
            List<FinvergeCaptureSystem> listemployee = new List<FinvergeCaptureSystem>();

            dtClearingType = GetDataTableFromSqlStr("SELECT SessionType As ClearingType,SessionName As ClearingName FROM ClearingSession ORDER BY ClearingType", "GetBatchType");
            //cmbClearingType.DataSource = dtClearingType;
            List<SelectListItem> cleartypedropdownlist = new List<SelectListItem>();
            cleartypedropdownlist.Add(new SelectListItem
            {
                Text = "---Select---",
                Value = "0"
            });
            for (int i = 0; i < dtClearingType.Rows.Count; i++)
            {

                cleartypedropdownlist.Add(new SelectListItem
                {
                    Text = dtClearingType.Rows[i]["ClearingName"].ToString(),
                    Value = dtClearingType.Rows[i]["ClearingType"].ToString()
                });
            }

            ViewBag.cleartypedropdown = cleartypedropdownlist;

            dtBranchMaster = GetDataTableFromSqlStr("SELECT * FROM vBranchMaster ORDER BY 1 ", "GetBranchMaster");
            List<SelectListItem> branchtypedroplist = new List<SelectListItem>();
            branchtypedroplist.Add(new SelectListItem
            {
                Text = "---Select---",
                Value = "0"
            });
            for (int i = 0; i < dtBranchMaster.Rows.Count; i++)
            {

                branchtypedroplist.Add(new SelectListItem
                {
                    Text = dtBranchMaster.Rows[i]["BranchName"].ToString(),
                    Value = dtBranchMaster.Rows[i]["BOFD"].ToString()
                });
            }

            ViewBag.branchtypedropdown = branchtypedroplist;


            return View();
        }


        [HttpPost]
        public JsonResult UpdatePhyBlockTbl(string sBOFD, string sSorter, string sLoginName, string sClearingType, string sChequeCount, string sCTPBatchNo)
        {
            sLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;
            ////passing parameter bofd,clearin type id ,sorter no, cheque count ,batch no
            //DataTable dtBranchList = (DataTable)cmbBranch.DataSource;
            //sBOFD = dtBranchList.Rows[cmbBranch.SelectedIndex]["BOFD"].ToString();
            //sTBRN = dtBranchList.Rows[cmbBranch.SelectedIndex]["TBRN"].ToString();
            //sIFSC = dtBranchList.Rows[cmbBranch.SelectedIndex]["IFSCCode"].ToString();
            //sPBRN = dtBranchList.Rows[cmbBranch.SelectedIndex]["PBRN"].ToString();
            //sSolID = dtBranchList.Rows[cmbBranch.SelectedIndex]["SolID"].ToString();

            //Method to fetch Details TBRN,IFSC,PBRN

            DataTable dtBracnInfo = GetDataTableFromSqlStr("SELECT * FROM vBranchMaster WHERE BOFD = " + sBOFD, "");
            string sTBRN = dtBracnInfo.Rows[0]["TBRN"].ToString();
            string sIFSC = dtBracnInfo.Rows[0]["IFSCCode"].ToString();
            string sPBRN = dtBracnInfo.Rows[0]["PBRN"].ToString();
            string sToday = GetToday();

            DateTime dt = DateTime.ParseExact(sToday, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            string sDDMM = String.Format("{0:ddMM}", dt);
            string sYY = String.Format("{0:yyyy}", dt);
            // insertin value in InstrumentMain table
            DataTable dtPhyBlockTbl = GetDataTableFromSqlStr("SELECT * FROM InstrumentMain WHERE 1=0", "BatchInfo");
            DataRow drPhyBlock = dtPhyBlockTbl.Rows.Add();
            drPhyBlock.BeginEdit();
            drPhyBlock["SorterNo"] = sSorter;
            drPhyBlock["Runno"] = "1";
            drPhyBlock["ChequeDate"] = dt;
            drPhyBlock["LoginName"] = sLoginName;
            drPhyBlock["Status"] = 0;
            drPhyBlock["Deleted"] = 0;
            drPhyBlock["ClearingType"] = sClearingType;
            drPhyBlock["TBRN"] = sTBRN;
            drPhyBlock["PBRN"] = sPBRN;
            drPhyBlock["BOFD"] = sBOFD;
            drPhyBlock["ChequeCount"] = sChequeCount;
            drPhyBlock["CTPBatchNo"] = sCTPBatchNo;
            drPhyBlock.EndEdit();
            sBlockNo = Convert.ToString(UpdatePhyBlockTbl(dtPhyBlockTbl, sToday, sSorter));
            dtPhyBlockTbl.Rows.Clear();

            sBatchNo = CheckForRC(sSorter);

            //ShowInfo();

            //lblSorterNo.Text = sSorter;
            //lblBOFD.Text = sBOFD;
            //lblBatchNo.Text = sBatchNo;
            //lblBlockNo.Text = sBlockNo;
            //lblSCount.Text = iSlipCount.ToString();
            //LblInstrumentCount.Text = iScannedCount.ToString();


            //PnlRC.Enabled = sBlockNo == "0";
            //btnstart_Click(this, null);

            FinvergeCaptureSystem objfcs = new FinvergeCaptureSystem();

            //ShowInfo();
            //PnlRC.Enabled = sBlockNo == "0";
            objfcs.BatchNo = sBatchNo;
            objfcs.BlockNo = sBlockNo;
            objfcs.Bofd = sBOFD;
            objfcs.ChequeCount = "0";
            objfcs.SlipCount = "0";
            objfcs.SorterNo = sSorter;

            //return "true";

            return Json(objfcs);
        }


        [HttpGet]
        public ActionResult Print_guest_page()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Chequereader_Engine()
        
        {
            return View();
        }



        public string GetCheque_Engine(string frontcheque_id, string Backsidechq_id, string uv_id,string loadfromcsv_id ,string Predict_id ,string Slip_id,string PayeeAccNo_id, string PayeeName_id)
        {

            FinvergeCaptureSystem objfcs = new FinvergeCaptureSystem();
            
                    objfcs.frontcheque_id = frontcheque_id;
                    objfcs.Backsidechq_id = Backsidechq_id;
                    objfcs.uv_id = uv_id;
                    objfcs.loadfromcsv_id = loadfromcsv_id;
                    objfcs.Predict_id = Predict_id;
                    objfcs.Slip_id = Slip_id;
            objfcs.PayeeAccNo_id = PayeeAccNo_id;
            objfcs.PayeeName_id = PayeeName_id;
            
            return "true";
        }



        //[HttpGet]
        //public ActionResult DataEntry_TransferForm()

        //{
        //    return View();
        //}



        //[HttpPost]
        //public ActionResult DataEntry_TransferForm(DataEntry_TransferForm obj)
        //{


        //    try
        //    {
        //        List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
        //        loSqlParametersDoc.Add(new SqlParameter("@TransferRadio", obj.TransferRadio));
        //        loSqlParametersDoc.Add(new SqlParameter("@NormalRadio", obj.NormalRadio));
        //        loSqlParametersDoc.Add(new SqlParameter("@Credit_Account_Number", obj.Credit_Account_Number));
        //        loSqlParametersDoc.Add(new SqlParameter("@Credit_Account_Name", obj.Credit_Account_Name));
        //        loSqlParametersDoc.Add(new SqlParameter("@No_of_Cheque", obj.No_of_Cheque));
        //        loSqlParametersDoc.Add(new SqlParameter("@Debit_Account_Number", obj.Debit_Account_Number));
        //        loSqlParametersDoc.Add(new SqlParameter("@Debit_Account_Name", obj.Debit_Account_Name));

        //        loSqlParametersDoc.Add(new SqlParameter("@inst_Date", obj.inst_Date));
        //        loSqlParametersDoc.Add(new SqlParameter("@cheque", obj.cheque));
        //        loSqlParametersDoc.Add(new SqlParameter("@Sort_Code", obj.Sort_Code));
        //        loSqlParametersDoc.Add(new SqlParameter("@Base_no", obj.Base_no));
        //        loSqlParametersDoc.Add(new SqlParameter("@TC", obj.TC));

        //        _DBContext.Database.ExecuteSqlCommand("DataEntry_TransferForm ".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray());


         

        //    }
        //    catch (Exception)
        //    {
        //        return null;
        //    }
        //    return View();
        //}
    }
}