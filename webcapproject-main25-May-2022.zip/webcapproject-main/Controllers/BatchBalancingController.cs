﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class BatchBalancingController : Controller
    {
        private readonly BatchBalancingDataContext _DBContext;
        public BatchBalancingController(BatchBalancingDataContext dbContext) { _DBContext = dbContext; }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public ActionResult List(int? id)
        {
            int iFunctionNo = Convert.ToInt16(id);
            //BatchSelectionDataContext loBatchSelectionDataContext = new BatchSelectionDataContext();

            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
            ViewBag.sToday = appUserInfo.sToday;

            WrapperBatchSelection loWrapperBatchSelection = new WrapperBatchSelection();
            //loWrapperBatchSelection.loBatchSelectionList = new List<BatchSelectionViewModel.BatchSelection>();
            //loWrapperBatchSelection.loBatchSelectionList = loBatchSelectionDataContext.getBatchSelectionList();

            BatchSelectionGridColumnsString loBatchSelectionGridColumnsString = new BatchSelectionGridColumnsString();
            loBatchSelectionGridColumnsString = getBatchGridDisplayColumns(iFunctionNo);

            loWrapperBatchSelection.iFuntionNumber = id;
            loWrapperBatchSelection.loBatchSelectionGridColumnsList = new List<BatchSelectionGridColumns>();
            string[] lsGridColumnMainArray = loBatchSelectionGridColumnsString.BatchGridDisplayColumns.Split('|');
            foreach (var loData in lsGridColumnMainArray)
            {
                string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

                BatchSelectionGridColumns loBatchSelectionGridColumns = new BatchSelectionGridColumns();
                loBatchSelectionGridColumns.stFieldName = lsGridValues[0];
                loBatchSelectionGridColumns.stWidth = lsGridValues[1];
                loBatchSelectionGridColumns.stDisplayCaption = lsGridValues[2];

                loWrapperBatchSelection.loBatchSelectionGridColumnsList.Add(loBatchSelectionGridColumns);
            }
            //string sBOFD = ((AdminLoginViewModel)Session["WebCTSAdmin"]).stPhBRNo;
            //var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");

            loWrapperBatchSelection.loBatchSelectionList = getBatchSelectionList(iFunctionNo, appUserInfo.stPhBRNo);

            if (TempData["BatchIslocked"] != null)
            {
                ViewData["BatchIslocked"] = (string)TempData["BatchIslocked"];
                TempData["BatchIslocked"] = null;
            }

            //if (TempData["CurrentBatchInProcess"] != null)
            //{
            //    string lsBatchNo = (string)TempData["CurrentBatchInProcess"];
            //    TempData["CurrentBatchInProcess"] = null;
            //    BatchSelectionDataContext loUpdateBatchSelectionDataContext = new BatchSelectionDataContext();
            //    bool lbIsUpdated = loUpdateBatchSelectionDataContext.updateLockStautByBatchNo(Convert.ToInt16(0), lsBatchNo);
            //}
            List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();
            loPermissionMasterList = getUserPermissionByFunctionNumber(Convert.ToInt32(id));
            loWrapperBatchSelection.sCall_Action = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_action).FirstOrDefault();
            //loWrapperBatchSelection.sCall_Controller = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_Controller).FirstOrDefault();
            loWrapperBatchSelection.sController = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Controller).FirstOrDefault();

            return View(loWrapperBatchSelection);
        }
        public ActionResult submitBatch(string fsSorterNo, string fsRefreshBlockNo, string fsAppNo, string fsInstrumentMainID)
        {
            //BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();
            bool lbStatus = submitBatchM(fsSorterNo, fsRefreshBlockNo, fsAppNo, fsInstrumentMainID);
            return Json(new { lbStatus });
        }

        public ActionResult BatchBalancing(int? id, string InstrumentMainID)
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
            ViewBag.sToday = appUserInfo.sToday;
            BatchBalancingViewModel loBatchBalancingViewModel = new BatchBalancingViewModel();
            //BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();

            //loBatchBalancingViewModel.loBatchDetailsRBNL = loBatchBalancingDataContext.getBatchDetailsRBNL(BatchNo);
            //loBatchBalancingViewModel.loBatchDeailsLBNR = loBatchBalancingDataContext.getBatchDetailLBNR(0, string.Empty, string.Empty);

            loBatchBalancingViewModel.loBatchDetailsRBNL = new List<BatchBalancingViewModel.BatchBalancing>();
            loBatchBalancingViewModel.loBatchDeailsLBNR = new List<BatchBalancingViewModel.BatchBalancing>();

            //loBatchBalancingViewModel.loSummaryLBNR = loBatchBalancingDataContext.getSummaryLBNR(0,InstrumentMainID);
            //loBatchBalancingViewModel.loBatchBalancing=
            loBatchBalancingViewModel.loRecordTypeValidationDetailList = getRecordTypeByRecTypeID(2);
            loBatchBalancingViewModel.loBatchDetails = getBatchDetailsByBatchID(InstrumentMainID);



            // DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
            List<DataEntryViewModel.TransactionCodeMaster> loTransactionCodeMasterList = new List<DataEntryViewModel.TransactionCodeMaster>();
            loTransactionCodeMasterList = getTransactionCodeList();
            loBatchBalancingViewModel.loTransactionCodeMasterList = loTransactionCodeMasterList.Select(x => x.stTCNo).ToList();

            loBatchBalancingViewModel.loCityMasterList = new List<string>();
            loBatchBalancingViewModel.loBankMasterList = new List<string>();
            loBatchBalancingViewModel.loBranchMasterList = new List<string>();
            List<DataEntryViewModel.CityMaster> loCityMasterList = new List<DataEntryViewModel.CityMaster>();
            loCityMasterList = getCityList();

            List<DataEntryViewModel.BankMaster> loBankMasterList = new List<DataEntryViewModel.BankMaster>();
            loBankMasterList = getBankList();

            List<DataEntryViewModel.BranchMaster> loBranchMasterList = new List<DataEntryViewModel.BranchMaster>();
            loBranchMasterList = getBranchList();

            loBatchBalancingViewModel.loCityMasterList = loCityMasterList.Select(x => x.stCityNo).ToList();
            loBatchBalancingViewModel.loBankMasterList = loBankMasterList.Select(x => x.stBankNo).ToList();
            loBatchBalancingViewModel.loBranchMasterList = loBranchMasterList.Select(x => x.stBranchNo).ToList();

            return View(loBatchBalancingViewModel);
        }

        public ActionResult getRBNLGrid(string BatchNo, Int32? RCStatus)
        {
            BatchBalancingViewModel loBatchBalancingViewModel = new BatchBalancingViewModel();
            //BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();
            loBatchBalancingViewModel.loBatchDetailsRBNL = getBatchDetailsRBNL(BatchNo, RCStatus);
            return View("~/Views/BatchBalancing/RBNLGrid.cshtml", loBatchBalancingViewModel);
        }

        public ActionResult getLBNRGrid(int iRCStatus, int iInstrumentMainID)
        {
            //string sBOFD = ((Login.ViewModel.AdminLoginViewModel)Session["WebCTSAdmin"]).stPhBRNo;
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            BatchBalancingViewModel loBatchBalancingViewModel = new BatchBalancingViewModel();
            //BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();
            loBatchBalancingViewModel.loBatchDeailsLBNR = getBatchDetailLBNR(appUserInfo.stPhBRNo, iRCStatus, iInstrumentMainID);
            return View("~/Views/BatchBalancing/LBNRGrid.cshtml", loBatchBalancingViewModel);
        }

        public ActionResult getSummary(int iInstrumentMainID)
        {
            //string sBOFD = ((Login.ViewModel.AdminLoginViewModel)Session["WebCTSAdmin"]).stPhBRNo;
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            List<BatchBalancingViewModel.SummaryLBNR> loSummary = new List<BatchBalancingViewModel.SummaryLBNR>();
            //BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();
            loSummary = getSummaryLBNR(iInstrumentMainID, appUserInfo.stPhBRNo);
            return Json(new { loSummary });
        }

        public ActionResult getCheckImage(string fsUDKID)
        {
            //BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();
            BatchBalancingViewModel.ChequeImage loChequeImage = getChequeImage(fsUDKID);

            string lsImage = string.Empty;
            if (loChequeImage != null)
            {
                lsImage = Convert.ToBase64String(loChequeImage.stImage);
            }

            return Json(new { response = lsImage });
        }

        public ActionResult getChequeImageByImageType(string fsImageType, string fsUDKID)
        {
            // BatchBalancingDataContext loBatchBalancingDataContext = new BatchBalancingDataContext();
            BatchBalancingViewModel.ChequeImage loChequeImage = getChequeImageByImageTypeM(fsImageType, fsUDKID);

            string lsImage = string.Empty;
            if (loChequeImage != null)
            {
                if ((fsImageType == "2") || (fsImageType == "3"))
                {
                    loChequeImage.stImage = CommonFunctions.ConvertTiffToJpeg(loChequeImage.stImage);
                }
                lsImage = Convert.ToBase64String(loChequeImage.stImage);
            }
            return Json(new { response = lsImage });
        }

        public ActionResult markUnmarkBatchDetail(string UDK, string LBNR_ID, string RBNL_ID, bool MarkType)
        {
            Int32 liRowsAffected = 0;
            liRowsAffected = markUnmarkBatchDetailM(UDK, LBNR_ID, RBNL_ID, MarkType);
            return Json(new { RowsAffected = liRowsAffected });
        }

        public ActionResult commitBatchDetail(string UDK)
        {
            Int32 liRowsAffected = 0;
            liRowsAffected = commitBatchDetailM(UDK);
            return Json(new { RowsAffected = liRowsAffected });
        }

        public ActionResult p2fBatchDetail(string UDK)
        {
            Int32 liRowsAffected = 0;
            liRowsAffected = p2fBatchDetailM(UDK);
            return Json(new { RowsAffected = liRowsAffected });
        }

        public ActionResult deleteBatchDetail(string UDK)
        {
            Int32 liRowsAffected = 0;
            liRowsAffected = deleteBatchDetailM(UDK);
            return Json(new { RowsAffected = liRowsAffected });
        }

        public ActionResult rejectBatchDetail(string UDK)
        {
            Int32 liRowsAffected = 0;
            liRowsAffected = rejectBatchDetailM(UDK);
            return Json(new { RowsAffected = liRowsAffected });
        }

        public ActionResult saveBatchDetail(string UDK, string ChequeNo, string SortCode, string BaseNo, string TC, decimal Amount, string AccountNo, string AccountName)
        {
            Int32 liRowsAffected = 0;
            liRowsAffected = saveBatchDetailM(UDK, ChequeNo, SortCode, BaseNo, TC, Amount, AccountNo, AccountName);
            return Json(new { RowsAffected = liRowsAffected });
        }

        public ActionResult checkBatchStatus(string fsInstrumentMainID)
        {
            //string stLoginName = ((Login.ViewModel.AdminLoginViewModel)Session["WebCTSAdmin"]).stLoginName;
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            //DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
            DataEntryViewModel.BatchCurrentStatus loBatchCurrentStatus = checkBatchStatusM(fsInstrumentMainID, appUserInfo.stLoginName);
            return Json(new { loBatchCurrentStatus });
        }


        //[OutputCacheAttribute(NoStore = true, Duration = 0)]
        //public ActionResult List()
        //{
        //	BatchSelectionDataContext loBatchSelectionDataContext = new BatchSelectionDataContext();

        //	BatchSelectionViewModel.WrapperBatchSelection loWrapperBatchSelection = new BatchSelectionViewModel.WrapperBatchSelection();
        //	//loWrapperBatchSelection.loBatchSelectionList = new List<BatchSelectionViewModel.BatchSelection>();
        //	//loWrapperBatchSelection.loBatchSelectionList = loBatchSelectionDataContext.getBatchSelectionList();

        //	BatchSelectionViewModel.BatchSelectionGridColumnsString loBatchSelectionGridColumnsString = new BatchSelectionViewModel.BatchSelectionGridColumnsString();
        //	loBatchSelectionGridColumnsString = loBatchSelectionDataContext.getBatchGridDisplayColumns();


        //	loWrapperBatchSelection.loBatchSelectionGridColumnsList = new List<BatchSelectionViewModel.BatchSelectionGridColumns>();
        //	string[] lsGridColumnMainArray = loBatchSelectionGridColumnsString.BatchGridDisplayColumns.Split('|');
        //	foreach (var loData in lsGridColumnMainArray)
        //	{
        //		string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

        //		BatchSelectionViewModel.BatchSelectionGridColumns loBatchSelectionGridColumns = new BatchSelectionViewModel.BatchSelectionGridColumns();
        //		loBatchSelectionGridColumns.stFieldName = lsGridValues[0];
        //		loBatchSelectionGridColumns.stWidth = lsGridValues[1];
        //		loBatchSelectionGridColumns.stDisplayCaption = lsGridValues[2];

        //		loWrapperBatchSelection.loBatchSelectionGridColumnsList.Add(loBatchSelectionGridColumns);
        //	}

        //	loWrapperBatchSelection.loBatchSelectionList = loBatchSelectionDataContext.getBatchSelectionList();

        //	if (TempData["BatchIslocked"] != null)
        //	{
        //		ViewData["BatchIslocked"] = (string)TempData["BatchIslocked"];
        //		TempData["BatchIslocked"] = null;
        //	}

        //	if (TempData["CurrentBatchInProcess"] != null)
        //	{
        //		string lsBatchNo = (string)TempData["CurrentBatchInProcess"];
        //		TempData["CurrentBatchInProcess"] = null;
        //		BatchSelectionDataContext loUpdateBatchSelectionDataContext = new BatchSelectionDataContext();
        //		bool lbIsUpdated = loUpdateBatchSelectionDataContext.updateLockStautByBatchNo(Convert.ToInt16(0), lsBatchNo);
        //	}
        //	return View(loWrapperBatchSelection);
        //}

        public List<BatchBalancingViewModel.RecordTypeValidationDetails> getRecordTypeByRecTypeID(Int32 fiRecTypeID)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("inRecTypeID", fiRecTypeID.handleDBNull()));

                return _DBContext.DBSet_RecordTypeValidationDetails.FromSql("getRecordTypeByRecTypeID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception) { return null; }
        }

        public BatchBalancingViewModel.BatchDetails getBatchDetailsByBatchID(string fsInstrumentMainID)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
                return _DBContext.DBSet_BatchDetails.FromSql("getBatchDetailsByBatchID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
            }
            catch (Exception) { return null; }
        }

        public List<BatchBalancingViewModel.BatchBalancing> getBatchDetailLBNR(string fsBOFD, int fiRCStatus, int fiInstrumentMainID)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("BOFD", fsBOFD));
                loSqlParameters.Add(new SqlParameter("RCStatus", fiRCStatus));
                loSqlParameters.Add(new SqlParameter("InstrumentMainID", fiInstrumentMainID));
                return _DBContext.DBSet_BatchBalancing.FromSql("USP_GetBatchDetailLBNR".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex) { return null; }
        }

        public List<BatchBalancingViewModel.BatchBalancing> getBatchDetailsRBNL(string fsBatchNo, Int32? RCStatus)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("BatchNo", fsBatchNo));
                loSqlParameters.Add(new SqlParameter("RCStatus", RCStatus));
                return _DBContext.DBSet_BatchBalancing.FromSql("USP_GetBatchDetailRBNL".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex) { return null; }
        }

        public Int32 markUnmarkBatchDetailM(string fsUDK, string lbnr_id, string rbnl_id, bool fbMarkType)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("UDK", fsUDK));
                loSqlParameters.Add(new SqlParameter("LBNR_id", lbnr_id));
                loSqlParameters.Add(new SqlParameter("RBNL_id", rbnl_id));
                loSqlParameters.Add(new SqlParameter("MarkType", fbMarkType));
                _DBContext.Database.ExecuteSqlCommand("USP_MarkUnMark".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                return 1;
            }
            catch (Exception ex) { return 0; }
        }

        public Int32 commitBatchDetailM(string fsUDK)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("UDK", fsUDK));
                _DBContext.Database.ExecuteSqlCommand("USP_CommitBatchDetail".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                return 1;
            }
            catch (Exception ex) { return 0; }

        }

        public Int32 p2fBatchDetailM(string fsUDK)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("UDK", fsUDK));
                _DBContext.Database.ExecuteSqlCommand("USP_P2FBatchDetail".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                return 1;
            }
            catch (Exception ex) { return 0; }
        }

        public Int32 deleteBatchDetailM(string fsUDK)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("UDK", fsUDK));
                _DBContext.Database.ExecuteSqlCommand("USP_DeleteBatchDetail".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                return 1;
            }
            catch (Exception ex) { return 0; }
        }

        public Int32 rejectBatchDetailM(string fsUDK)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("UDK", fsUDK));
                _DBContext.Database.ExecuteSqlCommand("USP_RejectBatchDetail".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                return 1;
            }
            catch (Exception ex) { return 0; }
        }

        public Int32 saveBatchDetailM(string fsUDK, string fsChequeNo, string fsSortCode, string fsBaseNo, string fsTC, decimal fdAmount, string fAccountNo, string fsAccountName)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("UDK", fsUDK));
                loSqlParameters.Add(new SqlParameter("ChequeNo", fsChequeNo));
                loSqlParameters.Add(new SqlParameter("SortCode", fsSortCode));
                loSqlParameters.Add(new SqlParameter("BaseNo", fsBaseNo));
                loSqlParameters.Add(new SqlParameter("TC", fsTC));
                loSqlParameters.Add(new SqlParameter("Amount", fdAmount));
                loSqlParameters.Add(new SqlParameter("AccountNo", fAccountNo));
                loSqlParameters.Add(new SqlParameter("AccountName", fsAccountName));
                _DBContext.Database.ExecuteSqlCommand("USP_SaveBatchDetail".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
                return 1;
            }
            catch (Exception ex) { return 0; }
        }

        public List<BatchBalancingViewModel.SummaryLBNR> getSummaryLBNR(int fsInstrumentMainID, string fsBOFD)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("BOFD", fsBOFD));
                loSqlParameters.Add(new SqlParameter("InstrumentMainID", fsInstrumentMainID));
                return _DBContext.DBSet_SummaryLBNR.FromSql("USP_SummaryLBNR".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)  { return null; }

        }

        public BatchBalancingViewModel.ChequeImage getChequeImageByImageTypeM(string fsImageType, string fsUDKID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stImageType", fsImageType.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
            return _DBContext.DBSet_ChequeImage.FromSql("getChequeImageByImageType".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }

        public bool submitBatchM(string fsSorterNo, string fsRefreshBlockNo, string fsAppNo, string fsInstrumentMainID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("sSorterNo", fsSorterNo.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iRefreshBlockNo", fsRefreshBlockNo.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iAppNo", fsAppNo.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iInstrumentMainID", fsInstrumentMainID.handleDBNull()));
            _DBContext.Database.ExecuteSqlCommand("USP_SubmitBatchLBNR".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());
            return true;
        }

        public BatchBalancingViewModel.ChequeImage getChequeImage(string fsUDKID)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("skUDKID", fsUDKID.handleDBNull()));
                return _DBContext.DBSet_ChequeImage.FromSql("getChequeImage".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
            }
            catch (Exception ex) { return null; }
        }


        ///
        public DataEntryViewModel.BatchCurrentStatus checkBatchStatusM(string fsInstrumentMainID, string sLoginName)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("LoginName", sLoginName.handleDBNull()));
            return _DBContext.DBSet_BatchCurrentStatus.FromSql("checkBatchStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }

        public List<DataEntryViewModel.ModuleFields> getModuleFieldsList(string fsFunctionNo)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("stFunction", fsFunctionNo.handleDBNull()));
                return _DBContext.DBSet_ModuleFields.FromSql("getModuleFields".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.CityMaster> getCityList()
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                return _DBContext.DBSet_CityMaster.FromSql("getCityList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.BankMaster> getBankList()
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                return _DBContext.DBSet_BankMaster.FromSql("getBankList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.BranchMaster> getBranchList()
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                return _DBContext.DBSet_BranchMaster.FromSql("getBranchList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public List<DataEntryViewModel.TransactionCodeMaster> getTransactionCodeList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_TransactionCodeMaster.FromSql("getTransactionCodeList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<PermissionMaster> getUserPermissionByFunctionNumber(Int32 fiFunctionNumber)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("functionNumber", fiFunctionNumber.handleDBNull()));

            return _DBContext.DBSet_PermissionMaster.FromSql("USP_ModuleInfoByFuntionNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public BatchSelectionGridColumnsString getBatchGridDisplayColumns(Int32 iFunctionNumber)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("functionNumber", iFunctionNumber.handleDBNull()));
            return _DBContext.DBSet_BatchSelectionGridColumnsString.FromSql("USP_GetBatchGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }

        public IEnumerable<dynamic> getBatchSelectionList(int iFunctionNo, string fsBOFD)
        {
            //using (var ctx = new BatchSelectionDataContext())
            var cmd = new SqlCommand();
            var con = new SqlConnection(CommonFunctions.ConStr);
            cmd.Connection = con;
            con.Open();

            cmd.CommandText = "EXEC USP_GetBatchSelectionList " + Convert.ToString(iFunctionNo) + "," + fsBOFD;
            using (var reader = cmd.ExecuteReader())
            {
                var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
                return model;
            }
        }
    }
}
