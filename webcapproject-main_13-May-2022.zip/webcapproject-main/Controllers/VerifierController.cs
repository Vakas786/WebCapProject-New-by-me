﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Controllers
{
	[AuthorizeRole]
	public class VerifierController : Controller
	{
		private readonly DataEntryDataContext _DBContext;
		public VerifierController(DataEntryDataContext dbContext) { _DBContext = dbContext; }

		public ActionResult Verifier(int? id)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
			ViewBag.sToday = appUserInfo.sToday;

			DataEntryViewModel.WrapperDataEntry loWrapperDataEntry = new DataEntryViewModel.WrapperDataEntry();
			//if (!string.IsNullOrEmpty(InstrumentMainID))
			//{
			//  string lsInstrumentMainID = InstrumentMainID;
			//string sLoginName = ((AdminLoginViewModel)Session["WebCTSAdmin"]).stLoginName;

			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			//var loBatchCurrentStatus = checkBatchStatusM(lsInstrumentMainID, appUserInfo.stLoginName);
			//string lsBatchNo = loBatchCurrentStatus.stBatchNo;
			int iFuntionNumber = 100;
			if (id != null)
			{
				iFuntionNumber = Convert.ToInt16(id);
			}

			DataEntryViewModel.FuntionSP loFucntionSP = new DataEntryViewModel.FuntionSP();
			loFucntionSP = GetFunctionSpName(iFuntionNumber);
			ViewBag.sSP = loFucntionSP.SPName;
			ViewBag.Title = loFucntionSP.ModuleName;
			loWrapperDataEntry.loCheckDetailsList = getChequeDetails(appUserInfo.stLoginName, loFucntionSP.SPName, Convert.ToInt16(id));

			if (loWrapperDataEntry.loCheckDetailsList != null && loWrapperDataEntry.loCheckDetailsList.Count() > 0)
			{
				loWrapperDataEntry.iFuntionNo = iFuntionNumber;
				loWrapperDataEntry.loModuleFieldsList = getModuleFieldsList(iFuntionNumber.ToString());
				
				DataEntryViewModel.BatchGridColumnsString loBatchGridColumnsString = new DataEntryViewModel.BatchGridColumnsString();
				loBatchGridColumnsString = getGridDisplayColumns(iFuntionNumber);

				loWrapperDataEntry.loBatchGridColumnsList = new List<DataEntryViewModel.BatchGridColumns>();
				string[] lsGridColumnMainArray = loBatchGridColumnsString.GridDisplayColumns.Split('|');

				foreach (var loData in lsGridColumnMainArray)
				{
					string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

					DataEntryViewModel.BatchGridColumns BatchGridColumns = new DataEntryViewModel.BatchGridColumns();
					BatchGridColumns.stFieldName = lsGridValues[0];
					BatchGridColumns.stWidth = lsGridValues[1];
					BatchGridColumns.stDisplayCaption = lsGridValues[2];

					loWrapperDataEntry.loBatchGridColumnsList.Add(BatchGridColumns);
				}



				loWrapperDataEntry.loDataEntry = new DataEntryViewModel.DataEntry();
				loWrapperDataEntry.loCityMasterList = new List<string>();
				loWrapperDataEntry.loBankMasterList = new List<string>();
				loWrapperDataEntry.loBranchMasterList = new List<string>();
				loWrapperDataEntry.loTransactionCodeMasterList = new List<string>();
				

				List<DataEntryViewModel.CityMaster> loCityMasterList = new List<DataEntryViewModel.CityMaster>();
				loCityMasterList = getCityList();

				List<DataEntryViewModel.BankMaster> loBankMasterList = new List<DataEntryViewModel.BankMaster>();
				loBankMasterList = getBankList();

				List<DataEntryViewModel.BranchMaster> loBranchMasterList = new List<DataEntryViewModel.BranchMaster>();
				loBranchMasterList = getBranchList();

				List<DataEntryViewModel.ReturnReasonMaster> loReturnReasonList = new List<DataEntryViewModel.ReturnReasonMaster>();
				loReturnReasonList = getReturnReasonForDropdown();

				List<DataEntryViewModel.TransactionCodeMaster> loTransactionCodeMasterList = new List<DataEntryViewModel.TransactionCodeMaster>();
				loTransactionCodeMasterList = getTransactionCodeList();

				loWrapperDataEntry.loCityMasterList = loCityMasterList.Select(x => x.stCityNo).ToList();
				loWrapperDataEntry.loBankMasterList = loBankMasterList.Select(x => x.stBankNo).ToList();
				loWrapperDataEntry.loBranchMasterList = loBranchMasterList.Select(x => x.stBranchNo).ToList();
				loWrapperDataEntry.loTransactionCodeMasterList = loTransactionCodeMasterList.Select(x => x.stTCNo).ToList();
				
				loWrapperDataEntry.loReturnReasonList = loReturnReasonList;

				//loWrapperDataEntry.loBatchDetails = new DataEntryViewModel.BatchDetails();
				//loWrapperDataEntry.loBatchDetails = getBatchDetailsByBatchID(lsInstrumentMainID);



				loWrapperDataEntry.loRecordTypeValidationDetailList = getRecordTypeByRecTypeIDM(2);

				List<DataEntryViewModel.RecordTypeFromDB> loRecordTypeFromDBList = new List<DataEntryViewModel.RecordTypeFromDB>();
				loRecordTypeFromDBList = getRecordTypeForDropdown();

				loWrapperDataEntry.loRecordTypeList = getRecordTypeForDropdown();

				//TempData["CurrentBatchInProcess"] = lsBatchNo;
				TempData["CurrentBatchInProcess"] = "";
				//TempData["InstrumentMainID"] = InstrumentMainID;
				TempData["InstrumentMainID"] = "";

				List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();
				loPermissionMasterList = getUserPermissionByFunctionNumber(Convert.ToInt32(id));
				loWrapperDataEntry.sCall_Action = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_action).FirstOrDefault();
				//loWrapperDataEntry.sCall_Controller = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_Controller).FirstOrDefault();
				loWrapperDataEntry.sController = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Controller).FirstOrDefault();


				return View(loWrapperDataEntry);
			}
			else
			{

				return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
			}
			//}
			//else
			//{
			//    return RedirectToRoute("default", new { controller = "DataEntry", action = "List", id = id });
			//}
		}

		public ActionResult getCheckImage(string fsUDKID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			DataEntryViewModel.ChequeImage loChequeImage = getChequeImage(fsUDKID);

			string lsImage = string.Empty;
			if (loChequeImage != null)
			{
				lsImage = Convert.ToBase64String(loChequeImage.stImage);
			}

			return Json(new { response = lsImage });

			//if (!string.IsNullOrEmpty(loChequeImage.stImage))
			//    return Json(new { response = loChequeImage.stImage }, JsonRequestBehavior.AllowGet);
			//else
			//    return Json(new { response = "" }, JsonRequestBehavior.AllowGet);
		}
		public ActionResult BackMenu(string fsSp, string fsFunctionNo)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			string fsUserName = appUserInfo.stLoginName;
			string sUnlockSP = fsSp.Split('~')[2];
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql(sUnlockSP.getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			//return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
			return Json(new { response = "true" });
		}
		public ActionResult saveChequeDetails(string fsUDKID, string fsParamList, string fsParamValue, string fsFunctionNo,string fsSp)
		{
			//string sGetSP = fsSp.Split('~')[0].ToString();
			string sUpdateSP = fsSp.Split('~')[1].ToString();
			//string sUnlockSP = fsSp.Split('~')[2].ToString();

			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			bool lbStatus = updateChequeDetails_NEW(fsUDKID, fsParamList, fsParamValue, fsFunctionNo);
			return Json(new { response = "true" });
		}

		public ActionResult getNextBatchDetails(string fsInstrumentMainID, string fsFunctionNo, string fsBOFD)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			DataEntryViewModel.NextBatchDetails loNextBatchDetails = getNextBatchDetailsM(fsInstrumentMainID, fsFunctionNo, fsBOFD);
			return Json(new { loNextBatchDetails });
		}

		public ActionResult getRecordTypeByRecTypeID(Int32 fiRecTypeID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			List<DataEntryViewModel.RecordTypeValidationDetails> loRecordTypeValidationDetailsList = getRecordTypeByRecTypeIDM(fiRecTypeID);

			return Json(new { loRecordTypeValidationDetailsList });
		}
		public ActionResult submitBatch(string fsUDKID, string fsFunctionNo)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			string fsUserName = appUserInfo.stLoginName;

			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDK", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("USP_SubmitVerifier".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();


			return Json(new { response = "true" });
		}

		public ActionResult getChequeImageByImageType(string fsImageType, string fsUDKID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			DataEntryViewModel.ChequeImage loChequeImage = getChequeImageByImageTypeM(fsImageType, fsUDKID);

			string lsImage = string.Empty;
			if (loChequeImage != null)
			{
				if ((fsImageType == "2") || (fsImageType == "3"))
				{
					loChequeImage.stImage = CommonFunctions.ConvertTiffToJpeg(loChequeImage.stImage);
				}
				lsImage = Convert.ToBase64String(loChequeImage.stImage);
			}

			return Json(new { response = lsImage });

		}

		[HttpPost]
		public ActionResult checkBatchStatus(string fsInstrumentMainID)
		{
			//string stLoginName = ((Login.ViewModel.AdminLoginViewModel)Session["WebCTSAdmin"]).stLoginName;
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");

			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			var loBatchCurrentStatus = checkBatchStatusM(fsInstrumentMainID, appUserInfo.stLoginName);
			return Json(new { loBatchCurrentStatus });
		}

		public ActionResult unlockBatchByBatchNo(string fsBatchNo, string fsInstrumentMainID)
		{
			TempData["LastProcessedBactNo"] = fsBatchNo;
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			var loResponse = unlockBatchByBatchNo(fsInstrumentMainID);

			return Json(new { loResponse });
		}

		public List<DataEntryViewModel.ModuleFields> getModuleFieldsList(string fsFunctionNo)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stFunction", fsFunctionNo.handleDBNull()));
				return _DBContext.DBSet_ModuleFields.FromSql("getModuleFields".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.CityMaster> getCityList()
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				return _DBContext.DBSet_CityMaster.FromSql("getCityList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.BankMaster> getBankList()
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				return _DBContext.DBSet_BankMaster.FromSql("getBankList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.BranchMaster> getBranchList()
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				return _DBContext.DBSet_BranchMaster.FromSql("getBranchList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.TransactionCodeMaster> getTransactionCodeList()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			return _DBContext.DBSet_TransactionCodeMaster.FromSql("getTransactionCodeList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public DataEntryViewModel.ChequeImage getChequeImage(string fsUDKID)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("skUDKID", fsUDKID.handleDBNull()));
				return _DBContext.DBSet_ChequeImage.FromSql("getChequeImage".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			}
			catch (Exception) { return null; }
		}

		public bool updateChequeDetails(string fsUDKID, string fsChequeNo, string fsCityNo, string fsBankNo, string fsBranchNo, string fsBaseNo, string fsTCNo, string fsSortCode, string fsStatusNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stChequeNo", fsChequeNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stCityNo", fsCityNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stBankNo", fsBankNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stBranchNo", fsBranchNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stBaseNo", fsBaseNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stTCNo", fsTCNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stSortCode", fsSortCode.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stStatusNo", fsStatusNo.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("updateChequeDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}

		public bool updateChequeDetails_NEW(string fsUDKID, string fsParamList, string fsParamValue, string fsFunctionNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stParamList", fsParamList.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stParamValue", fsParamValue.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("updateChequeDetails_New".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}
		public bool updateVerifierData(string fsSp, string fsUDKID,string fsAccountNo ,string fsParamList, string fsParamValue, string fsFunctionNo,
			string fsDecesion,string fsNarration,string fsRejectCode,string fsModifiedByUser,string fsUserName )
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			fsUserName = appUserInfo.stLoginName;

			string sUpdateSP = fsSp.Split('~')[1];
			//string [] lstParamAll = fsAllparam.Split('|');
			string [] lstParam = fsParamList.Split('|');
			string [] lstParamVal = fsParamValue.Split('|');
			
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			
			for (int i=0;i< lstParam.Length;i++)
			{
				loSqlParameters.Add(new SqlParameter("st"+lstParam[i].ToString(), lstParamVal[i].ToString().handleDBNull()));
			}
			
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stAccountNo", fsAccountNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stDecesion", fsDecesion.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stNarration", fsNarration.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stRejectCode", fsRejectCode.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stModifiedByUser", fsModifiedByUser.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));

			_DBContext.DBSet_Verifier.FromSql(sUpdateSP.getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}
		public DataEntryViewModel.NextBatchDetails getNextBatchDetailsM(string fsInstrumentMainID, string fsFunctionNo, string fsBOFD)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("FunctionNumber", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("BOFD", fsBOFD.handleDBNull()));
			return _DBContext.DBSet_NextBatchDetails.FromSql("getNextBatchDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public DataEntryViewModel.BatchDetails getBatchDetailsByBatchID(string fsInstrumentMainID)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
				return _DBContext.DBSet_BatchDetails.FromSql("getBatchDetailsByBatchID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}

		public List<DataEntryViewModel.RecordTypeFromDB> getRecordTypeForDropdown()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();

			return _DBContext.DBSet_RecordTypeFromDB.FromSql("getRecordTypeForDropdown".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public bool setUDKDeleteUndeleteM(string fsUDK, bool fbIsDelete)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDK", fsUDK.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("flgIsDelete", fbIsDelete.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("setUDKDeleteUndelete".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}

		public List<PermissionMaster> getUserPermissionByFunctionNumber(Int32 fiFunctionNumber)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("functionNumber", fiFunctionNumber.handleDBNull()));

			return _DBContext.DBSet_PermissionMaster.FromSql("USP_ModuleInfoByFuntionNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public bool submitBatchM(string fsSorterNo, string fsRefreshBlockNo, string fsAppNo, string fsInstrumentMainID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("sSorterNo", fsSorterNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iRefreshBlockNo", fsRefreshBlockNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iAppNo", fsAppNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iInstrumentMainID", fsInstrumentMainID.handleDBNull()));
			_DBContext.DBSet_TransactionCodeMaster.FromSql("USP_SubmitBatch".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			return true;
		}

		public bool submitBatch_verifier(string fsInstrumentMainID, string fsAppNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("InstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iAppNo", fsAppNo.handleDBNull()));
			_DBContext.DBSet_TransactionCodeMaster.FromSql("USP_SubmitBatch_Verifier".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			return true;
		}

		public List<DataEntryViewModel.RecordTypeValidationDetails> getRecordTypeByRecTypeIDM(Int32 fiRecTypeID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("inRecTypeID", fiRecTypeID.handleDBNull()));
			return _DBContext.DBSet_RecordTypeValidationDetails.FromSql("getRecordTypeByRecTypeID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public DataEntryViewModel.BatchGridColumnsString getGridDisplayColumns(Int32 iFunctionNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("FunctionNo", iFunctionNo.handleDBNull()));
			return _DBContext.DBSet_BatchGridColumnsString.FromSql("USP_GetGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		//public List<DataEntryViewModel.CheckDetails> getChequeDetailsByBatchID(string fsBatchNo)
		//{
		//    List<SqlParameter> loSqlParameters = new List<SqlParameter>();
		//    loSqlParameters.Add(new SqlParameter("stBatchNo", fsBatchNo.handleDBNull()));

		//    return new DataEntryDataContext().Database.SqlQuery<DataEntryViewModel.CheckDetails>("getChequeDetailsByBatchID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		//}

		public IEnumerable<dynamic> getChequeDetailsByBatchID(string fsInstrumentMainID)
		{
			//using (var ctx = new DataEntryDataContext())
			var cmd = new SqlCommand();
			var con = new SqlConnection(CommonFunctions.ConStr);
			cmd.Connection = con;
			cmd.CommandText = "getChequeDetailsByBatchID";
			cmd.CommandType = CommandType.StoredProcedure;

			DbParameter param = cmd.CreateParameter();
			param.ParameterName = "stInstrumentMainID";
			param.DbType = DbType.String;
			param.Direction = ParameterDirection.Input;
			param.Value = fsInstrumentMainID;

			cmd.Parameters.Add(param);
			//_DBContext.Database.OpenConnection();
			con.Open();
			using (var reader = cmd.ExecuteReader())
			{
				var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
				//_DBContext.Database.CloseConnection();
				return model;
			}
		}
		public IEnumerable<dynamic> getChequeDetails(string fsloginName, string fsSP,Int16 fsFunctionNo)
		{
			string sgetSp = fsSP.Split('~')[0].ToString();
			//using (var ctx = new DataEntryDataContext())
			var cmd = new SqlCommand();
			var con = new SqlConnection(CommonFunctions.ConStr);
			cmd.Connection = con;
			cmd.CommandText = sgetSp;
			cmd.CommandType = CommandType.StoredProcedure;

			DbParameter param = cmd.CreateParameter();
			param.ParameterName = "stLoginName";
			param.DbType = DbType.String;
			param.Direction = ParameterDirection.Input;
			param.Value = fsloginName;
			cmd.Parameters.Add(param);

			DbParameter param2 = cmd.CreateParameter();
			param2.ParameterName = "stFunctionNo";
			param2.DbType = DbType.Int16;
			param2.Direction = ParameterDirection.Input;
			param2.Value = fsFunctionNo;
			cmd.Parameters.Add(param2);
			//_DBContext.Database.OpenConnection();
			con.Open();
			using (var reader = cmd.ExecuteReader())
			{
				var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
				//_DBContext.Database.CloseConnection();
				return model;
			}
		}
		//public IEnumerable<dynamic> GetAllData4ImageExtraction(string fsWhereClouse)
		//{
		//    using (var ctx = new DataEntryDataContext())
		//    using (var cmd = ctx.Database.Connection.CreateCommand())
		//    {
		//        ctx.Database.Connection.Open();
		//        cmd.CommandText = "USP_ImageExtractionData";
		//        cmd.CommandType = CommandType.StoredProcedure;
		//        DbParameter param = cmd.CreateParameter();
		//        param.ParameterName = "sWhereClouse";
		//        param.DbType = DbType.String;
		//        param.Direction = ParameterDirection.Input;
		//        param.Value = fsWhereClouse;

		//        cmd.Parameters.Add(param);

		//        using (var reader = cmd.ExecuteReader())
		//        {
		//            var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
		//            return model;
		//        }
		//    }
		//}

		//public IEnumerable<dynamic> getChequeDetailsByCondition(string fsWhereClouse)
		//{
		//    using (var ctx = new DataEntryDataContext())
		//    using (var cmd = ctx.Database.Connection.CreateCommand())
		//    {
		//        ctx.Database.Connection.Open();
		//        cmd.CommandText = "getChequeDetailsByCondition";

		//        cmd.CommandType = CommandType.StoredProcedure;

		//        DbParameter param = cmd.CreateParameter();
		//        param.ParameterName = "sWhereClouse";
		//        param.DbType = DbType.String;
		//        param.Direction = ParameterDirection.Input;
		//        param.Value = fsWhereClouse;

		//        cmd.Parameters.Add(param);

		//        using (var reader = cmd.ExecuteReader())
		//        {
		//            var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
		//            return model;
		//        }
		//    }
		//}

		public DataEntryViewModel.ChequeImage getChequeImageByImageTypeM(string fsImageType, string fsUDKID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stImageType", fsImageType.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			return _DBContext.DBSet_ChequeImage.FromSql("getChequeImageByImageType".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public DataEntryViewModel.AllChequeImage GetAllImages(string fsUDKID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			return _DBContext.DBSet_AllChequeImage.FromSql("USP_GetAllImages".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public DataEntryViewModel.BatchCurrentStatus checkBatchStatusM(string fsInstrumentMainID, string sLoginName)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("LoginName", sLoginName.handleDBNull()));
			return _DBContext.DBSet_BatchCurrentStatus.FromSql("checkBatchStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public bool unlockBatchByBatchNo(string fsInstrumentMainID)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
				_DBContext.DBSet_BatchCurrentStatus.FromSql("unlockBatchByBatchNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

				return true;
			}
			catch (Exception) { return false; }

		}

		public bool Accept_Reject(string fsAccept_Reject, string fsUDKID, string fsRejectCode)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stAccept_Reject", fsAccept_Reject.handleDBNull()));
				loSqlParameters.Add(new SqlParameter("stUDK", fsUDKID.handleDBNull()));
				loSqlParameters.Add(new SqlParameter("RejectCode", fsRejectCode.handleDBNull()));

				_DBContext.DBSet_BatchCurrentStatus.FromSql("USP_setUDKAcceptReject".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

				return true;
			}
			catch (Exception) { return false; }

		}

		public List<DataEntryViewModel.ReturnReasonMaster> getReturnReasonForDropdown()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();

			return _DBContext.DBSet_ReturnReasonMaster.FromSql("getReturnReasonList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public List<DataEntryViewModel.DocSearchCriteria> getReportCriteria()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			return _DBContext.DBSet_DocSearchCriteria.FromSql("getDocSearchCriteria".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		/* Batch Selection */

		public BatchSelectionGridColumnsString getBatchGridDisplayColumns(Int32 iFunctionNumber)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("functionNumber", iFunctionNumber.handleDBNull()));
			return _DBContext.DBSet_BatchSelectionGridColumnsString.FromSql("USP_GetBatchGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}
		public FuntionSP GetFunctionSpName(Int32 iFunctionNumber)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("functionNumber", iFunctionNumber.handleDBNull()));
			return _DBContext.DBSet_FuntionSP.FromSql("USP_GetSpByFunctionNumber".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}
		public IEnumerable<dynamic> getBatchSelectionList(int iFunctionNo, string fsBOFD)
		{
			//using (var ctx = new BatchSelectionDataContext())
			var cmd = new SqlCommand();
			var con = new SqlConnection(CommonFunctions.ConStr);
			cmd.Connection = con;
			con.Open();

			cmd.CommandText = "EXEC USP_GetBatchSelectionList " + Convert.ToString(iFunctionNo) + "," + fsBOFD;
			using (var reader = cmd.ExecuteReader())
			{
				var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
				return model;
			}

		}


		public bool updateLockStautByBatchNo(Int16 fiLockStatus, Int64 fsInstrumentMainID, string fsBOFD)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("inLockStatus", fiLockStatus.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("InstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("BOFD", fsBOFD.handleDBNull()));
			_DBContext.DBSet_BatchSelectionGridColumnsString.FromSql("updateLockStautByBatchNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			return true;
		}

	}
}
