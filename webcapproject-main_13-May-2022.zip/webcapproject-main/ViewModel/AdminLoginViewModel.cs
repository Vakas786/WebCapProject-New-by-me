﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class AdminLoginViewModel
    {
        [Key]
        public Int16 inUserInfoID { get; set; }

        [Required(ErrorMessage = "Please enter your user name")]
        public string stUserName { get; set; }

        [Required(ErrorMessage = "Please enter your password")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "Please enter minimum 1 characters password.")]
        public string stUserPWD { get; set; }
        public string stPhBRNo { get; set; }
        public int inGroupID { get; set; }
        public string stLoginName { get; set; }
        //public string logo { get; set; }
        //public string cmpName { get; set; }
        //public byte[] imglogo { get; set; }
        public string stMobileNo { get; set; }
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Invalid OTP")]
        public string stLoginOTP { get; set; }
        public string sToday { get; set; }

        /* Restrict Multiple Login */
        public string loginKey { get; set; } 
        public string lastTimeActive { get; set; }
        //public string forceLogin { get; set; }
    }

    public class AdminLoginCheckViewModel
    {
        [Key]
        public string stUserName { get; set; }

    }
}