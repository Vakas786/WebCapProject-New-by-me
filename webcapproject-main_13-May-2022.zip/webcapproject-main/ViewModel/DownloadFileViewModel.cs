﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class DownloadFileViewModel
    {
        public class BatchGridColumns
        {
            public string stFieldName { get; set; }
            public string stWidth { get; set; }
            public string stDisplayCaption { get; set; }
        }

        public class FileDetails
        {
            public Int32 FileTypeID { get; set; }
            public string FileDisplayName { get; set; }
            public Int32 InstCount { get; set; }
          

        }
        public class TransactionCodeMaster
        {
            public string stTCNo { get; set; }
        }
        public class DownloadFileConfigure
        {
            [Key]
            public Int32 FileTypeID { get; set; }
            public string FileNamingConvention { get; set; }
            public string FilePath { get; set; }
            public string FilePrepareSP { get; set; }
            public string FileOutputType { get; set; }
            public string FileSegField { get; set; }
            public string FileDisplayName { get; set; }
        }

        public class FileDownloadData
        {
            public string DownloadData { get; set; }
            [Key]
            public Int32 FileTypeID { get; set; }
            public Int32 DownloadID { get; set; }
            public string FileName { get; set; }
        }
        public class FileDownloadBOFD
        {
            [Key]
            public string BOFD { get; set; }
            public string BranchName { get; set; }
        }

        public class ModuleFields
        {
            public Int32 FileTypeID { get; set; }
            public string FileDisplayName { get; set; }
            public Int32 InstCount { get; set; }
          
        }
        public class BatchGridColumnsString
        {
            public string GridDisplayColumns { get; set; }
        }

        public List<ModuleFields> loModuleFieldsList { get; set; }

        public List<DownloadFileConfigure> loDownloadFileConfigureList { get; set; }

        public class WrapperDownloadFile
        {
            public Nullable<int> iFuntionNo { get; set; }
            public string stReturnCodeValue { get; set; }
           
            public List<BatchGridColumns> loBatchGridColumnsList { get; set; }
            //public List<FileDetails> loFileDetailsList { get; set; }
            public IEnumerable<dynamic> loFileDetailsList { get; set; }
            public IEnumerable<dynamic> loDownloadedSummaryList { get; set; }

        }
    }
}