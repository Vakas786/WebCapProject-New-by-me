﻿using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Newtonsoft.Json;

namespace CtsWebCoreOutward.Authorize
{

    public static class SessionExtensions
    {
        public static void SetObjectAsJson(this ISession session, string key, object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }
        public static T GetObjectFromJson<T>(this ISession session, string key)
        {
            var value = session.GetString(key);
            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
        }
    }
    public class AuthorizeRoleAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var appUserInfo = filterContext.HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");

            if (appUserInfo == null)
            {
                filterContext.Result = new RedirectToRouteResult("Default",
                new RouteValueDictionary { { "controller", "Login" }, { "action", "dologin" } });
            }

            base.OnActionExecuting(filterContext);
        }
    }
}