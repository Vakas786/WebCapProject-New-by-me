﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using Microsoft.EntityFrameworkCore;
using CtsWebCoreOutward.ViewModel;

namespace CtsWebCoreOutward.Models
{
    public class DownloadFileDataContext :DbContext
    {
         public DownloadFileDataContext(DbContextOptions<DownloadFileDataContext> options)
            : base(options)
        { }

        //public DbSet<DownloadFileViewModel.BatchGridColumns> DBSet_BatchGridColumns { get; set; }
        //public DbSet<DownloadFileViewModel.FileDetails> DBSet_FileDetails { get; set; }
        public DbSet<DownloadFileViewModel.DownloadFileConfigure> DBSet_DownloadFileConfigure { get; set; }
        public DbSet<DownloadFileViewModel.FileDownloadBOFD> DBSet_FileDownloadBOFD { get; set; }
        //public DbSet<DownloadFileViewModel.ModuleFields> DBSet_ModuleFields { get; set; }
        //public DbSet<DownloadFileViewModel.BatchGridColumnsString> DBSet_BatchGridColumnsString { get; set; }
        //public DbSet<DownloadFileViewModel.TransactionCodeMaster> DBSet_TransactionCodeMaster { get; set; }
        public DbSet<DownloadFileViewModel.FileDownloadData> DBSet_FileDownloadData { get; set; }



    }
}