﻿using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;
using static CtsWebCoreOutward.ViewModel.ReportsViewModel;

namespace CtsWebCoreOutward.Models
{
    public class ReportsDataContext : DbContext
    {
        public ReportsDataContext(DbContextOptions<ReportsDataContext> options)
            : base(options)
        { }
        public DbSet<ReportDetails> DBSet_ReportDetails { get; set; }
        public DbSet<ReportCriteria> DBSet_ReportCriteria { get; set; }
        public DbSet<ReportGridColumns> DBSet_ReportGridColumns { get; set; }
        public DbSet<ReportsGridColumnsString> DBSet_ReportsGridColumnsString { get; set; }
    }
}