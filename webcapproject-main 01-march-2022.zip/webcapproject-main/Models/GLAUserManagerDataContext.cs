﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using static CtsWebCoreOutward.ViewModel.GLAUserManagerViewModel;

namespace CtsWebCoreOutward.Models
{
    public class GLAUserManagerDataContext : DbContext
    {
        public GLAUserManagerDataContext(DbContextOptions<GLAUserManagerDataContext> options)
            : base(options)
        { }

        public DbSet<UserInfo> DBSet_UserInfo { get; set; }
        public DbSet<UserGroup> DBSet_UserGroup { get; set; }
        public DbSet<TransactionCodeMaster> DBSet_TransactionCodeMaster { get; set; }
    }
}