﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CtsWebCoreOutward.ViewModel
{
    public class UserGroupManagerViewModel
    {
        public class UserGroup
        {
            [Key]
            public Int32 UserGroupID { get; set; }
            public string UserGroupName { get; set; }
            public string UserGroupDescription { get; set; }
        }

        public class UserGroupDtl
        {
            [Key]
            public Int32 UserGroupDtlID { get; set; }
            public Int32 UserGroupID { get; set; }
            public Int32 FunctionNumber { get; set; }
        }
        public class ModuleFunctionTbl
        {
            [Key]
            public Int32 FunctionNumber { get; set; }
            public string Name { get; set; }
            public bool Checked { get; set; }
        }

        public class ModuleFunctionCheckModel
        {
            [Key]
            public int Id { get; set; }
            public string Name { get; set; }
            public bool Checked { get; set; }
        }

        public class AddUserGroup
        {
            public Int32 UserGroupID { get; set; }
            public IList<UserGroupDtl> UserGroupDtlList { get; set; }
            public Nullable<int> iFuntionNo { get; set; }
            public IList<UserGroup> UserGroupList { get; set; }
            public IList<ModuleFunctionTbl> ModuleFunctionList { get; set; }

            [Display(Name = "User Group Name")]
            public string UserGroupName { get; set; }

            [Display(Name = "Description")]
            public string UserGroupDescription { get; set; }
  
            //Constructor
            public AddUserGroup()
            {
                //Create Objects
            }
        }

        public class TransactionCodeMaster
        {
            [Key]
            public string stNo { get; set; }
        }
    }
}