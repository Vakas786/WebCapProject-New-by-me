﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class BatchBalancingViewModel
    {
        public BatchDetails loBatchDetails { get; set; }

        public List<RecordTypeValidationDetails> loRecordTypeValidationDetailList { get; set; }

        public BatchBalancing loBatchBalancing { get; set; }

        public List<BatchBalancing> loBatchDeailsLBNR { get; set; }

        public List<BatchBalancing> loBatchDetailsRBNL { get; set; }

        public List<SummaryLBNR> loSummaryLBNR { get; set; }

       public class BatchBalancing
        {
            [Key]
            public Int32 InstrumentDtlID { get; set; }
            public string ChequeNo { get; set; }
            public string SortCode { get; set; }
            public string BaseNo { get; set; }
            public string TC { get; set; }
            public decimal Amount { get; set; }
            public string AccountName { get; set; }
            public string AccountNo { get; set; }
            public string UDK { get; set; }
            public string BankNo { get; set; }
            public string CityNo { get; set; }
            public string BranchNo { get; set; }
            public int? RCStatus { get; set; }
            public string RowColor { get; set; }
            public string DocType { get; set; }
        }

        public class SummaryLBNR
        {
            [Key]
            public string Descriptions { get; set; }
            public string RBNL { get; set; }
            public string LBNR { get; set; }
        }

        public class BatchDetails
        {
            public string stBlockNo { get; set; }
            [Key]
            public string stBatchNo { get; set; }
            public string stSorterNo { get; set; }
            public int stInstrumentMainID { get; set; }

        }

        public class RecordTypeValidationDetails
        {
            public Int32 inRecTypeDtlID { get; set; }
            public Int32 inRecTypeID { get; set; }
            [Key]
            public string stFieldName { get; set; }
            public string stCaption { get; set; }
            public bool FlgIsActive { get; set; }
            public Int32 inFieldLength { get; set; }
            public Int32 inDisplaySeqNo { get; set; }
            public string stValidateScheme { get; set; }
            public string stOnKeyPress { get; set; }
        }
        public class ChequeImage
        {
            [Key]
            public byte[] stImage { get; set; }
            //public byte[] stGrImage { get; set; }
        }


        public List<string> loCityMasterList { get; set; }
        public List<string> loBankMasterList { get; set; }
        public List<string> loBranchMasterList { get; set; }

        public List<string> loTransactionCodeMasterList { get; set; }

    }
}