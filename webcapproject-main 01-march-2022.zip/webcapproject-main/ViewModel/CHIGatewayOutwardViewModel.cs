﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CtsWebCoreOutward.ViewModel
{
    public class CHIGatewayOutwardViewModel
    {

        public class TransactionCodeMaster
        {
            [Key]
            public string stNo { get; set; }
        }

        public class ResProcessStatusUDK
        {
            [Key]
            public int iRESProcessCount { get; set; }
        }

        public class InHouseInstrumentsDtl
        {
            public string ChequeNo { get; set; }
            public string Amount { get; set; }
            [Key]
            public string ItemSeqNo { get; set; }
            public string SortCode { get; set; }
            public string TC { get; set; }
            public string BatchNo { get; set; }
            public string ReasonCode { get; set; }
            public string ReturnReason { get; set; }
        }
        public class CXFInformation
        {

            public string CLGType { get; set; }
            public string TBRN { get; set; }
            public string UploadDate { get; set; }
            public Nullable<int> iCount { get; set; }
            public string Amount { get; set; }

            public string Gen_SesNo { get; set; }

            [Key]
            public string Gen_FileName { get; set; }
            public string Gen_TotalItem { get; set; }
            public string Gen_status { get; set; }
            public string Gen_Rejected { get; set; }
            public string Gen_Accpted { get; set; }

             public string Inward_FileType { get; set; }
             public string Inward_AvailableFileCount { get; set; }
             public string Inward_DownloadFileCount { get; set; }

            public string Return_FileName { get; set; }
            public string Return_Status { get; set; }
            public string Return_TotalCount { get; set; }

            public string Ses_SesNo { get; set; }
            public string Ses_SessionFor { get; set; }
            public string Ses_StartTime { get; set; }
            public string Ses_EndTime { get; set; }
            public string Ses_Status { get; set; }



        }

        public List<CXFInformation> loCXFItemList { get; set; }
        public List<CXFInformation> loCXFGeneratedStatusList { get; set; }
        public List<CXFInformation> loInwardReturnFileDetailsList { get; set; }
        public List<CXFInformation> loInwardReturnFileReturnFileList { get; set; }
        public List<CXFInformation> loSessionDetailsList { get; set; }
        public List<CXFInformation> loSessionReturnSessionList { get; set; }
        public List<InHouseInstrumentsDtl> loInHouseInstrumentsDtlList { get; set; }
        public List<InHouseInstrumentsDtl> loInHouseInstrumentsDtlReturnList { get; set; }
    }
}