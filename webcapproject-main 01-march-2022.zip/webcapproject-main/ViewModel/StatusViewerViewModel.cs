﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class StatusViewerViewModel
    {

        public class StatusViewerGridColumns
        {
            [Key]
            public string stFieldName { get; set; }
            public string stWidth { get; set; }
            public string stDisplayCaption { get; set; }
        }
        public class StatusViewerGridColumnsString
        {
            [Key]
            public string BatchGridDisplayColumns { get; set; }
        }

        public class WrapperStatusViewer
        {
            public List<StatusViewerGridColumns> loStatusViewerGridColumnsList { get; set; }
            //public List<BatchSelection> loBatchSelectionList { get; set; }

            public IEnumerable<dynamic> loStatusViewerList { get; set; }
        }
    }
}