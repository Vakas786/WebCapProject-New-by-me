﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.ViewModel
{
    public class ReportsViewModel
    {

        public class ReportDetails
        {
            [Key]
            public int ReportID { get; set; }
            public string ReportName { get; set; }
        }

        public class  ReportCriteria
        {
            
            public int ReportID { get; set; }
            [Key]
            public string Caption { get; set; }
            public string MappingField { get; set; }
            public string DataType { get; set; }
            public bool RangeRequired { get; set; }
            
        }

        public class ReportGridColumns
        {
            [Key]
            public string stFieldName { get; set; }
            public string stWidth { get; set; }
            public string stDisplayCaption { get; set; }
        }

        public class ReportsGridColumnsString
        {
            [Key]
            public string ReportsGridDisplayColumns { get; set; }
            public string ReportName { get; set; }
            public string ReportPath { get; set; }
            public string PDFFileName { get; set; }
            public string TotalFieldColumns { get; set; }
            public string GroupFieldColumns { get; set; }
            public bool IsRDLCRep { get; set; }
            public string RDLCName { get; set; }
            public bool IsLandscap { get; set; }
            public string FooterTotalFields { get; set; }
        }
        public class WrapperReports
        {
            public List<ReportGridColumns> loReportsGridColumnsList { get; set; }
            public List<ReportDetails> loReportsList { get; set; }
            public List<ReportCriteria> loReportCriteriaList { get; set; }
            public string stReportIDValue { get; set; }
            //public IEnumerable<dynamic> loChequeDetailList { get; set; }
            public Nullable<int> iFuntionNo { get; set; }
            public Nullable<int> iReportId { get; set; }
            public string sWhere { get; set; }
            public string sReportName { get; set; }
            public string sReportPath { get; set; }
            public string sPDFFileName { get; set; }
            public string sTotalFieldColumns { get; set; }
            public string sGroupFieldColumns { get; set; }
            public bool IsRDLCRep { get; set; }
            public string RDLCName { get; set; }
            public bool IsLandscap { get; set; }
            public string FooterTotalFields { get; set; }
        }
    }
}