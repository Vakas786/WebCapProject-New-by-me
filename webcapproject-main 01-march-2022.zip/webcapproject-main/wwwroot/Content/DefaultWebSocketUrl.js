//
// Copyright © 2014-2018, Silver Bullet Technology, Inc.
//

function GetUserDefinedUrl() {
  return "ws://127.0.0.1:9002"
}
