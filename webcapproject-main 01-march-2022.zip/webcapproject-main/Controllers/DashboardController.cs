﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.Filter;
using System.Data.SqlClient;
using CtsWebCoreOutward.ViewModel;
using CtsWebCoreOutward.ComonUtility;
using System.Data;
using System.Globalization;
using FACoreDAC;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Reflection;
using System.IO;

namespace CtsWebCoreOutward.Controllers
{
    
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class DashboardController : Controller
    {
        // 
        // GET: /KeepAlive
        
        [AllowAnonymous]
        public ActionResult KeepAlive()
        {
            return Content("I am alive!");
        }

        public ActionResult Dashboard(int? id)
        {
            //var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            return View();
        }
        public ActionResult DashboardView(int? id)
        {

            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            DataSet dataSet = new DataSet();

            var sqlParameterMain = new List<SqlParameter>();
            sqlParameterMain.Add(new SqlParameter("@pBRNo", appUserInfo.stPhBRNo));
            dataSet.Tables.Add(MsSQL.GetDataTable("WebProc_DashboardMain", sqlParameterMain.ToArray(), CommonFunctions.ConStr, Path.Combine(CommonFunctions.AppLogPath, MethodBase.GetCurrentMethod().Name)));

            sqlParameterMain = new List<SqlParameter>();
            sqlParameterMain.Add(new SqlParameter("@pBRNo", appUserInfo.stPhBRNo));
            dataSet.Tables.Add(MsSQL.GetDataTable("WebProc_DashboardWeekly", sqlParameterMain.ToArray(), CommonFunctions.ConStr, Path.Combine(CommonFunctions.AppLogPath, MethodBase.GetCurrentMethod().Name)));

            return View("DashboardView", dataSet);
        }

        [HttpPost]
        public ActionResult SetUserLastTimeActive(string PKey)
        {
            string _SQLQry = "UPDATE UserInfo SET lastTimeActive ='" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture) + "' WHERE UserInfoID='" + PKey + "';";
            MsSQL.ExecuteNonQuery(_SQLQry, CommonFunctions.ConStr, Path.Combine(CommonFunctions.AppLogPath, MethodBase.GetCurrentMethod().Name));
            return Json(new
            {
                Sts = "1",
                Msg = "Set User Last Time Active Success!",
                Res = ""
            });
        }
    }
}
