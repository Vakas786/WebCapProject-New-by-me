﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Common;
using Microsoft.EntityFrameworkCore;
using CtsWebCoreOutward.ViewModel;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Models
{
    public class BatchBalancingDataContext : DbContext
    {
        public BatchBalancingDataContext(DbContextOptions<BatchBalancingDataContext> options)
            : base(options)
        { }

        public DbSet<BatchBalancingViewModel.RecordTypeValidationDetails> DBSet_RecordTypeValidationDetails { get; set; }
        public DbSet<BatchBalancingViewModel.BatchDetails> DBSet_BatchDetails { get; set; }
        public DbSet<BatchBalancingViewModel.BatchBalancing> DBSet_BatchBalancing { get; set; }
        public DbSet<BatchBalancingViewModel.SummaryLBNR> DBSet_SummaryLBNR { get; set; }
        public DbSet<BatchBalancingViewModel.ChequeImage> DBSet_ChequeImage { get; set; }

        public DbSet<DataEntryViewModel.ModuleFields> DBSet_ModuleFields { get; set; }
        public DbSet<DataEntryViewModel.CityMaster> DBSet_CityMaster { get; set; }
        public DbSet<DataEntryViewModel.BankMaster> DBSet_BankMaster { get; set; }
        public DbSet<DataEntryViewModel.BranchMaster> DBSet_BranchMaster { get; set; }
        public DbSet<DataEntryViewModel.TransactionCodeMaster> DBSet_TransactionCodeMaster { get; set; }
        public DbSet<DataEntryViewModel.BatchCurrentStatus> DBSet_BatchCurrentStatus { get; set; }
        public DbSet<BatchSelectionGridColumnsString> DBSet_BatchSelectionGridColumnsString { get; set; }

        public DbSet<PermissionMaster> DBSet_PermissionMaster { get; set; }
    }
}