﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.ViewModel;
using System.Data;
using System.Data.Common;
using CtsWebCoreOutward.ComonUtility;
using Microsoft.EntityFrameworkCore;

namespace CtsWebCoreOutward.Models
{
    public class SODDataContext : DbContext
    {
        public SODDataContext(DbContextOptions<SODDataContext> options)
            : base(options)
        { }
        public DbSet<SODViewModel.WrapperSOD> DBSet_SODViewModel { get; set; }
        public DbSet<SODViewModel.PermissionMaster> DBSet_PermissionMaster { get; set; }

        
    }
}