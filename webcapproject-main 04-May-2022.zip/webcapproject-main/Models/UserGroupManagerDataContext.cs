﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.UserGroupManagerViewModel;

namespace CtsWebCoreOutward.Models
{
    public class UserGroupManagerDataContext : DbContext
    {
        public UserGroupManagerDataContext(DbContextOptions<UserGroupManagerDataContext> options)
            : base(options)
        { }

        public DbSet<UserGroup> DBSet_UserGroup { get; set; }
        public DbSet<ModuleFunctionTbl> DBSet_ModuleFunctionTbl { get; set; }
        public DbSet<UserGroupDtl> DBSet_UserGroupDtl { get; set; }
        public DbSet<ModuleFunctionCheckModel> DBSet_ModuleFunctionCheckModel { get; set; }
        //public DbSet<ModuleFunctionTbl> DBSet_AdminLoginViewModel { get; set; }

    }
}