﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Controllers
{
	[AuthorizeRole]
	public class ImageDataEntryController : Controller
	{
		private readonly DataEntryDataContext _DBContext;
		public ImageDataEntryController(DataEntryDataContext dbContext) { _DBContext = dbContext; }
		public IActionResult ImageDataEntry(int? id)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
			ViewBag.sToday = appUserInfo.sToday;
			
			DataEntryViewModel.WrapperDataEntry loWrapperDataEntry = new DataEntryViewModel.WrapperDataEntry();
			int iFuntionNumber = 100;
			if (id != null)
			{
				iFuntionNumber = Convert.ToInt16(id);
			}

			//DataEntryViewModel.FuntionSP loFucntionSP = new DataEntryViewModel.FuntionSP();
			//loFucntionSP = GetFunctionSpName(iFuntionNumber);
			//ViewBag.sSP = loFucntionSP.SPName;
			//ViewBag.Title = loFucntionSP.ModuleName;

			loWrapperDataEntry.iFuntionNo = iFuntionNumber;

			loWrapperDataEntry.loModuleFieldsList = getModuleFieldsList(iFuntionNumber.ToString());
			return View(loWrapperDataEntry);
		}

		public ActionResult BackMenu(string fsSp, string fsFunctionNo)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			string fsUserName = appUserInfo.stLoginName;
			string sUnlockSP = fsSp.Split('~')[2];
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql(sUnlockSP.getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			//return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
			return Json(new { response = "true" });
		}

		public ActionResult saveChequeDetails(string fsSp, string fsUDKID, string fsParamList, string fsParamValue, string fsFunctionNo, string fsDETYPE)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();

			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			string fsUserName = appUserInfo.stLoginName;

			string sUpdateSP = fsSp.Split('~')[1];

			string[] lstParam = fsParamList.Split('|');
			string[] lstParamVal = fsParamValue.Split('|');
			for (int i = 0; i < lstParam.Length; i++)
			{
				loSqlParameters.Add(new SqlParameter("st" + lstParam[i].ToString(), lstParamVal[i].ToString().handleDBNull()));
			}

			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUserName", fsUserName.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stDETYPE", fsDETYPE.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql(sUpdateSP.getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return Json(new { response = "true" });
		}

		public ActionResult getChequeImageByImageType(string fsImageType, string fsUDKID)
		{
			//List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			//loSqlParameters.Add(new SqlParameter("iUDK", fsUDKID.handleDBNull()));
			//loSqlParameters.Add(new SqlParameter("iType", fsImageType.handleDBNull()));
			//var loChequeImage = _DBContext.DBSet_ChequeImage.FromSql("WebProc_GetChequeImageByType".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault(); ;

			//string lsImage = string.Empty;
			//if (loChequeImage != null)
			//{
			//	if ((fsImageType == "2") || (fsImageType == "3"))
			//	{
			//		loChequeImage.stImage = CommonFunctions.ConvertTiffToJpeg(loChequeImage.stImage);
			//	}
			//	lsImage = Convert.ToBase64String(loChequeImage.stImage);
			//}

			//return Json(new { response = lsImage });
			
			string sPath = CommonFunctions.AppTempPath;
			string lsImage = string.Empty;
			ChequeImage loChequeImage = new ChequeImage();
			//loChequeImage.stImage = System.IO.File.ReadAllBytes(sPath+"//"+ "111111.tif");
			loChequeImage.stImage = CommonFunctions.ConvertTiffToJpeg(loChequeImage.stImage);
			lsImage = Convert.ToBase64String(loChequeImage.stImage);
			return Json(new { response = lsImage });
		}
		public FuntionSP GetFunctionSpName(Int32 iFunctionNumber)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("functionNumber", iFunctionNumber.handleDBNull()));
			return _DBContext.DBSet_FuntionSP.FromSql("USP_GetSpByFunctionNumber".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}
		public List<DataEntryViewModel.ModuleFields> getModuleFieldsList(String fsFunctionNo)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stFunction", fsFunctionNo.handleDBNull()));
				return _DBContext.DBSet_ModuleFields.FromSql("getModuleFields".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception ex)
			{
				return null;
			}
		}

		[HttpPost]
		public ActionResult getText(string base64image)
		{
			string path = CommonFunctions.AppTempPath;
			string imageName =  "myPravin.jpeg";
			string imgPath = System.IO.Path.Combine(path, imageName);
			if (base64image != "")
			{
				base64image = base64image.Split(',')[1].ToString();
				
				byte[] imageBytes = Convert.FromBase64String(base64image);
				System.IO.File.WriteAllBytes(imgPath, imageBytes);

			}
			string sValue = "";
			string url = "http://103.10.234.102:9099/home/OcrString";
			// for number url will be :  string url="http://103.10.234.102:9099/home/OcrNumber";
			try
			{
				var cliImg = new WebClient();
				cliImg.Headers[HttpRequestHeader.ContentType] = "application/json";
				byte[] rawResponse = cliImg.UploadFile(url, "POST", imgPath);
				string response = System.Text.Encoding.ASCII.GetString(rawResponse);
				sValue = response;
			}

			catch (Exception ex)
			{
				sValue = "";
			}



			return Json(new { sValue });
		}
	}
}
