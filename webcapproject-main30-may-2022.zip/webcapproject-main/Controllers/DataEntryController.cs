﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Nancy.Json;
using Newtonsoft.Json;
using static CtsWebCoreOutward.ViewModel.DataEntryViewModel;

namespace CtsWebCoreOutward.Controllers
{
	[AuthorizeRole]
	public class DataEntryController : Controller
	{
		public static IConfiguration _configuration;
		private readonly DataEntryDataContext _DBContext;
		public DataEntryController(DataEntryDataContext dbContext, IConfiguration configuration) { 
			_DBContext = dbContext;
			_configuration = configuration;
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public ActionResult List(int? id)
		{
			//BatchSelectionDataContext loBatchSelectionDataContext = new BatchSelectionDataContext();

			WrapperBatchSelection loWrapperBatchSelection = new WrapperBatchSelection();
			//loWrapperBatchSelection.loBatchSelectionList = new List<BatchSelectionViewModel.BatchSelection>();
			//loWrapperBatchSelection.loBatchSelectionList = loBatchSelectionDataContext.getBatchSelectionList();

			loWrapperBatchSelection.iFuntionNumber = id;
			BatchSelectionGridColumnsString loBatchSelectionGridColumnsString = new BatchSelectionGridColumnsString();
			loBatchSelectionGridColumnsString = getBatchGridDisplayColumns(Convert.ToInt16(loWrapperBatchSelection.iFuntionNumber));


			loWrapperBatchSelection.loBatchSelectionGridColumnsList = new List<BatchSelectionGridColumns>();
			string[] lsGridColumnMainArray = loBatchSelectionGridColumnsString.BatchGridDisplayColumns.Split('|');
			foreach (var loData in lsGridColumnMainArray)
			{
				string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

				BatchSelectionGridColumns loBatchSelectionGridColumns = new BatchSelectionGridColumns();
				loBatchSelectionGridColumns.stFieldName = lsGridValues[0];
				loBatchSelectionGridColumns.stWidth = lsGridValues[1];
				loBatchSelectionGridColumns.stDisplayCaption = lsGridValues[2];

				loWrapperBatchSelection.loBatchSelectionGridColumnsList.Add(loBatchSelectionGridColumns);
			}
			// string sBOFD = ((AdminLoginViewModel)Session["WebCTSAdmin"]).stPhBRNo;

			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");

			loWrapperBatchSelection.loBatchSelectionList = getBatchSelectionList(Convert.ToInt16(loWrapperBatchSelection.iFuntionNumber), appUserInfo.stPhBRNo);

			if (TempData["BatchIslocked"] != null)
			{
				ViewData["BatchIslocked"] = (string)TempData["BatchIslocked"];
				TempData["BatchIslocked"] = null;
			}

			if (TempData["CurrentBatchInProcess"] != null)
			{
				Int64 iInstrumentMainID = Convert.ToInt64(TempData["InstrumentMainID"]);
				string lsBatchNo = (string)TempData["CurrentBatchInProcess"];
				TempData["CurrentBatchInProcess"] = null;
				TempData["InstrumentMainID"] = null;
				//BatchSelectionDataContext loUpdateBatchSelectionDataContext = new BatchSelectionDataContext();
				bool lbIsUpdated = updateLockStautByBatchNo(Convert.ToInt16(0), iInstrumentMainID, appUserInfo.stPhBRNo);
			}

			if (TempData["LastProcessedBacthNo"] != null)
			{
				ViewData["LastProcessedBacthNo"] = (string)TempData["LastProcessedBacthNo"];
				TempData["LastProcessedBacthNo"] = null;
			}
			else
			{
				ViewData["LastProcessedBacthNo"] = "";
			}

			List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();
			loPermissionMasterList = getUserPermissionByFunctionNumber(Convert.ToInt32(id));
			loWrapperBatchSelection.sCall_Action = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_action).FirstOrDefault();
			//loWrapperBatchSelection.sCall_Controller = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_Controller).FirstOrDefault();
			loWrapperBatchSelection.sController = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Controller).FirstOrDefault();

			return View(loWrapperBatchSelection);
		}

		public ActionResult DataEntry(int? id, string InstrumentMainID)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
			ViewBag.sToday = appUserInfo.sToday;

			DataEntryViewModel.WrapperDataEntry loWrapperDataEntry = new DataEntryViewModel.WrapperDataEntry();
			if (!string.IsNullOrEmpty(InstrumentMainID))
			{
				string lsInstrumentMainID = InstrumentMainID;
				//string sLoginName = ((AdminLoginViewModel)Session["WebCTSAdmin"]).stLoginName;

				//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
				var loBatchCurrentStatus = checkBatchStatusM(lsInstrumentMainID, appUserInfo.stLoginName);
				string lsBatchNo = loBatchCurrentStatus.stBatchNo;
				if (loBatchCurrentStatus != null && loBatchCurrentStatus.inLockStatus == 0)
				{
					//loDataEntryDataContext = new DataEntryDataContext();

					//loWrapperDataEntry.loCheckDetailsList = new List<DataEntryViewModel.CheckDetails>();
					//loWrapperDataEntry.loCheckDetailsList = loDataEntryDataContext.getChequeDetailsByBatchID(lsBatchNo);

					loWrapperDataEntry.loCheckDetailsList = getChequeDetailsByBatchID(lsInstrumentMainID);
					int iFuntionNumber = 100;
					if (id != null)
					{
						iFuntionNumber = Convert.ToInt16(id);
					}



					loWrapperDataEntry.iFuntionNo = iFuntionNumber;

					loWrapperDataEntry.loModuleFieldsList = getModuleFieldsList(iFuntionNumber.ToString());

					DataEntryViewModel.BatchGridColumnsString loBatchGridColumnsString = new DataEntryViewModel.BatchGridColumnsString();
					loBatchGridColumnsString = getGridDisplayColumns(iFuntionNumber);

					loWrapperDataEntry.loBatchGridColumnsList = new List<DataEntryViewModel.BatchGridColumns>();
					string[] lsGridColumnMainArray = loBatchGridColumnsString.GridDisplayColumns.Split('|');

					foreach (var loData in lsGridColumnMainArray)
					{
						string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

						DataEntryViewModel.BatchGridColumns BatchGridColumns = new DataEntryViewModel.BatchGridColumns();
						BatchGridColumns.stFieldName = lsGridValues[0];
						BatchGridColumns.stWidth = lsGridValues[1];
						BatchGridColumns.stDisplayCaption = lsGridValues[2];

						loWrapperDataEntry.loBatchGridColumnsList.Add(BatchGridColumns);
					}



					loWrapperDataEntry.loDataEntry = new DataEntryViewModel.DataEntry();
					loWrapperDataEntry.loCityMasterList = new List<string>();
					loWrapperDataEntry.loBankMasterList = new List<string>();
					loWrapperDataEntry.loBranchMasterList = new List<string>();
					loWrapperDataEntry.loTransactionCodeMasterList = new List<string>();

					List<DataEntryViewModel.CityMaster> loCityMasterList = new List<DataEntryViewModel.CityMaster>();
					loCityMasterList = getCityList();

					List<DataEntryViewModel.BankMaster> loBankMasterList = new List<DataEntryViewModel.BankMaster>();
					loBankMasterList = getBankList();

					List<DataEntryViewModel.BranchMaster> loBranchMasterList = new List<DataEntryViewModel.BranchMaster>();
					loBranchMasterList = getBranchList();

					List<DataEntryViewModel.TransactionCodeMaster> loTransactionCodeMasterList = new List<DataEntryViewModel.TransactionCodeMaster>();
					loTransactionCodeMasterList = getTransactionCodeList();

					loWrapperDataEntry.loCityMasterList = loCityMasterList.Select(x => x.stCityNo).ToList();
					loWrapperDataEntry.loBankMasterList = loBankMasterList.Select(x => x.stBankNo).ToList();
					loWrapperDataEntry.loBranchMasterList = loBranchMasterList.Select(x => x.stBranchNo).ToList();
					loWrapperDataEntry.loTransactionCodeMasterList = loTransactionCodeMasterList.Select(x => x.stTCNo).ToList();

					loWrapperDataEntry.loBatchDetails = new DataEntryViewModel.BatchDetails();
					loWrapperDataEntry.loBatchDetails = getBatchDetailsByBatchID(lsInstrumentMainID);



					loWrapperDataEntry.loRecordTypeValidationDetailList = getRecordTypeByRecTypeIDM(2);

					List<DataEntryViewModel.RecordTypeFromDB> loRecordTypeFromDBList = new List<DataEntryViewModel.RecordTypeFromDB>();
					loRecordTypeFromDBList = getRecordTypeForDropdown();

					loWrapperDataEntry.loRecordTypeList = getRecordTypeForDropdown();

					TempData["CurrentBatchInProcess"] = lsBatchNo;
					TempData["InstrumentMainID"] = InstrumentMainID;

					List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();
					loPermissionMasterList = getUserPermissionByFunctionNumber(Convert.ToInt32(id));
					loWrapperDataEntry.sCall_Action = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_action).FirstOrDefault();
					//loWrapperDataEntry.sCall_Controller = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_Controller).FirstOrDefault();
					loWrapperDataEntry.sController = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Controller).FirstOrDefault();


					return View(loWrapperDataEntry);
				}
				else
				{
					TempData["BatchIslocked"] = lsBatchNo;
					//return RedirectToAction("List", "BatchSelection");
					return RedirectToRoute("default", new { controller = "DataEntry", action = "List", id = id });
				}
			}
			else
			{
				return RedirectToRoute("default", new { controller = "DataEntry", action = "List", id = id });
			}
		}

		public ActionResult DataEntry2(int? id)
		{
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
			ViewBag.stPhBRNo = appUserInfo.stPhBRNo;
			ViewBag.sToday = appUserInfo.sToday;

			DataEntryViewModel.WrapperDataEntry loWrapperDataEntry = new DataEntryViewModel.WrapperDataEntry();
			//if (!string.IsNullOrEmpty(InstrumentMainID))
			//{
			//  string lsInstrumentMainID = InstrumentMainID;
			//string sLoginName = ((AdminLoginViewModel)Session["WebCTSAdmin"]).stLoginName;

			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			//var loBatchCurrentStatus = checkBatchStatusM(lsInstrumentMainID, appUserInfo.stLoginName);
			//string lsBatchNo = loBatchCurrentStatus.stBatchNo;
			
			loWrapperDataEntry.loCheckDetailsList = getChequeDetails(appUserInfo.stLoginName,"");

			if (loWrapperDataEntry.loCheckDetailsList != null && loWrapperDataEntry.loCheckDetailsList.Count() > 0)
			{
				int iFuntionNumber = 100;
				if (id != null)
				{
					iFuntionNumber = Convert.ToInt16(id);
				}


				loWrapperDataEntry.iFuntionNo = iFuntionNumber;

				loWrapperDataEntry.loModuleFieldsList = getModuleFieldsList(iFuntionNumber.ToString());

				DataEntryViewModel.BatchGridColumnsString loBatchGridColumnsString = new DataEntryViewModel.BatchGridColumnsString();
				loBatchGridColumnsString = getGridDisplayColumns(iFuntionNumber);

				loWrapperDataEntry.loBatchGridColumnsList = new List<DataEntryViewModel.BatchGridColumns>();
				string[] lsGridColumnMainArray = loBatchGridColumnsString.GridDisplayColumns.Split('|');

				foreach (var loData in lsGridColumnMainArray)
				{
					string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

					DataEntryViewModel.BatchGridColumns BatchGridColumns = new DataEntryViewModel.BatchGridColumns();
					BatchGridColumns.stFieldName = lsGridValues[0];
					BatchGridColumns.stWidth = lsGridValues[1];
					BatchGridColumns.stDisplayCaption = lsGridValues[2];

					loWrapperDataEntry.loBatchGridColumnsList.Add(BatchGridColumns);
				}



				loWrapperDataEntry.loDataEntry = new DataEntryViewModel.DataEntry();
				loWrapperDataEntry.loCityMasterList = new List<string>();
				loWrapperDataEntry.loBankMasterList = new List<string>();
				loWrapperDataEntry.loBranchMasterList = new List<string>();
				loWrapperDataEntry.loTransactionCodeMasterList = new List<string>();

				List<DataEntryViewModel.CityMaster> loCityMasterList = new List<DataEntryViewModel.CityMaster>();
				loCityMasterList = getCityList();

				List<DataEntryViewModel.BankMaster> loBankMasterList = new List<DataEntryViewModel.BankMaster>();
				loBankMasterList = getBankList();

				List<DataEntryViewModel.BranchMaster> loBranchMasterList = new List<DataEntryViewModel.BranchMaster>();
				loBranchMasterList = getBranchList();

				List<DataEntryViewModel.TransactionCodeMaster> loTransactionCodeMasterList = new List<DataEntryViewModel.TransactionCodeMaster>();
				loTransactionCodeMasterList = getTransactionCodeList();

				loWrapperDataEntry.loCityMasterList = loCityMasterList.Select(x => x.stCityNo).ToList();
				loWrapperDataEntry.loBankMasterList = loBankMasterList.Select(x => x.stBankNo).ToList();
				loWrapperDataEntry.loBranchMasterList = loBranchMasterList.Select(x => x.stBranchNo).ToList();
				loWrapperDataEntry.loTransactionCodeMasterList = loTransactionCodeMasterList.Select(x => x.stTCNo).ToList();

				//loWrapperDataEntry.loBatchDetails = new DataEntryViewModel.BatchDetails();
				//loWrapperDataEntry.loBatchDetails = getBatchDetailsByBatchID(lsInstrumentMainID);



				loWrapperDataEntry.loRecordTypeValidationDetailList = getRecordTypeByRecTypeIDM(2);

				List<DataEntryViewModel.RecordTypeFromDB> loRecordTypeFromDBList = new List<DataEntryViewModel.RecordTypeFromDB>();
				loRecordTypeFromDBList = getRecordTypeForDropdown();

				loWrapperDataEntry.loRecordTypeList = getRecordTypeForDropdown();

				//TempData["CurrentBatchInProcess"] = lsBatchNo;
				TempData["CurrentBatchInProcess"] = "";
				//TempData["InstrumentMainID"] = InstrumentMainID;
				TempData["InstrumentMainID"] = "";

				List<PermissionMaster> loPermissionMasterList = new List<PermissionMaster>();
				loPermissionMasterList = getUserPermissionByFunctionNumber(Convert.ToInt32(id));
				loWrapperDataEntry.sCall_Action = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_action).FirstOrDefault();
				//loWrapperDataEntry.sCall_Controller = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Call_Controller).FirstOrDefault();
				loWrapperDataEntry.sController = loPermissionMasterList.Where(x => x.FunctionNumber == Convert.ToInt32(id)).Select(x => x.Controller).FirstOrDefault();


				return View(loWrapperDataEntry);
			}
			else
			{

				return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
			}
			//}
			//else
			//{
			//    return RedirectToRoute("default", new { controller = "DataEntry", action = "List", id = id });
			//}
		}
		public ActionResult getCheckImage(string fsUDKID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			DataEntryViewModel.ChequeImage loChequeImage = getChequeImage(fsUDKID);

			string lsImage = string.Empty;
			if (loChequeImage != null)
			{
				lsImage = Convert.ToBase64String(loChequeImage.stImage);
			}

			return Json(new { response = lsImage });

			//if (!string.IsNullOrEmpty(loChequeImage.stImage))
			//    return Json(new { response = loChequeImage.stImage }, JsonRequestBehavior.AllowGet);
			//else
			//    return Json(new { response = "" }, JsonRequestBehavior.AllowGet);
		}


		public ActionResult saveChequeDetails(string fsUDKID, string fsParamList, string fsParamValue, string fsFunctionNo)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			bool lbStatus = updateChequeDetails_NEW(fsUDKID, fsParamList, fsParamValue, fsFunctionNo);
			return Json(new { response = "true" });
		}

		public ActionResult getNextBatchDetails(string fsInstrumentMainID, string fsFunctionNo, string fsBOFD)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			DataEntryViewModel.NextBatchDetails loNextBatchDetails = getNextBatchDetailsM(fsInstrumentMainID, fsFunctionNo, fsBOFD);
			return Json(new { loNextBatchDetails });
		}

		public ActionResult setUDKDeleteUndelete(string fsUDK, bool fbIsDelete)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			bool lbIsDelete = setUDKDeleteUndeleteM(fsUDK, fbIsDelete);

			if (fbIsDelete)
			{
				lbIsDelete = true;
			}
			else
			{
				lbIsDelete = false;
			}

			return Json(new { lbIsDelete });
		}

		public ActionResult getRecordTypeByRecTypeID(Int32 fiRecTypeID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			List<DataEntryViewModel.RecordTypeValidationDetails> loRecordTypeValidationDetailsList = getRecordTypeByRecTypeIDM(fiRecTypeID);

			return Json(new { loRecordTypeValidationDetailsList });
		}

		public ActionResult submitBatch(string fsSorterNo, string fsRefreshBlockNo, string fsAppNo, string fsInstrumentMainID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			bool lbStatus = submitBatchM(fsSorterNo, fsRefreshBlockNo, fsAppNo, fsInstrumentMainID);
			return Json(new { lbStatus });
		}

		public ActionResult getChequeImageByImageType(string fsImageType, string fsUDKID)
		{
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			DataEntryViewModel.ChequeImage loChequeImage = getChequeImageByImageTypeM(fsImageType, fsUDKID);

			string lsImage = string.Empty;
			if (loChequeImage != null)
			{
				if ((fsImageType == "2") || (fsImageType == "3"))
				{
					loChequeImage.stImage = CommonFunctions.ConvertTiffToJpeg(loChequeImage.stImage);
				}
				lsImage = Convert.ToBase64String(loChequeImage.stImage);
			}

			return Json(new { response = lsImage });

		}

		[HttpPost]
		public ActionResult checkBatchStatus(string fsInstrumentMainID)
		{
			//string stLoginName = ((Login.ViewModel.AdminLoginViewModel)Session["WebCTSAdmin"]).stLoginName;
			var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");

			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			var loBatchCurrentStatus = checkBatchStatusM(fsInstrumentMainID, appUserInfo.stLoginName);
			return Json(new { loBatchCurrentStatus });
		}

		public ActionResult unlockBatchByBatchNo(string fsBatchNo, string fsInstrumentMainID)
		{
			TempData["LastProcessedBactNo"] = fsBatchNo;
			//DataEntryDataContext loDataEntryDataContext = new DataEntryDataContext();
			var loResponse = unlockBatchByBatchNo(fsInstrumentMainID);

			return Json(new { loResponse });
		}

		public List<DataEntryViewModel.ModuleFields> getModuleFieldsList(string fsFunctionNo)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stFunction", fsFunctionNo.handleDBNull()));
				return _DBContext.DBSet_ModuleFields.FromSql("getModuleFields".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.CityMaster> getCityList()
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				return _DBContext.DBSet_CityMaster.FromSql("getCityList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.BankMaster> getBankList()
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				return _DBContext.DBSet_BankMaster.FromSql("getBankList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.BranchMaster> getBranchList()
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				return _DBContext.DBSet_BranchMaster.FromSql("getBranchList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
			}
			catch (Exception)
			{
				return null;
			}
		}

		public List<DataEntryViewModel.TransactionCodeMaster> getTransactionCodeList()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			return _DBContext.DBSet_TransactionCodeMaster.FromSql("getTransactionCodeList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public DataEntryViewModel.ChequeImage getChequeImage(string fsUDKID)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("skUDKID", fsUDKID.handleDBNull()));
				return _DBContext.DBSet_ChequeImage.FromSql("getChequeImage".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			}
			catch (Exception) { return null; }
		}

		public bool updateChequeDetails(string fsUDKID, string fsChequeNo, string fsCityNo, string fsBankNo, string fsBranchNo, string fsBaseNo, string fsTCNo, string fsSortCode, string fsStatusNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stChequeNo", fsChequeNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stCityNo", fsCityNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stBankNo", fsBankNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stBranchNo", fsBranchNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stBaseNo", fsBaseNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stTCNo", fsTCNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stSortCode", fsSortCode.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stStatusNo", fsStatusNo.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("updateChequeDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}

		public bool updateChequeDetails_NEW(string fsUDKID, string fsParamList, string fsParamValue, string fsFunctionNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stParamList", fsParamList.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stParamValue", fsParamValue.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stFunctionNo", fsFunctionNo.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("updateChequeDetails_New".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}

		public DataEntryViewModel.NextBatchDetails getNextBatchDetailsM(string fsInstrumentMainID, string fsFunctionNo, string fsBOFD)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("FunctionNumber", fsFunctionNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("BOFD", fsBOFD.handleDBNull()));
			return _DBContext.DBSet_NextBatchDetails.FromSql("getNextBatchDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public DataEntryViewModel.BatchDetails getBatchDetailsByBatchID(string fsInstrumentMainID)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
				return _DBContext.DBSet_BatchDetails.FromSql("getBatchDetailsByBatchID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			}
			catch (Exception ex)
			{
				throw ex;
			}

		}

		public List<DataEntryViewModel.RecordTypeFromDB> getRecordTypeForDropdown()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();

			return _DBContext.DBSet_RecordTypeFromDB.FromSql("getRecordTypeForDropdown".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public bool setUDKDeleteUndeleteM(string fsUDK, bool fbIsDelete)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDK", fsUDK.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("flgIsDelete", fbIsDelete.handleDBNull()));

			_DBContext.DBSet_TransactionCodeMaster.FromSql("setUDKDeleteUndelete".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

			return true;
		}

		public List<PermissionMaster> getUserPermissionByFunctionNumber(Int32 fiFunctionNumber)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("functionNumber", fiFunctionNumber.handleDBNull()));

			return _DBContext.DBSet_PermissionMaster.FromSql("USP_ModuleInfoByFuntionNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public bool submitBatchM(string fsSorterNo, string fsRefreshBlockNo, string fsAppNo, string fsInstrumentMainID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("sSorterNo", fsSorterNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iRefreshBlockNo", fsRefreshBlockNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iAppNo", fsAppNo.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iInstrumentMainID", fsInstrumentMainID.handleDBNull()));
			_DBContext.DBSet_TransactionCodeMaster.FromSql("USP_SubmitBatch".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			return true;
		}

		public bool submitBatch_verifier(string fsInstrumentMainID, string fsAppNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("InstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("iAppNo", fsAppNo.handleDBNull()));
			_DBContext.DBSet_TransactionCodeMaster.FromSql("USP_SubmitBatch_Verifier".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			return true;
		}

		public List<DataEntryViewModel.RecordTypeValidationDetails> getRecordTypeByRecTypeIDM(Int32 fiRecTypeID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("inRecTypeID", fiRecTypeID.handleDBNull()));
			return _DBContext.DBSet_RecordTypeValidationDetails.FromSql("getRecordTypeByRecTypeID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public DataEntryViewModel.BatchGridColumnsString getGridDisplayColumns(Int32 iFunctionNo)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("FunctionNo", iFunctionNo.handleDBNull()));
			return _DBContext.DBSet_BatchGridColumnsString.FromSql("USP_GetGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		//public List<DataEntryViewModel.CheckDetails> getChequeDetailsByBatchID(string fsBatchNo)
		//{
		//    List<SqlParameter> loSqlParameters = new List<SqlParameter>();
		//    loSqlParameters.Add(new SqlParameter("stBatchNo", fsBatchNo.handleDBNull()));

		//    return new DataEntryDataContext().Database.SqlQuery<DataEntryViewModel.CheckDetails>("getChequeDetailsByBatchID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		//}

		public IEnumerable<dynamic> getChequeDetailsByBatchID(string fsInstrumentMainID)
		{
			//using (var ctx = new DataEntryDataContext())
			var cmd = new SqlCommand();
			var con = new SqlConnection(CommonFunctions.ConStr);
			cmd.Connection = con;
			cmd.CommandText = "getChequeDetailsByBatchID";
			cmd.CommandType = CommandType.StoredProcedure;

			DbParameter param = cmd.CreateParameter();
			param.ParameterName = "stInstrumentMainID";
			param.DbType = DbType.String;
			param.Direction = ParameterDirection.Input;
			param.Value = fsInstrumentMainID;

			cmd.Parameters.Add(param);
			//_DBContext.Database.OpenConnection();
			con.Open();
			using (var reader = cmd.ExecuteReader())
			{
				var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
				//_DBContext.Database.CloseConnection();
				return model;
			}
		}
		public IEnumerable<dynamic> getChequeDetails(string fsloginName,string sSP)
		{
			//using (var ctx = new DataEntryDataContext())
			var cmd = new SqlCommand();
			var con = new SqlConnection(CommonFunctions.ConStr);
			cmd.Connection = con;
			cmd.CommandText = "getChequeDetails";
			cmd.CommandType = CommandType.StoredProcedure;

			DbParameter param = cmd.CreateParameter();
			param.ParameterName = "stLoginName";
			param.DbType = DbType.String;
			param.Direction = ParameterDirection.Input;
			param.Value = fsloginName;

			cmd.Parameters.Add(param);
			//_DBContext.Database.OpenConnection();
			con.Open();
			using (var reader = cmd.ExecuteReader())
			{
				var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
				//_DBContext.Database.CloseConnection();
				return model;
			}
		}
		//public IEnumerable<dynamic> GetAllData4ImageExtraction(string fsWhereClouse)
		//{
		//    using (var ctx = new DataEntryDataContext())
		//    using (var cmd = ctx.Database.Connection.CreateCommand())
		//    {
		//        ctx.Database.Connection.Open();
		//        cmd.CommandText = "USP_ImageExtractionData";
		//        cmd.CommandType = CommandType.StoredProcedure;
		//        DbParameter param = cmd.CreateParameter();
		//        param.ParameterName = "sWhereClouse";
		//        param.DbType = DbType.String;
		//        param.Direction = ParameterDirection.Input;
		//        param.Value = fsWhereClouse;

		//        cmd.Parameters.Add(param);

		//        using (var reader = cmd.ExecuteReader())
		//        {
		//            var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
		//            return model;
		//        }
		//    }
		//}

		//public IEnumerable<dynamic> getChequeDetailsByCondition(string fsWhereClouse)
		//{
		//    using (var ctx = new DataEntryDataContext())
		//    using (var cmd = ctx.Database.Connection.CreateCommand())
		//    {
		//        ctx.Database.Connection.Open();
		//        cmd.CommandText = "getChequeDetailsByCondition";

		//        cmd.CommandType = CommandType.StoredProcedure;

		//        DbParameter param = cmd.CreateParameter();
		//        param.ParameterName = "sWhereClouse";
		//        param.DbType = DbType.String;
		//        param.Direction = ParameterDirection.Input;
		//        param.Value = fsWhereClouse;

		//        cmd.Parameters.Add(param);

		//        using (var reader = cmd.ExecuteReader())
		//        {
		//            var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
		//            return model;
		//        }
		//    }
		//}

		public DataEntryViewModel.ChequeImage getChequeImageByImageTypeM(string fsImageType, string fsUDKID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stImageType", fsImageType.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			return _DBContext.DBSet_ChequeImage.FromSql("getChequeImageByImageType".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public DataEntryViewModel.AllChequeImage GetAllImages(string fsUDKID)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stUDKID", fsUDKID.handleDBNull()));
			return _DBContext.DBSet_AllChequeImage.FromSql("USP_GetAllImages".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public DataEntryViewModel.BatchCurrentStatus checkBatchStatusM(string fsInstrumentMainID, string sLoginName)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("LoginName", sLoginName.handleDBNull()));
			return _DBContext.DBSet_BatchCurrentStatus.FromSql("checkBatchStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public bool unlockBatchByBatchNo(string fsInstrumentMainID)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stInstrumentMainID", fsInstrumentMainID.handleDBNull()));
				_DBContext.DBSet_BatchCurrentStatus.FromSql("unlockBatchByBatchNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

				return true;
			}
			catch (Exception) { return false; }

		}

		public bool Accept_Reject(string fsAccept_Reject, string fsUDKID, string fsRejectCode)
		{
			try
			{
				List<SqlParameter> loSqlParameters = new List<SqlParameter>();
				loSqlParameters.Add(new SqlParameter("stAccept_Reject", fsAccept_Reject.handleDBNull()));
				loSqlParameters.Add(new SqlParameter("stUDK", fsUDKID.handleDBNull()));
				loSqlParameters.Add(new SqlParameter("RejectCode", fsRejectCode.handleDBNull()));

				_DBContext.DBSet_BatchCurrentStatus.FromSql("USP_setUDKAcceptReject".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

				return true;
			}
			catch (Exception) { return false; }

		}

		public List<DataEntryViewModel.ReturnReasonMaster> getReturnReasonForDropdown()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();

			return _DBContext.DBSet_ReturnReasonMaster.FromSql("getReturnReasonList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		public List<DataEntryViewModel.DocSearchCriteria> getReportCriteria()
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			return _DBContext.DBSet_DocSearchCriteria.FromSql("getDocSearchCriteria".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		}

		/* Batch Selection */

		public BatchSelectionGridColumnsString getBatchGridDisplayColumns(Int32 iFunctionNumber)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("functionNumber", iFunctionNumber.handleDBNull()));
			return _DBContext.DBSet_BatchSelectionGridColumnsString.FromSql("USP_GetBatchGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
		}

		public IEnumerable<dynamic> getBatchSelectionList(int iFunctionNo, string fsBOFD)
		{
			//using (var ctx = new BatchSelectionDataContext())
			var cmd = new SqlCommand();
			var con = new SqlConnection(CommonFunctions.ConStr);
			cmd.Connection = con;
			con.Open();

			cmd.CommandText = "EXEC USP_GetBatchSelectionList " + Convert.ToString(iFunctionNo) + "," + fsBOFD;
			using (var reader = cmd.ExecuteReader())
			{
				var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
				return model;
			}

		}


		public bool updateLockStautByBatchNo(Int16 fiLockStatus, Int64 fsInstrumentMainID, string fsBOFD)
		{
			List<SqlParameter> loSqlParameters = new List<SqlParameter>();
			loSqlParameters.Add(new SqlParameter("inLockStatus", fiLockStatus.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("InstrumentMainID", fsInstrumentMainID.handleDBNull()));
			loSqlParameters.Add(new SqlParameter("BOFD", fsBOFD.handleDBNull()));
			_DBContext.DBSet_BatchSelectionGridColumnsString.FromSql("updateLockStautByBatchNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
			return true;
		}

		//public List<PermissionMaster> getUserPermissionByFunctionNumber(Int32 fiFunctionNumber)
		//{
		//    List<SqlParameter> loSqlParameters = new List<SqlParameter>();
		//    loSqlParameters.Add(new SqlParameter("functionNumber", fiFunctionNumber.handleDBNull()));

		//    return _DBContext.DBSet_PermissionMaster.FromSql("USP_ModuleInfoByFuntionNo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
		//}

		[HttpGet]
		public ActionResult DataEntry_TransferForm()

		{
			List<DataEntry_TransferForm> lisdata = new List<DataEntry_TransferForm>();
			ArrayList param = new ArrayList();
			ArrayList param_value = new ArrayList();
			param.Add("@ID");
			param_value.Add("0");

			DataTable dt2 = filldatatable_by_commmand("Sp_GetDataEntry_TransferFormDetails", param, param_value);
			for (int i = 0; i < dt2.Rows.Count; i++)
			{
				DataEntry_TransferForm objlocal = new DataEntry_TransferForm();
				objlocal.TransferRadio = dt2.Rows[i]["TransferRadio"].ToString();
				objlocal.Sno = Convert.ToInt32(i + 1);
				objlocal.ID = Convert.ToInt32(dt2.Rows[i]["ID"].ToString());
				objlocal.NormalRadio = dt2.Rows[i]["NormalRadio"].ToString(); 
				
				//objlocal.Emp_ID = Convert.ToInt32(dt2.Rows[i]["EmpID"].ToString());
				objlocal.Credit_Account_Number = dt2.Rows[i]["Credit_Account_Number"].ToString();
				objlocal.Credit_Account_Name = dt2.Rows[i]["Credit_Account_Name"].ToString();

				objlocal.No_of_Cheque = Convert.ToInt32(dt2.Rows[i]["No_of_Cheque"].ToString());
				objlocal.Debit_Account_Number = dt2.Rows[i]["Debit_Account_Number"].ToString();
				objlocal.Debit_Account_Name = dt2.Rows[i]["Debit_Account_Name"].ToString();


				objlocal.inst_Date = dt2.Rows[i]["inst_Date"].ToString();

				objlocal.cheque = dt2.Rows[i]["cheque"].ToString();
				objlocal.Sort_Code = dt2.Rows[i]["Sort_Code"].ToString();
				objlocal.Base_no = dt2.Rows[i]["Base_no"].ToString();
				objlocal.TC = dt2.Rows[i]["TC"].ToString();
				objlocal.Amount = dt2.Rows[i]["Amount"].ToString();
				
				lisdata.Add(objlocal);
			}
			ViewBag.All = lisdata;
			return View();
		}



		[HttpPost]
		public ActionResult DataEntry_TransferForm(DataEntry_TransferForm obj)
		{


			try
			{
				if(obj.TransferRadio==null)
                {
					obj.TransferRadio = "null";

				}
				if (obj.NormalRadio == null)
				{
					obj.NormalRadio = "null";

				}
			

				ArrayList param = new ArrayList();
				ArrayList param_value = new ArrayList();
				param.Add("@TransferRadio");
				param_value.Add(obj.TransferRadio.ToString());
				param.Add("@NormalRadio");
				param_value.Add(obj.NormalRadio.ToString());
				param.Add("@Credit_Account_Number");
				param_value.Add(obj.Credit_Account_Number.ToString());
				param.Add("@Credit_Account_Name");
				param_value.Add(obj.Credit_Account_Name.ToString());
				param.Add("@No_of_Cheque");
				param_value.Add(obj.No_of_Cheque.ToString());
				param.Add("@Debit_Account_Number");
				param_value.Add(obj.Debit_Account_Number.ToString());

				param.Add("@Debit_Account_Name");
				param_value.Add(obj.Debit_Account_Name.ToString());
				param.Add("@inst_Date");
				param_value.Add(obj.inst_Date.ToString());
				param.Add("@cheque");
				param_value.Add(obj.cheque.ToString());
				param.Add("@Sort_Code");
				param_value.Add(obj.Sort_Code.ToString());
				param.Add("@Base_no");
				param_value.Add(obj.Base_no.ToString());
				param.Add("@TC");
				param_value.Add(obj.TC.ToString());
				param.Add("@Amount");
				param_value.Add(obj.Amount.ToString());
				

				DataTable dt2 = filldatatable_by_commmand("Sp_DataEntry_TransferForm", param, param_value);
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return RedirectToAction("DataEntry_TransferForm");
			//return View();
		}



		public DataTable filldatatable_by_commmand(string spname, ArrayList param, ArrayList param_value)
		{
			try
			{
				SqlCommand cmd = new SqlCommand();
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = spname;
				for (int i = 0; i <= param.Count - 1; i++)
				{
					cmd.Parameters.AddWithValue((string)param[i], param_value[i]);
				}
				SqlConnection con = new SqlConnection();
				con.ConnectionString = _configuration.GetSection("ConnectionStrings").GetSection("MsSqlConStr").Value; 
				cmd.Connection = con;
				cmd.CommandTimeout = 300;
				DataTable dt = new DataTable();
				SqlDataAdapter da = new SqlDataAdapter(cmd);
				da.Fill(dt);
				return dt;
			}
			catch (SystemException ex)
			{
				throw ex;
			}
			return null;

		}






		public string delete_DataEntryOperation(string id)
        {
			try
			{
				DataEntry_TransferForm objlocal = new DataEntry_TransferForm();
				ArrayList param = new ArrayList();
				ArrayList param_value = new ArrayList();
				param.Add("@ID");
				param_value.Add(id);

				DataTable dt2 = filldatatable_by_commmand("Sp_DeleteDataEntry_TransferFormDetails", param, param_value);
				return "true";
			}
			catch (Exception ex)
            {
				throw ex;
            }
        }

		public JsonResult GetDataTransfer(string id)
		{
			List<DataEntry_TransferForm> lisdata = new List<DataEntry_TransferForm>();
			DataEntry_TransferForm objlocal = new DataEntry_TransferForm();
			ArrayList param = new ArrayList();
			ArrayList param_value = new ArrayList();
			param.Add("@ID");
			param_value.Add(id);

			DataTable dt2 = filldatatable_by_commmand("Sp_GetDataEntry_TransferFormDetails", param, param_value);
			for (int i = 0; i < dt2.Rows.Count; i++)
			{
				
				objlocal.TransferRadio = dt2.Rows[i]["TransferRadio"].ToString();
				objlocal.Sno = Convert.ToInt32(i + 1);
				objlocal.ID = Convert.ToInt32(dt2.Rows[i]["ID"].ToString());
				objlocal.NormalRadio = dt2.Rows[i]["NormalRadio"].ToString();

				//objlocal.Emp_ID = Convert.ToInt32(dt2.Rows[i]["EmpID"].ToString());
				objlocal.Credit_Account_Number = dt2.Rows[i]["Credit_Account_Number"].ToString();
				objlocal.Credit_Account_Name = dt2.Rows[i]["Credit_Account_Name"].ToString();

				objlocal.No_of_Cheque = Convert.ToInt32(dt2.Rows[i]["No_of_Cheque"].ToString());
				objlocal.Debit_Account_Number = dt2.Rows[i]["Debit_Account_Number"].ToString();
				objlocal.Debit_Account_Name = dt2.Rows[i]["Debit_Account_Name"].ToString();


				objlocal.inst_Date = dt2.Rows[i]["inst_Date"].ToString();

				objlocal.cheque = dt2.Rows[i]["cheque"].ToString();
				objlocal.Sort_Code = dt2.Rows[i]["Sort_Code"].ToString();
				objlocal.Base_no = dt2.Rows[i]["Base_no"].ToString();
				objlocal.TC = dt2.Rows[i]["TC"].ToString();
				objlocal.Amount = dt2.Rows[i]["Amount"].ToString();

				
			}




			//var json = new JavaScriptSerializer().Serialize(objlocal);
			return Json(objlocal);


		}




		
		public JsonResult UpdateDataTransfer(string id, string TransferRadio, string NormalRadio, string credit_Account_Number, string credit_Account_Name, string no_of_Cheque, string debit_Account_Number, string debit_Account_Name, string inst_Date, string cheque, string sort_Code, string base_no, string tc, string amount)
		{
			List<DataEntry_TransferForm> lisdata = new List<DataEntry_TransferForm>();
			DataEntry_TransferForm objlocal = new DataEntry_TransferForm();
			try
			{

				if (TransferRadio == null)
				{
					TransferRadio = "null";

				}
				if (NormalRadio == null)
				{
					NormalRadio = "null";

				}

				ArrayList param = new ArrayList();
				ArrayList param_value = new ArrayList();
				param.Add("@TransferRadio");
				param_value.Add(TransferRadio);
				param.Add("@NormalRadio");
				param_value.Add(NormalRadio);
				param.Add("@Credit_Account_Number");
				param_value.Add(credit_Account_Number);
				param.Add("@Credit_Account_Name");
				param_value.Add(credit_Account_Name);
				param.Add("@No_of_Cheque");
				param_value.Add(no_of_Cheque);
				param.Add("@Debit_Account_Number");
				param_value.Add(debit_Account_Number);

				param.Add("@Debit_Account_Name");
				param_value.Add(debit_Account_Name);
				param.Add("@inst_Date");
				param_value.Add(inst_Date);
				param.Add("@cheque");
				param_value.Add(cheque);
				param.Add("@Sort_Code");
				param_value.Add(sort_Code);
				param.Add("@Base_no");
				param_value.Add(base_no);
				param.Add("@TC");
				param_value.Add(tc);
				param.Add("@Amount");
				param_value.Add(amount);
				param.Add("@ID");
				param_value.Add(id);

				DataTable dt2 = filldatatable_by_commmand("Sp_UpdateDataEntry_TransferForm", param, param_value);
				return Json("true");
			}
			catch (Exception ex)
			{
				throw ex;
				
			}





			//var json = new JavaScriptSerializer().Serialize(objlocal);
			


		}


		[HttpGet]
		public ActionResult form1()
		{
			return View();
		}


		[HttpPost]
		public ActionResult form1(DataEntry_TransferForm obj)
		{
			try
			{
				



				ArrayList param = new ArrayList();
				ArrayList param_value = new ArrayList();
				param.Add("@Date");
				param_value.Add(obj.Date.ToString());
				param.Add("@Location");
				param_value.Add(obj.Location.ToString());
				param.Add("@SchemeCode");
				param_value.Add(obj.SchemeCode.ToString());
				param.Add("@EntryID");
				param_value.Add(obj.EntryID.ToString());
				param.Add("@BankCode");
				param_value.Add(obj.BankCode.ToString());
				param.Add("@BranchCode");
				param_value.Add(obj.BranchCode.ToString());

				param.Add("@SNO");
				param_value.Add(obj.Sno.ToString());
				param.Add("@FormNo");
				param_value.Add(obj.FormNo.ToString());
				param.Add("@ApplicantName");
				param_value.Add(obj.ApplicantName.ToString());
				param.Add("@Gender");
				param_value.Add(obj.Gender.ToString());
				param.Add("@DateOfBirth");
				param_value.Add(obj.DateOfBirth.ToString());
				param.Add("@FatherName");
				param_value.Add(obj.FathersName.ToString());
				param.Add("@SpouseName");
				param_value.Add(obj.SpouseName.ToString());
				param.Add("@Pan");
				param_value.Add(obj.Pan.ToString());
				param.Add("@ApplicantBank");
				param_value.Add(obj.ApplicantBank.ToString());
				param.Add("@Branch");
				param_value.Add(obj.Branch.ToString());
				param.Add("@AccountNo");
				param_value.Add(obj.AccountNo.ToString());
				param.Add("@IFSCCode");
				param_value.Add(obj.IFSCCode.ToString());
				param.Add("@STDCODE");
				param_value.Add(obj.STDCode.ToString());
				param.Add("@Mobile");
				param_value.Add(obj.Mobile.ToString());
				param.Add("@AadharNo");
				param_value.Add(obj.AadharNo.ToString());
				param.Add("@EmailID");
				param_value.Add(obj.EmailID.ToString());
				param.Add("@Category");
				param_value.Add(obj.Category.ToString());
				param.Add("@Address");
				param_value.Add(obj.Address.ToString());
				param.Add("@Address2");
				param_value.Add(obj.Address2.ToString());
				param.Add("@Address3");
				param_value.Add(obj.Address3.ToString());
				param.Add("@CorrespondenceAddress");
				param_value.Add(obj.CorrespondenceAddress.ToString());
				param.Add("@CorrespondenceAddress2");
				param_value.Add(obj.CorrespondenceAddress2.ToString());
				param.Add("@CorrespondenceAddress3");
				param_value.Add(obj.CorrespondenceAddress3.ToString());
				param.Add("@City");
				param_value.Add(obj.City.ToString());
				param.Add("@State");
				param_value.Add(obj.State.ToString());
				param.Add("@City2");
				param_value.Add(obj.City2.ToString());
				param.Add("@Pin");
				param_value.Add(obj.Pin.ToString());
				param.Add("@DelhiRegion");
				param_value.Add(obj.DelhiRegion.ToString());
				param.Add("@CopyAddress");
				param_value.Add(obj.CopyAddress.ToString());
				param.Add("@State2");
				param_value.Add(obj.State2.ToString());
				param.Add("@PinCode");
				param_value.Add(obj.Pin2.ToString());
				param.Add("@JointApplicant");
				param_value.Add(obj.JointApplicant.ToString());
				param.Add("@Relation");
				param_value.Add(obj.Relation.ToString());
				param.Add("@Name");
				param_value.Add(obj.Name.ToString());
				param.Add("@FormNo2");
				param_value.Add(obj.FormNo2.ToString());
				param.Add("@Remarks");
				param_value.Add(obj.Remarks.ToString());
				param.Add("@WebForm");
				param_value.Add(obj.WebForm.ToString());
				param.Add("@AmountTotal");
				param_value.Add(obj.AmountTotal.ToString());
				param.Add("@Pref1");
				param_value.Add(obj.Pref1.ToString());
				param.Add("@Pref2");
				param_value.Add(obj.Pref2.ToString());
				param.Add("@Pref3");
				param_value.Add(obj.Pref3.ToString());
				param.Add("@Pref4");
				param_value.Add(obj.Pref4.ToString());
				param.Add("@Pref5");
				param_value.Add(obj.Pref5.ToString());
				param.Add("@Pref6");
				param_value.Add(obj.Pref6.ToString());
				param.Add("@Pref7");
				param_value.Add(obj.Pref7.ToString());
				param.Add("@BankBranch");
				param_value.Add(obj.BankBranch.ToString());
				param.Add("@Total");
				param_value.Add(obj.Total.ToString());
				param.Add("@RTGSACNO");
				param_value.Add(obj.RTGSAcNo.ToString());
				param.Add("@BankName");
				param_value.Add(obj.BankName.ToString());
				

				DataTable dt2 = filldatatable_by_commmand("Sp_Form1Table", param, param_value);
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return RedirectToAction("form1");
		}
	}
}
