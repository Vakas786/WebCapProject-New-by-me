﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CtsWebCoreOutward.ViewModel
{
    public class ScannerInfoViewModel
    {
        public class ScannerInfo
        {
            [Key]
            public string SorterID { get; set; }
            public string SorterNo { get; set; }
        }

        public class AddScannerInfo
        {
            public IList<ScannerInfo> ScannerInfolList { get; set; }
            public Nullable<int> iFuntionNo { get; set; }

            [Display(Name = "Scanner Serial No")]
            public string SorterID { get; set; }

            [Display(Name = "Sorter No")]
            public string SorterNo { get; set; }
  
            //Constructor
            public AddScannerInfo()
            {
                //Create Objects
            }
        }
       
    }
}