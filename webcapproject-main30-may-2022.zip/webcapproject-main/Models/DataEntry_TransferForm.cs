﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CtsWebCoreOutward.Models
{
    public class DataEntry_TransferForm
    {
        

        public  int ID { get; set; }
        public int Sno { get; set; }
        public string TransferRadio { get; set; }
        public string NormalRadio { get; set; }
        public string Credit_Account_Number { get; set; }
        public string Credit_Account_Name { get; set; }
        public string Name { get; set; }
        
        public string JointApplicant { get; set; }
        public string Relation { get; set; }
        
        public string Pin { get; set; }
        public string Pin2 { get; set; }
        public string DelhiRegion { get; set; }

        public string CopyAddress { get; set; }
        

        public int No_of_Cheque { get; set; }
        public string Debit_Account_Number { get; set; }

        public string Debit_Account_Name { get; set; }
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public string inst_Date { get; set; }

        public string Date { get; set; }
        public string Location { get; set; }
        public string SchemeCode { get; set; }
        public string EntryID { get; set; }
        public string BankCode { get; set; }
        public string BranchCode { get; set; }
        public string FormNo { get; set; }
        public string FormNo2 { get; set; }
        public string Remarks { get; set; }
        public string RTGSAcNo { get; set; }

        public string BankName { get; set; }

        public string WebForm { get; set; }

        public string AmountTotal { get; set; }
        public string BankBranch { get; set; }
        public string Total { get; set; }



        

        public string ApplicantName { get; set; }
        public string Gender { get; set; }

        public string DateOfBirth { get; set; }
        public string FathersName { get; set; }
        public string SpouseName { get; set; }
        public string Pan { get; set; }
        public string ApplicantBank { get; set; }
        public string Branch { get; set; }
        public string AccountNo { get; set; }
        public string IFSCCode { get; set; }

        public string STDCode { get; set; }
        public string Mobile { get; set; }
        public string AadharNo { get; set; }

        public string EmailID { get; set; }
        public string Category { get; set; }

        public string Address { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        
        public string CorrespondenceAddress { get; set; }
        public string CorrespondenceAddress2 { get; set; }
        public string CorrespondenceAddress3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string State2 { get; set; }
        public string City2 { get; set; }
        public string cheque { get; set; }
        public string Sort_Code { get; set; }
        public string Base_no { get; set; }
        public string TC { get; set; }
        public string Amount { get; set; }



        public string Pref1 { get; set; }
        public string Pref2 { get; set; }
        public string Pref3 { get; set; }
        public string Pref4 { get; set; }
        public string Pref5 { get; set; }
        public string Pref6 { get; set; }
        public string Pref7 { get; set; }
    }
}
