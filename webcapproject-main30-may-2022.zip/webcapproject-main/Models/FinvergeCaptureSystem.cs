﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CtsWebCoreOutward.Models
{
    public class FinvergeCaptureSystem
    {
     

        public string BatchNo { get; set; }
        public string BlockNo { get; set; }
        public string SorterNo { get; set; }
        public string Bofd { get; set; }
        public string ChequeCount { get; set; }
        public string SlipCount { get; set; }

        public string Branchtype { get; set; }
        public string cleartype { get; set; }
        public string Chequenumber { get; set; }
        public string seqno { get;  set; }
        public string iqa { get;  set; }
        public string instrutype { get;  set; }
        public string shortercode { get;  set; }
        public string basenumber { get;  set; }
        public string Tc { get;  set; }
        public string deleted { get;  set; }
        public string frontcheque_id { get;  set; }
        public string Backsidechq_id { get;  set; }
        public string uv_id { get;  set; }
        public string loadfromcsv_id { get;  set; }
        public string Predict_id { get;  set; }
        public string Slip_id { get;  set; }
        public string PayeeAccNo_id { get;  set; }
        public string PayeeName_id { get;  set; }
    }
}
