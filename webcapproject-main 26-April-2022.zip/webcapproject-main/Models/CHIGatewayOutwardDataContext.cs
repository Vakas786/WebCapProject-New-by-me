﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using Microsoft.EntityFrameworkCore;
using static CtsWebCoreOutward.ViewModel.CHIGatewayOutwardViewModel;

namespace CtsWebCoreOutward.Models
{
    public class CHIGatewayOutwardDataContext : DbContext
    {
        public CHIGatewayOutwardDataContext(DbContextOptions<CHIGatewayOutwardDataContext> options)
            : base(options)
        { }

        public DbSet<TransactionCodeMaster> DBSet_TransactionCodeMaster { get; set; }
        public DbSet<ResProcessStatusUDK> DBSet_ResProcessStatusUDK { get; set; }
        public DbSet<InHouseInstrumentsDtl> DBSet_InHouseInstrumentsDtl { get; set; }
        public DbSet<CXFInformation> DBSet_CXFInformation { get; set; }
        

    }
}