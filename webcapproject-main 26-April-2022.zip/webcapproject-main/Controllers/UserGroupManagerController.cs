﻿using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;


namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class UserGroupManagerController : Controller
    {

        private readonly UserGroupManagerDataContext _DBContext;
        public UserGroupManagerController(UserGroupManagerDataContext dbContext) { _DBContext = dbContext; }
        public ActionResult UserGroupManagerListMain(int? id)
        {
            try
            {
                UserGroupManagerViewModel.AddUserGroup loAddUserGroupEntry = new UserGroupManagerViewModel.AddUserGroup();
                //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();

                loAddUserGroupEntry.iFuntionNo = id;
                loAddUserGroupEntry.UserGroupList = getUserGroupList();
         
                return View(loAddUserGroupEntry);
                //return View("~/Areas/UserGroupManager/Views/UserGroupManager/UserGroupManagerList.cshtml", loAddUserGroupEntry);
            }
            catch (Exception ex)
            {
                return View();
            }

        }

        public ActionResult UserGroupManager(int? id)
        {
            try
            {
                UserGroupManagerViewModel.AddUserGroup loAddUserGroupEntry = new UserGroupManagerViewModel.AddUserGroup();
                //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();

                loAddUserGroupEntry.iFuntionNo = id;

                //loAddUserGroupEntry.UserGroupList = loUserGroupManagerDataContext.getUserGroupList();
                loAddUserGroupEntry.ModuleFunctionList = getModuleFunctionList();
               
                return View(loAddUserGroupEntry);

            }
            catch (Exception ex)
            {
                return View();
            }

        }

        public ActionResult UserGroupManagerEdit(int? id, int? UserGroupID)
        {
            try
            {
                UserGroupManagerViewModel.AddUserGroup loAddUserGroupEntry = new UserGroupManagerViewModel.AddUserGroup();
                //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();

                UserGroupManagerViewModel.AddUserGroup loUserGroupManagerViewModel = new UserGroupManagerViewModel.AddUserGroup();
                loUserGroupManagerViewModel.UserGroupList = getUserGroup_EditById(UserGroupID);
                loAddUserGroupEntry.iFuntionNo = id;
                
                loAddUserGroupEntry.UserGroupID = Convert.ToInt16(UserGroupID);

                if (loUserGroupManagerViewModel.UserGroupList != null && loUserGroupManagerViewModel.UserGroupList.Count > 0)
                {


                    loAddUserGroupEntry.UserGroupList = getUserGroupList();

                    loAddUserGroupEntry.UserGroupID = loUserGroupManagerViewModel.UserGroupList[0].UserGroupID;
                    loAddUserGroupEntry.UserGroupName = loUserGroupManagerViewModel.UserGroupList[0].UserGroupName;
                    loAddUserGroupEntry.UserGroupDescription = loUserGroupManagerViewModel.UserGroupList[0].UserGroupDescription;
                    
                }

                loAddUserGroupEntry.ModuleFunctionList = getModuleFunctionList();
                loAddUserGroupEntry.UserGroupDtlList = getUserGroupDtlList(UserGroupID);

                
                //List<int> result = loAddUserGroupEntry.ModuleFunctionList.Select(x => x.FunctionNumber).Intersect(loAddUserGroupEntry.UserGroupDtlList.Select(y => y.FunctionNumber)).ToList();
                foreach (var num in loAddUserGroupEntry.ModuleFunctionList)
                {

                    int iFunctionNumber = 0, iUserGroupid=0;
                    iFunctionNumber = num.FunctionNumber;
                    iUserGroupid = loAddUserGroupEntry.UserGroupDtlList.Where(x => x.FunctionNumber == iFunctionNumber).Select(x => x.FunctionNumber).FirstOrDefault();
                    if (iUserGroupid > 0)
                        num.Checked = true;  
                    else
                        num.Checked = false;  

                } 

                return View(loAddUserGroupEntry);

            }
            catch (Exception)
            {
                return View();
            }

        }

        public ActionResult InsertData(string UserGroupName, string UserGroupDescription, string FunctionNumber)
        {
            UserGroupManagerViewModel.AddUserGroup loUserGroupManagerViewModel = new UserGroupManagerViewModel.AddUserGroup();
            //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();
            loUserGroupManagerViewModel.UserGroupList = InsertUserGroupData(UserGroupName, UserGroupDescription, FunctionNumber);
            return View("~/Views/UserGroupManager/UserGroupManagerListMain.cshtml", loUserGroupManagerViewModel);

        }

        public ActionResult UpdateDetail(int? UserGroupID, string UserGroupName, string UserGroupDescription, string FunctionNumber)
        {
            int iFunctionNumber = 0;
            UserGroupManagerViewModel.AddUserGroup loUserGroupManagerViewModel = new UserGroupManagerViewModel.AddUserGroup();
            //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();
            loUserGroupManagerViewModel.UserGroupList = UpdateUserGroupData(UserGroupID, UserGroupName, UserGroupDescription);

            getUserGroupDtl_DeleteById(UserGroupID);
            string[] sFunctionNumberList = FunctionNumber.Split('|');

            for (int i = sFunctionNumberList.GetLowerBound(0); i <= sFunctionNumberList.GetUpperBound(0); i++)
            {
                iFunctionNumber = Convert.ToInt32(sFunctionNumberList[i]);
                InsertUserGroupDtlData(UserGroupID, iFunctionNumber);
            }
            return View("~/Views/UserGroupManager/UserGroupManagerListMain.cshtml", loUserGroupManagerViewModel);

        }


        public ActionResult GETData(string UserGroupName)
        {
            UserGroupManagerViewModel.AddUserGroup loUserGroupManagerViewModel = new UserGroupManagerViewModel.AddUserGroup();
            //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();
            loUserGroupManagerViewModel.UserGroupList = GetUserGroupInfoData(UserGroupName);
           
            return View("~/Views/UserGroupManager/UserGroupManagerList.cshtml", loUserGroupManagerViewModel);
        }

        public ActionResult DeleteDetailByID(int? UserGroupID)
        {
            UserGroupManagerViewModel.AddUserGroup loUserGroupManagerViewModel = new UserGroupManagerViewModel.AddUserGroup();
            //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();
            loUserGroupManagerViewModel.UserGroupList = getUserGroup_DeleteById(UserGroupID);
            loUserGroupManagerViewModel.UserGroupList = getUserGroupList();
            return View("~/Views/UserGroupManager/UserGroupManagerList.cshtml", loUserGroupManagerViewModel);
            
        }

        public ActionResult EditDetailByID(int? UserGroupID)
        {
            UserGroupManagerViewModel.AddUserGroup loUserGroupManagerViewModel = new UserGroupManagerViewModel.AddUserGroup();
            //UserGroupManagerDataContext loUserGroupManagerDataContext = new UserGroupManagerDataContext();
            loUserGroupManagerViewModel.UserGroupList = getUserGroup_EditById(UserGroupID);

            return Json(loUserGroupManagerViewModel.UserGroupList);
        }

        public List<UserGroupManagerViewModel.UserGroup> getUserGroupList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_UserGroup.FromSql("getUserGroupList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<UserGroupManagerViewModel.UserGroupDtl> getUserGroupDtlList(int? UserGroupID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("UserGroupID", UserGroupID.handleDBNull()));

            return _DBContext.DBSet_UserGroupDtl.FromSql("GetUserGroupDeatilList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<UserGroupManagerViewModel.ModuleFunctionTbl> getModuleFunctionList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_ModuleFunctionTbl.FromSql("USP_GetUserGroupDtl".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<UserGroupManagerViewModel.UserGroup> getUserGroup_DeleteById(int? UserGroupID)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("UserGroupID", UserGroupID.handleDBNull()));

            return _DBContext.DBSet_UserGroup.FromSql("DeleteUserGroup".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<UserGroupManagerViewModel.UserGroup> getUserGroupDtl_DeleteById(int? UserGroupID)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("UserGroupID", UserGroupID.handleDBNull()));

            return _DBContext.DBSet_UserGroup.FromSql("DeleteUserGroupDtl".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<UserGroupManagerViewModel.UserGroup> getUserGroup_EditById(int? UserGroupID)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("UserGroupID", UserGroupID.handleDBNull()));

            return _DBContext.DBSet_UserGroup.FromSql("EditUserGroupByID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        //User Group
        public List<UserGroupManagerViewModel.UserGroup> InsertUserGroupData(string UserGroupName, string UserGroupDescription, string FunctionNumber)
        {
            try
            {


                decimal dUserGroupID = 0;
                int iUserGroupID = 0, iFunctionNumber = 0;
                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupName", UserGroupName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupDescription", UserGroupDescription.handleDBNull()));
                // dUserGroupID = new UserGroupManagerDataContext().Database.SqlQuery<decimal>("InsertUserGroup".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).FirstOrDefault();
                ////dUserGroupID = new UserGroupManagerDataContext().Database.SqlQuery<UserGroupManagerViewModel.TransactionCodeMaster>("InsertUserGroup ".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

                iUserGroupID = Convert.ToInt32(dUserGroupID);
                string[] sFunctionNumberList = FunctionNumber.Split('|');

                for (int i = sFunctionNumberList.GetLowerBound(0); i <= sFunctionNumberList.GetUpperBound(0); i++)
                {
                    iFunctionNumber = Convert.ToInt32(sFunctionNumberList[i]);
                    InsertUserGroupDtlData(iUserGroupID, iFunctionNumber);
                }
                List<SqlParameter> loSqlParameters_List = new List<SqlParameter>();
                //loSqlParameters_List.Add(new SqlParameter("stUserGroupID", UserGroupID.handleDBNull()));

                return _DBContext.DBSet_UserGroup.FromSql("getUserGroupList".getSql(loSqlParameters_List), loSqlParameters_List.Cast<object>().ToArray()).ToList();


            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<UserGroupManagerViewModel.UserGroup> UpdateUserGroupData(int? UserGroupID, string UserGroupName, string UserGroupDescription)
        {
            try
            {

                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupID", UserGroupID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupName", UserGroupName.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupDescription", UserGroupDescription.handleDBNull()));


                return _DBContext.DBSet_UserGroup.FromSql("UpdateUserGroup".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }

        //User Group Dtl
        public List<UserGroupManagerViewModel.UserGroupDtl> InsertUserGroupDtlData(int? UserGroupID, int? FunctionNumber)
        {
            try
            {



                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                //loSqlParametersDoc.Add(new SqlParameter("stUserGroupDtlID", UserGroupDtlID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupID", UserGroupID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stFunctionNumber", FunctionNumber.handleDBNull()));

                _DBContext.DBSet_UserGroupDtl.FromSql("InsertUserGroupDetail ".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();


                List<SqlParameter> loSqlParameters_List = new List<SqlParameter>();
                //loSqlParameters_List.Add(new SqlParameter("UserGroupDtlID", UserGroupID.handleDBNull()));

                return _DBContext.DBSet_UserGroupDtl.FromSql("getUserGroupList".getSql(loSqlParameters_List), loSqlParameters_List.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<UserGroupManagerViewModel.UserGroupDtl> UpdateUserGroupDtlData(int? UserGroupDtlID, int? UserGroupID, int? FunctionNumber)
        {
            try
            {

                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupDtlID", UserGroupDtlID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stUserGroupID", UserGroupID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("stFunctionNumber", FunctionNumber.handleDBNull()));

                return _DBContext.DBSet_UserGroupDtl.FromSql("USP_UpdateUserGroupDetail".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<UserGroupManagerViewModel.UserGroup> GetUserGroupInfoData(string UserGroupName)
        {
            try
            {

                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("UserGroupName", UserGroupName.handleDBNull()));

                return _DBContext.DBSet_UserGroup.FromSql("GetUserGroupInfoDetail_Search".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
