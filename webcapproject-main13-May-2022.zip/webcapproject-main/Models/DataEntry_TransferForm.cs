﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CtsWebCoreOutward.Models
{
    public class DataEntry_TransferForm
    {
        

        public  int ID { get; set; }
        public int Sno { get; set; }
        public string TransferRadio { get; set; }
        public string NormalRadio { get; set; }
        public string Credit_Account_Number { get; set; }
        public string Credit_Account_Name { get; set; }
        public int No_of_Cheque { get; set; }
        public string Debit_Account_Number { get; set; }

        public string Debit_Account_Name { get; set; }
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public string inst_Date { get; set; }
        public string cheque { get; set; }
        public string Sort_Code { get; set; }
        public string Base_no { get; set; }
        public string TC { get; set; }
        public string Amount { get; set; }



    }
}
