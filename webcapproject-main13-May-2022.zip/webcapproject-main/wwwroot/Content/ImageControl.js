        var isBF=false;				
        var isBR=false;				
        var dband;
        var SelectedSeq;


        var stdImgPanelHeight = 340;
        var stdImgPanelWidth  = 760;
        var zoomfactor=0.15; 			
        var prefix;
        var maxHeight=5000; 			
        var minWidth=10;			
        var imgSlip;
        var actual_Slip_img_height,actual_Slip_img_width;
        var currSlipRotation=0;
        var bIsSlipInverted = false;
        
        var CurrentSlipImage=0; 
        var imgCheque;
        var imgSecondCheque;
        var actual_Cheque_img_height,actual_Cheque_img_width;
        var currChequeRotation = 0;
        var bIsChequeInverted = false;
        var CurrentChequeImage=0;
        var CurrentSecondChequeImage = 0 ;

        var divCheName = "divChequeImg";
        var CnvsName = "cnvs_ChequeImage";
        
         if(jg == null)
        {
            var jg=new jsGraphics(divCheName);
        }
       
        if(jb == null)
        {
            var jb=new jsGraphics("divSecondChequeImg");
        }


        var zoomfactor = 0.15;
        var prefix;
        var CnvsName = "cnvs_ChequeImage";
        var maxHeight = 5000;
        var minWidth = 100;
        var v_img_width = 0;
        var v_img_height = 0;
        var v_img_width_default = 480;
        var v_img_height_default = 335;
        var v_img_object = new Image();
        var SignCard_ZoomWidth = 0;
        var SignCard_ZoomHeight = 0;



        function fill_canvas(img) {
            // CREATE CANVAS CONTEXT.
            var canvas = document.getElementById('cnvs_ChequeImage');
            var ctx = canvas.getContext('2d');
            imgCheque = document.getElementById('imgCheque');
            canvas.width = img.width;
            canvas.height = img.height;

            v_img_width = img.width;// v_img_width_default;
            v_img_height = img.height; // v_img_height_default;
             
             ctx.drawImage(img, 0, 0, img.width, img.height);       // DRAW THE IMAGE TO THE CANVAS.
            
            v_img_object.src = document.getElementById('cnvs_ChequeImage').toDataURL();

        }


        function f_SignCard_Zoom_InOut(imgType, state) {
            console.log("click : f_img_zoom");
            try {
                prefix = (state == "in") ? 1 : -1;
                 
                zoomit( CnvsName, false, 1);
            } catch (err) {
                alert("Error : f_SignCard_Zoom_InOut : " + err);
            }
        };


        function zoomit(cnvsID, isInverted, iType) {
            try {
                
                var canvas = document.getElementById(cnvsID);
                var ctx = canvas.getContext("2d");

                var v_img_width_t = v_img_width + (v_img_width * zoomfactor * prefix);
                var v_img_height_t = v_img_height + (v_img_height * zoomfactor * prefix);
                
                if ((parseInt(v_img_width_t) > minWidth) && (parseInt(v_img_height_t) < maxHeight)) {
                    v_img_width = v_img_width_t;
                    v_img_height = v_img_height_t;
                }
                //console.log("v_img_width_t : " + v_img_width_t);
                //console.log("v_img_height_t : " + v_img_height_t);

                canvas.width = v_img_width;
                canvas.height = v_img_height;
                ctx.drawImage(v_img_object, 0, 0, canvas.width, canvas.height);

                //f_invert_flag(ctx);

            } catch (err) {
                console.log("zoomit : " + err);
                //alert("Error : zoomit : " + err);
            }
        }


            function setDefImageType(e)
            {
               try
               {
                CurrentChequeImage = e;
                CurrentSlipImage = e;
               }
               catch(err)
               {
                 alert("setDefImageType : " + err);
               }    
            }
           function setDivCheImage(chequediv,chequecanavas)
            {
//                  alert("test");
                  divCheName = chequediv;
                  CnvsName = chequecanavas;
                 // alert("divCheName:"+divCheName + " chequediv : " + chequediv + " chequecanavas: " + chequecanavas);
            }
           function DefSecondImageType(e)
            {
               try
               {
                CurrentSecondChequeImage = e;
                CurrentSlipImage = e;
               }
               catch(err)
               {
                 alert("setDefImageType : " + err);
               }    
            }
               
            function setSlipImage(e)
            {
               try
               {
                initSlipImage(e);
                
                }
               catch(err)
               {
                 alert("setSlipImage : " + err);
               }  
               
            }
            
            function setChequeImage(e)
            {
               try
               {
                initChequeImage(e);
               }
               catch(err)
               {
                 alert("setDefImageType : " + err);
               }   
            }
            function setChequeImageNew(e,f,g)
            {
               try
               {
                initChequeImageNew(e,f,g);
               }
               catch(err)
               {
                 alert("setDefImageType : " + err);
               }   
            }
            function setSecondChequeImage(e)
            {
               try
               {
                initSecondChequeImage(e);
               }
               catch(err)
               {
                 alert("setDefImageType : " + err);
               }   
            }
            
            function setImgPanel(iHeight, iWidth)
            {
                try
                {
                stdImgPanelHeight = iHeight;
                stdImgPanelWidth  = iWidth;
                
                }
               catch(err)
               {
                 alert("setImgPanel : " + err);
               }  
            }
                        
            function initSlipImage(e)
            {
                try
                {
                imgSlip = document.getElementById(e.id);
                ChqImg = new Image();
                if (!imgSlip.src=='') 
                    ChqImg.src=imgSlip.src;
                actual_Slip_img_height = ChqImg.height;
                actual_Slip_img_width = ChqImg.width;                
                DrawIt('cnvs_SlipImage',imgSlip);
                }
               catch(err)
               {
                 alert("initSlipImage : " + err);
               }  
            }
            
            function initChequeImage(e)
            {
                 try
                {
                ////alert(divCheName);
//                var divChq = document.getElementById(divCheName);
//                var iHeight = parseInt(divChq.style.height);
//                var iWidth = parseInt(divChq.style.width);
//                setImgPanel(iHeight, iWidth);
//                imgCheque = document.getElementById(e.id);
//                ChqImg = new Image();
//                if (!imgCheque.src=='') 
//                    ChqImg.src=imgCheque.src;
//                actual_Cheque_img_height = ChqImg.height;
//                actual_Cheque_img_width = ChqImg.width;
//            	stdImgPanelHeight=(screen.height*stdImgPanelHeight)/768;
//	            stdImgPanelWidth=(screen.width*stdImgPanelWidth)/1024;                
//                DrawIt(CnvsName,imgCheque);
               //initChequeImageNew(e.id,divCheName,CnvsName);
               initChequeImageNew(e,divCheName,CnvsName);
                }
               catch(err)
               {
                 alert("initChequeImage : " + err);
               }  
            }
            function initChequeImageNew(e,f,g)
            {
                 try
                {
                ////alert("e : " + e.id + " f : " + f + " g : " + g);
                var divChq = document.getElementById(f);
                var iHeight = parseInt(divChq.style.height);
                var iWidth = parseInt(divChq.style.width);
                setImgPanel(iHeight, iWidth);
                imgCheque = document.getElementById(e.id);
                ChqImg = new Image();
                if (!imgCheque.src=='') 
                    ChqImg.src=imgCheque.src;
                actual_Cheque_img_height = ChqImg.height;
                actual_Cheque_img_width = ChqImg.width;
            	stdImgPanelHeight=(screen.height*stdImgPanelHeight)/768;
	            stdImgPanelWidth=(screen.width*stdImgPanelWidth)/1024;                
                DrawIt(g,imgCheque);
                }
               catch(err)
               {
                 alert("initChequeImage : " + err);
               }  
            }
            
             function initSecondChequeImage(e)
            {
                 try
                {
                
                var divChq = document.getElementById('ctl00_ContentPlaceHolder1_divSecondChequeImg');
                var iHeight = parseInt(divChq.style.height);
                var iWidth = parseInt(divChq.style.width);
                setImgPanel(iHeight, iWidth);
               
                imgSecondCheque= document.getElementById(e.id);
                ChqImg = new Image();
                if (!imgSecondCheque.src=='') 
                    ChqImg.src=imgSecondCheque.src;
                actual_Cheque_img_height = ChqImg.height;
                actual_Cheque_img_width = ChqImg.width;
            	stdImgPanelHeight=(screen.height*stdImgPanelHeight)/768;
	            stdImgPanelWidth=(screen.width*stdImgPanelWidth)/1024;                
                DrawSecondIt('cnvs_ChequeSecondImage',imgSecondCheque);
                }
               catch(err)
               {
                 alert("initSecondChequeImage : " + err);
               }  
            }
            
            function isIE(){return!!document.all&&!!window.attachEvent&&!window.opera;}

            function hasCanvasImageData()
            {
                try
                {
	            var c=document.createElement("canvas");
	            var val=false;
	            var ctx;
	            try
	            {
		            if(typeof c.getContext=="function"&&(ctx=c.getContext("2d")))
		            {
			            val=(typeof ctx.getImageData=="function");
		            }
	            }catch(e){}
	            return val;
	            }
               catch(err)
               {
                 alert("hasCanvasImageData : " + err);
               }  
            }
            
            function Secondzoom(imgType, state)
            {
                try
                {
                ////alert("Secondzoom : imgType : " + imgType +  " state : " + state);
    	        prefix=(state=="in")? 1 : -1;
    	        if(imgType == "0")
                    zoomit(imgSlip,'cnvs_SlipImage',bIsSlipInverted, 0);
                else
                    zoomit(imgSecondCheque,'cnvs_ChequeSecondImage',bIsChequeInverted, 1);
                    //else
                  //  zoomit(imgSecondCheque,'cnvs_ChequeSecondImage',bIsChequeInverted, 1);
                }
               catch(err)
               {
                 alert("hasCanvasImageData : " + err);
               }  
            }
            
            function zoom(imgType, state)
            {
                try
                {
                 ////alert("zoom : imgType : " + imgType +  " state : " + state + " CnvsName : " + CnvsName + " imgCheque : " + imgCheque);
    	        prefix=(state=="in")? 1 : -1;
    	        if(imgType == "0")
                    zoomit(imgSlip,'cnvs_SlipImage',bIsSlipInverted, 0);
                else
                    zoomit(imgCheque,CnvsName,bIsChequeInverted, 1);
                }
               catch(err)
               {
                 alert("hasCanvasImageData : " + err);
               }  
            }
            
            var Old_L=0;
            var Old_T=0;
            function zoomit_OLD(imgToZoom, cnvsID, isInverted, iType)
            {
                
                try
                { 
                if(imgToZoom!=null)
                {
                   
                    var imgW = Math.round(parseInt(imgToZoom.style.width)+(parseInt(imgToZoom.style.width)*zoomfactor*prefix));
                    var imgH = Math.round(parseInt(imgToZoom.style.height)+(parseInt(imgToZoom.style.height)*zoomfactor*prefix));
                     
                    if ((parseInt(imgW)>minWidth&&parseInt(imgW)<maxHeight))
                    {	
	                    imgToZoom.style.width=imgW + "px";
	                    imgToZoom.style.height=imgH + "px";
                    }
                    var canvas = document.getElementById(cnvsID);
                    var ctx = canvas.getContext("2d");
                    canvas.width = imgW;
                    canvas.height = imgH;
                    //alert("hasCanvasImageData : cnvsID : " + cnvsID + " canvas.width : " + canvas.width + " canvas.height : " + canvas.height + " imgToZoom.style.width : " + imgToZoom.style.width + " imgToZoom.style.height : " +imgToZoom.style.width);
                    ctx.drawImage(imgToZoom, 0, 0, imgW, imgH);

                    if(hasCanvasImageData())
	                {
	                    
 		                ///alert("ctx.drawImage");
		                if(isInverted)
		                {
		                    if(iType == "0")
		                        bIsSlipInverted = false;
		                    else
		                        bIsChequeInverted = false;
                            invertit(iType);
                        }
	                }
	            }
	            }
               catch(err)
               {
                 alert("zoomit : " + err);
               }  
            }   
            
            function Scroll(imgType,id)
            {
                try
                {
                var divID = "";
                if(imgType == "0")
                    divID = "divSlipImg";
                else
                    divID = divCheName;
                if(id==0)
                {
                    document.getElementById(divID).scrollTop=0;
                    document.getElementById(divID).scrollLeft=0;
                }
                else if(id==1)
                {
                    document.getElementById(divID).scrollTop=0;
                }
                else if(id==2)
                {
                    document.getElementById(divID).scrollTop=document.getElementById(divID).scrollHeight;
                }
                else
                {
                    document.getElementById(divID).scrollTop=document.getElementById(divID).scrollHeight;
                    document.getElementById(divID).scrollLeft=document.getElementById(divID).scrollWidth;
                }
                
                }
               catch(err)
               {
                 alert("Scroll : " + err);
               }  
            }
            
             function SecondScroll(imgType,id)
            {
                try
                {
                var divID = "";
                if(imgType == "0")
                    divID = "divSlipImg";
                else
                    divID = "ctl00_ContentPlaceHolder1_divSecondChequeImg";
                if(id==0)
                {
                    document.getElementById(divID).scrollTop=0;
                    document.getElementById(divID).scrollLeft=0;
                }
                else if(id==1)
                {
                    document.getElementById(divID).scrollTop=0;
                }
                else if(id==2)
                {
                    document.getElementById(divID).scrollTop=document.getElementById(divID).scrollHeight;
                }
                else
                {
                    document.getElementById(divID).scrollTop=document.getElementById(divID).scrollHeight;
                    document.getElementById(divID).scrollLeft=document.getElementById(divID).scrollWidth;
                }
                
                }
               catch(err)
               {
                 alert("Scroll : " + err);
               }  
            }
            
        
            function rotateRight(imgType)
            {
                try
                {
                if (jg)
                jg.clear();
                var tmp="";
                var cnvsID = "";
                var divID = "";
                var imgToRotate;
                var currRotation;
                var tmpInverted;
                
                if(imgType == "0")
                {
                    cnvsID = "cnvs_SlipImage";
                    divID = "divSlipImg";
                    imgToRotate = imgSlip;
                    currRotation = currSlipRotation;
                    tmpInverted = bIsSlipInverted;
                }
                else
                {
                    cnvsID = CnvsName;
                    divID = divCheName;
                    imgToRotate = imgCheque;
                    currRotation = currChequeRotation;
                    tmpInverted = bIsChequeInverted;
                }
                
                if(imgToRotate!=null)
                {
                    if(hasCanvasImageData())
	                {    
                        var canvas = document.getElementById(cnvsID);
	 	                var ctx = canvas.getContext("2d");
				        //var iWidth = parseInt(imgToRotate.style.width);
				        //var iHeight = parseInt(imgToRotate.style.height);
                        var iWidth = parseInt(imgToRotate.width);
                        var iHeight = parseInt(imgToRotate.height);

	 	                canvas.width = iWidth;
				        canvas.height=iHeight;
				        if(currRotation!=2)
				        {
				            ctx.rotate(180 * Math.PI / 180);
				            ctx.drawImage(imgToRotate, -iWidth, -iHeight, iWidth, iHeight);
				            currRotation = 2;
				        }
				        else
				        {
				            ctx.rotate(0 * Math.PI / 180);
				            ctx.drawImage(imgToRotate, 0, 0, iWidth, iHeight);
				            currRotation = 0;
				        }
				        if(tmpInverted)
		                {
		                    if(iType == "0")
		                        bIsSlipInverted = false;
		                    else
		                        bIsChequeInverted = false;
                            invertit(imgType);
                        }
		            }
		            else
		            {
                        if(currRotation==2)
                        {
	                        currRotation = 0;	               
                            imgToRotate.className='rotate';
                            document.getElementById(divID).appendChild(imgToRotate);
	                    }
                        else
                        {
	                        currRotation = 2;
	                        imgToRotate.className='rotate180';
                            document.getElementById(divID).appendChild(imgToRotate);
	                    }
                        if(tmpInverted)
                            tmp = imgToRotate.style.filter;
                        else
                            tmp = "";
                        imgToRotate.style.filter = tmp + 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + currRotation + ')';
                    }
                    if(imgType == "0")
                        currSlipRotation = currRotation;
                    else
                        currChequeRotation = currRotation;
                }
                
                }
               catch(err)
               {
                 alert("rotateRight : " + err);
               }  
            } 
            
            
            function SecondrotateRight(imgType)
            {
                try
                {
                if (jb)
                jb.clear();
                var tmp="";
                var cnvsID = "";
                var divID = "";
                var imgToRotate;
                var currRotation;
                var tmpInverted;
                
                if(imgType == "0")
                {
                    cnvsID = "cnvs_SlipImage";
                    divID = "divSlipImg";
                    imgToRotate = imgSlip;
                    currRotation = currSlipRotation;
                    tmpInverted = bIsSlipInverted;
                }
                else
                {
                    cnvsID = "cnvs_ChequeSecondImage";
                    divID = "divSecondChequeImg";
                    imgToRotate = imgSecondCheque;
                    currRotation = currChequeRotation;
                    tmpInverted = bIsChequeInverted;
                }
                
                if(imgToRotate!=null)
                {
                    if(hasCanvasImageData())
	                {    
                        var canvas = document.getElementById(cnvsID);
	 	                var ctx = canvas.getContext("2d");
				        var iWidth = parseInt(imgToRotate.style.width);
				        var iHeight = parseInt(imgToRotate.style.height);
				        canvas.width=iWidth;
				        canvas.height=iHeight;
				        if(currRotation!=2)
				        {
				            ctx.rotate(180 * Math.PI / 180);
				            ctx.drawImage(imgToRotate, -iWidth, -iHeight, iWidth, iHeight);
				            currRotation = 2;
				        }
				        else
				        {
				            ctx.rotate(0 * Math.PI / 180);
				            ctx.drawImage(imgToRotate, 0, 0, iWidth, iHeight);
				            currRotation = 0;
				        }
				        if(tmpInverted)
		                {
		                    if(iType == "0")
		                        bIsSlipInverted = false;
		                    else
		                        bIsChequeInverted = false;
                            invertit(imgType);
                        }
		            }
		            else
		            {
                        if(currRotation==2)
                        {
	                        currRotation = 0;	               
                            imgToRotate.className='rotate';
                            document.getElementById(divID).appendChild(imgToRotate);
	                    }
                        else
                        {
	                        currRotation = 2;
	                        imgToRotate.className='rotate180';
                            document.getElementById(divID).appendChild(imgToRotate);
	                    }
                        if(tmpInverted)
                            tmp = imgToRotate.style.filter;
                        else
                            tmp = "";
                        imgToRotate.style.filter = tmp + 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + currRotation + ')';
                    }
                    if(imgType == "0")
                        currSlipRotation = currRotation;
                    else
                        currChequeRotation = currRotation;
                }
                
                }
               catch(err)
               {
                 alert("SecondrotateRight : " + err);
               }  
            } 
            
            
            function fitTo(imgType,id)
            {
                if (jg)
                jg.clear();
 
                try
                {
                var imgToFit;
                var SecondimgToFit
                var cnvsID;
                var iWidth, iHeight;
                var tmpisInverted;
                
	            if(imgType == "0")
	            {
	                switch(id)
	                {
	                  case 0: 
	                    iWidth = stdImgPanelWidth;
	                    iHeight = ((actual_Slip_img_height*stdImgPanelWidth)/actual_Slip_img_width);
	                    break;
	                  default: 
	                    iWidth = ((actual_Slip_img_width*stdImgPanelHeight)/actual_Slip_img_height);
	                    iHeight = stdImgPanelHeight;
	                }
	                cnvsID = "cnvs_SlipImage";
	                imgToFit = imgSlip;
	                tmpisInverted = bIsSlipInverted;
	                bIsSlipInverted = (bIsSlipInverted) ? false : bIsSlipInverted;
	            }
	            else
	            {
	                switch(id)
	                {
	                  case 0: 
	                    iWidth = stdImgPanelWidth;
	                    iHeight = ((actual_Cheque_img_height*stdImgPanelWidth)/actual_Cheque_img_width);
	                    break;
	                  default: 
	                    iWidth = ((actual_Cheque_img_width*stdImgPanelHeight)/actual_Cheque_img_height);
	                    iHeight = stdImgPanelHeight;
	                }
	                cnvsID = CnvsName;
	                imgToFit = imgCheque;
	                tmpisInverted = bIsChequeInverted;
	                bIsChequeInverted = (bIsChequeInverted) ? false : bIsChequeInverted;
	            }
	            
	            if(imgToFit!=null)
	            {
                    imgToFit.style.height = iHeight + "px";
                    imgToFit.style.width = iWidth + "px";

	                DrawIt(cnvsID, imgToFit);	            
	                if(tmpisInverted)
		            {
                        invertit(imgType);
                    }
                }
                }
               catch(err)
               {
                 alert("fitTo : " + err);
               }  
            }        
            
            
            function SecondfitTo(imgType,id)
            {
                if (jb)
                jb.clear();
 
                try
                {
                var imgToFit;
                var SecondimgToFit
                var cnvsID;
                var iWidth, iHeight;
                var tmpisInverted;
                
	            if(imgType == "0")
	            {
	                switch(id)
	                {
	                  case 0: 
	                    iWidth = stdImgPanelWidth;
	                    iHeight = ((actual_Slip_img_height*stdImgPanelWidth)/actual_Slip_img_width);
	                    break;
	                  default: 
	                    iWidth = ((actual_Slip_img_width*stdImgPanelHeight)/actual_Slip_img_height);
	                    iHeight = stdImgPanelHeight;
	                }
	                cnvsID = "cnvs_SlipImage";
	                imgToFit = imgSlip;
	                tmpisInverted = bIsSlipInverted;
	                bIsSlipInverted = (bIsSlipInverted) ? false : bIsSlipInverted;
	            }
	            else
	            {
	                switch(id)
	                {
	                  case 0: 
	                    iWidth = stdImgPanelWidth;
	                    iHeight = ((actual_Cheque_img_height*stdImgPanelWidth)/actual_Cheque_img_width);
	                    break;
	                  default: 
	                    iWidth = ((actual_Cheque_img_width*stdImgPanelHeight)/actual_Cheque_img_height);
	                    iHeight = stdImgPanelHeight;
	                }
	                cnvsID = "cnvs_ChequeSecondImage";
	                imgToFit = imgSecondCheque;
	                tmpisInverted = bIsChequeInverted;
	                bIsChequeInverted = (bIsChequeInverted) ? false : bIsChequeInverted;
	            }
	            
	            if(imgToFit!=null)
	            {
                    imgToFit.style.height = iHeight + "px";
                    imgToFit.style.width = iWidth + "px";

	                DrawIt(cnvsID, imgToFit);	            
	                if(tmpisInverted)
		            {
                        invertit(imgType);
                    }
                }
                }
               catch(err)
               {
                 alert("fitTo : " + err);
               }  
            }        

            

            function DrawIt(cnvsID, imgElement)
            {
                try
                {
	            if(hasCanvasImageData())
	            {
 		            var canvas = document.getElementById(cnvsID);
	 	            var ctx = canvas.getContext("2d");	 	            
	 	            canvas.width=parseInt(imgElement.style.width);
	 	            canvas.height=parseInt(imgElement.style.height);
		            ctx.drawImage(imgElement,0,0,canvas.width,canvas.height);
	            }
	            else
	            {
		            imgElement.style.visibility="visible";
	            }
	            }
               catch(err)
               {
                 alert("DrawIt : " + err);
               }  
            }
            
            function DrawSecondIt(cnvsID, imgElement)
            {
                try
                {
	            if(hasCanvasImageData())
	            {
 		            var canvas = document.getElementById(cnvsID);
	 	            var ctx = canvas.getContext("2d");	 	            
	 	            canvas.width=parseInt(imgElement.style.width);
	 	            canvas.height=parseInt(imgElement.style.height);
		            ctx.drawImage(imgElement,0,0,canvas.width,canvas.height);
	            }
	            else
	            {
		            imgElement.style.visibility="visible";
	            }
	            }
               catch(err)
               {
                 alert("DrawIt : " + err);
               }  
            }
            
            
            function invertit(imgType)
            {
                try
                {
                var cnvsID, imgToInvert;
                
            	if(imgType == "0")
	            {
	                cnvsID = "cnvs_SlipImage";
	                imgToInvert = imgSlip;
	                bIsSlipInverted = !bIsSlipInverted;
	            }
	            else
	            {
	                cnvsID = CnvsName;
	                imgToInvert = imgCheque;
	                bIsChequeInverted = !bIsChequeInverted;
	            }
	            
	            if(imgToInvert != null)
	            {
	                if(hasCanvasImageData())
	                {
		                var canvas = document.getElementById(cnvsID);
		                var ctx = canvas.getContext("2d");
		                var px=ctx.getImageData(0,0,canvas.width,canvas.height);
		                var l= px.data.length;
		                var i=0;
		                for(i=0;i<l;i+=4)
		                {
		 	                px.data[i+0] = 255-px.data[i+0];
	 		                px.data[i+1] = 255-px.data[i+1];
		 	                px.data[i+2] = 255-px.data[i+2];						
		                }
		                ctx.putImageData(px, 0, 0);
		                return true;
	                }
	                else if(isIE())
	                {
		                imgToInvert.style.filter+=" invert";
		                return true;
	                }
	            }
	            
	            }
               catch(err)
               {
                 alert("invertit : " + err);
               }  
            }
            
            function Secondinvertit(imgType)
            {
                try
                {
                var cnvsID, SecondimgToInvert;
                
            	if(imgType == "0")
	            {
	                cnvsID = "cnvs_SlipImage";
	                SecondimgToInvert = imgSlip;
	                bIsSlipInverted = !bIsSlipInverted;
	            }
	            else
	            {
	                cnvsID = "cnvs_ChequeSecondImage";
	                SecondimgToInvert = imgSecondCheque;
	                bIsChequeInverted = !bIsChequeInverted;
	            }
	            
	            if(SecondimgToInvert != null)
	            {
	                if(hasCanvasImageData())
	                {
		                var canvas = document.getElementById(cnvsID);
		                var ctx = canvas.getContext("2d");
		                var px=ctx.getImageData(0,0,canvas.width,canvas.height);
		                var l= px.data.length;
		                var i=0;
		                for(i=0;i<l;i+=4)
		                {
		 	                px.data[i+0] = 255-px.data[i+0];
	 		                px.data[i+1] = 255-px.data[i+1];
		 	                px.data[i+2] = 255-px.data[i+2];						
		                }
		                ctx.putImageData(px, 0, 0);
		                return true;
	                }
	                else if(isIE())
	                {
		                SecondimgToInvert.style.filter+=" invert";
		                return true;
	                }
	            }
	            
	            }
               catch(err)
               {
                 alert("Secondinvertit : " + err);
               }  
            }

            

            function SetCurrentSeq(SeqNo)
            {
                try
                {
                SelectedSeq = SeqNo;
                 }
               catch(err)
               {
                 alert("SetCurrentSeq : " + err);
               } 
            }
            
            function SetCurrentType(type)
            {
                try
                {
                CurrentType = type;
                }
               catch(err)
               {
                 alert("SetCurrentType : " + err);
               } 
            }
            
            function SetCurrentImage(imagetype)
            {
                try
                {
                CurrentImage = imagetype;
                }
               catch(err)
               {
                 alert("SetCurrentImage : " + err);
               } 
            }
            
            function changeImg(eid,imgname)
            {
                try
                {
	            document.getElementById(eid.id).src='Imgcontrols/'+imgname;
	            }
               catch(err)
               {
                 alert("changeImg : " + err);
               } 
            }            
            
            function applyChanges()
            {
                try
                {
              actual_img_width= ChqImg.width;
              actual_img_height= ChqImg.height;

              var field=document.getElementById(outImage);
              field.src=ChqImg.src;
              field.style.height=ChqimgpanelHeight+ "px";
              field.style.width=((actual_img_width*ChqimgpanelHeight)/actual_img_height)+ "px";
               }
               catch(err)
               {
                 alert("applyChanges : " + err);
               } 
            }

            function SecondpreviewChq(imgType, itype)
            {
                try
                {
                var btnID = "";
                var btnSecondClicked = itype;
                if(imgType == "0")
                {
                    btnID = 'ctl00_ContentPlaceHolder1_btn_SlipBF';
                    if ((CurrentSlipImage == 0)&& btnSecondClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipBR';
                        CurrentSlipImage = 1;
                    }
                    else if ((((CurrentSlipImage == 0)||(CurrentSlipImage == 1)) && btnSecondClicked == 1)||((CurrentSlipImage == 3)&& btnSecondClicked == 0))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipGF';
                        CurrentSlipImage = 2;
                    }
                    else if (((CurrentSlipImage == 1) && (btnSecondClicked == 0)) || (((CurrentSlipImage == 2)||(CurrentSlipImage == 3)) && (btnSecondClicked == 1)))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipBF';
                        CurrentSlipImage = 0;
                    }
                    else if((CurrentSlipImage == 2)&& btnSecondClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipGR';
                        CurrentSlipImage = 3;                    
                    }                    
                }
                else
                {
                   btnID = 'ctl00_ContentPlaceHolder1_btn_SecondChequeBF';
                    if ((CurrentSecondChequeImage == 0)&& btnSecondClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SecondChequeBR';
                        CurrentSecondChequeImage = 1;
                    }
                    else if ((((CurrentSecondChequeImage == 0)||(CurrentSecondChequeImage == 1)) && btnSecondClicked == 1)||((CurrentSecondChequeImage == 3)&& btnSecondClicked == 0))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SecondChequeGF';
                        CurrentSecondChequeImage = 2;
                    }
                    else if (((CurrentSecondChequeImage == 1) && (btnSecondClicked == 0)) || (((CurrentSecondChequeImage == 2)||(CurrentSecondChequeImage == 3)) && (btnSecondClicked == 1)))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SecondChequeBF';
                        CurrentSecondChequeImage = 0;
                    }
                    else if((CurrentSecondChequeImage == 2)&& btnSecondClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SecondChequeGR';
                        CurrentSecondChequeImage = 3;                    
                    }
                }
                if(btnID!="")
                {
                    var btn=document.getElementById(btnID);
                    btn.click();
                }
                }
               catch(err)
               {
                 alert("SecondpreviewChq : " + err);
               } 
            }
            
            function previewChq(imgType, itype)
            {
                try
                {
                var btnID = "";
                var btnClicked = itype;
                if(imgType == "0")
                {
                    btnID = 'ctl00_ContentPlaceHolder1_btn_SlipBF';
                    if ((CurrentSlipImage == 0)&& btnClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipBR';
                        CurrentSlipImage = 1;
                    }
                    else if ((((CurrentSlipImage == 0)||(CurrentSlipImage == 1)) && btnClicked == 1)||((CurrentSlipImage == 3)&& btnClicked == 0))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipGF';
                        CurrentSlipImage = 2;
                    }
                    else if (((CurrentSlipImage == 1) && (btnClicked == 0)) || (((CurrentSlipImage == 2)||(CurrentSlipImage == 3)) && (btnClicked == 1)))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipBF';
                        CurrentSlipImage = 0;
                    }
                    else if((CurrentSlipImage == 2)&& btnClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_SlipGR';
                        CurrentSlipImage = 3;                    
                    }                    
                }
                else
                {
                   btnID = 'ctl00_ContentPlaceHolder1_btn_ChequeBF';
                    if ((CurrentChequeImage == 0)&& btnClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_ChequeBR';
                        CurrentChequeImage = 1;
                    }
                    else if ((((CurrentChequeImage == 0)||(CurrentChequeImage == 1)) && btnClicked == 1)||((CurrentChequeImage == 3)&& btnClicked == 0))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_ChequeGF';
                        CurrentChequeImage = 2;
                    }
                    else if (((CurrentChequeImage == 1) && (btnClicked == 0)) || (((CurrentChequeImage == 2)||(CurrentChequeImage == 3)) && (btnClicked == 1)))
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_ChequeBF';
                        CurrentChequeImage = 0;
                    }
                    else if((CurrentChequeImage == 2)&& btnClicked == 0)
                    {
                        btnID = 'ctl00_ContentPlaceHolder1_btn_ChequeGR';
                        CurrentChequeImage = 3;                    
                    }
                }
                if(btnID!="")
                {
                    var btn=document.getElementById(btnID);
                    btn.click();
                }
                }
               catch(err)
               {
                 alert("previewChq : " + err);
               } 
            }
            

            function SecondFlipIt(imgType, type) 
            {
                try
                {
	               SecondpreviewChq(imgType, type);
	             }
               catch(err)
               {
                 alert("SecondFlipIt : " + err);
               } 
            }
            
           function FlipIt(imgType, type) 
            {
                try
                {
                 
                      previewChq(imgType, type);
                
                   
	          
	             }
               catch(err)
               {
                 alert("FlipIt : " + err);
               } 
            }
            

            function refresh(imgType)
            {
                try
                {
                if(imgType == "0")
                {
                	if (bIsSlipInverted)
		                invertit(imgType);
		            if(CurrentSlipImage != 0)
		            {
                        var btn=document.getElementById('ctl00_ContentPlaceHolder1_btn_SlipBF');
                        if(btn != null)
                        {
                        btn.click(); 
                        CurrentSlipImage = 0;
                        }
                    }
                }
                else
                {
                	if (bIsChequeInverted)
		                invertit(imgType); 
                        var btn=document.getElementById('ctl00_ContentPlaceHolder1_btn_ChequeBF');
                        if(btn != null)
                        {
                            btn.click(); 
                            CurrentChequeImage = 0;
                        }
                }
                }
               catch(err)
               {
                 alert("refresh : " + err);
               } 
            }      
            
           
           function Secondrefresh(imgType)
            {
                try
                {
                if(imgType == "0")
                {
                	if (bIsSlipInverted)
		                Secondinvertit(imgType);
		            if(CurrentSlipImage != 0)
		            {
                        var btn=document.getElementById('ctl00_ContentPlaceHolder1_btn_SlipBF');
                        if(btn != null)
                        {
                        btn.click(); 
                        CurrentSlipImage = 0;
                        }
                    }
                }
                else
                {
                	if (bIsChequeInverted)
		                Secondinvertit(imgType); 
                        var btn=document.getElementById('ctl00_ContentPlaceHolder1_btn_SecondChequeBF');
                        if(btn != null)
                        {
                            btn.click(); 
                            CurrentSecondChequeImage = 0;
                        }
                }
                }
               catch(err)
               {
                 alert("Secondrefresh : " + err);
               } 
            }      
            
           
           

            function invertitIE()
            {
                try
                {
                var cimg = document.getElementById(Ex.id);
                if(!isInverted)
                {
	                cimg.style.filter= cimg.style.filter + ' progid:DXImageTransform.Microsoft.BasicImage(invert=1)';
	                isInverted=true;
                }
                else
                {
                    image.style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + currRotation + ')';
	       
	                isInverted=false;
                }
                var cimg = document.getElementById(e);
                if(!isInverted)
                {
	                cimg.style.filter= cimg.style.filter + ' progid:DXImageTransform.Microsoft.BasicImage(invert=1)';
	                isInverted=true;
                }
                else
                {
                    image.style.filter = 'progid:DXImageTransform.Microsoft.BasicImage(rotation=' + currRotation + ')';
	     
	                isInverted=false;
                }
                
                 }
               catch(err)
               {
                 alert("invertitIE : " + err);
               } 
            }

            var strtX=0;
            var strtY=0;
            var endX=0;
            var endY=0;
            var dWidth=0;
            var dHeight=0;
            var bnding=false;
            var isAreaSelected=false;

            function StartSelection()
            {
                try
                {
                strtX=event.x;
                strtY=event.y;
            	
                dband.style.left=strtX;
                dband.style.top=strtY;
                dband.style.width=0;
                dband.style.height=0;
                dband.style.border= 'none';
                bnding=true;
                 }
               catch(err)
               {
                 alert("StartSelection : " + err);
               } 
            }

            function StopSelection()
            {
                try
                {
                bnding=false;
                 }
               catch(err)
               {
                 alert("StopSelection : " + err);
               } 
            }

            function DrawSelect()
            {
                try
                {
                if(!bnding)
	                return;

                endX=event.x+2;
                endY=event.y+2;

                dWidth = (endX>strtX) ? (endX-strtX) : (strtX-endX);
                dHeight = (endY>strtY) ? (endY-strtY) : (strtY-endY);

                dband.style.border = '2px dotted #FF0000';

                dband.style.width= dWidth;
                dband.style.height= dHeight;
                isAreaSelected=true;
                
                }
               catch(err)
               {
                 alert("DrawSelect : " + err);
               } 
            }

            function ZoomSelection()
            {
                try
                {
                if(!isAreaSelected)
	                return;

                var ratio;

                dWidth=dWidth*1.6;

                if(image!=null)
                {
                    if(parseInt(image.style.width)>2000)
                    {
                        return;
	                    if(dHeight>dWidth)
		                    ratio = (ChqimgpanelHeight/dHeight);
	                    else
		                    ratio = (ChqimgpanelWidth/dWidth);
                    }
                    else
                    {
	                    if(dHeight>dWidth)
		                    ratio = (parseInt(image.style.height)/dHeight);
	                    else
		                    ratio = (parseInt(image.style.width)/dWidth);
                    }


                    var imgW = Math.round((parseInt(image.style.width)) * ratio);
                    var imgH = Math.round((parseInt(image.style.height)) * ratio);

                    image.style.width=parseInt(imgW);
                    image.style.height=parseInt(imgH);


                    dband.style.width=0;
                    dband.style.height=0;
                    dband.style.border= 'none';
                    isAreaSelected=false;
                }
                
                 }
               catch(err)
               {
                 alert("ZoomSelection : " + err);
               } 
            } 
            
            function submitBatch(cID)
            {
                try
                {
                var btn=document.getElementById('ctl00_ContentPlaceHolder1_btnSubmitBatch');
                if(btn != null)
                {
                btn.click();
                }
                 }
               catch(err)
               {
                 alert("submitBatch : " + err);
               } 
            }
            
            function doFire(objID) 
            {
                try
                {
                var newEvt = document.createEventObject();
                newEvt.button = 1;
                document.all(objID).fireEvent("onclick", newEvt);
                event.cancelBubble = true;
                 }
               catch(err)
               {
                 alert("doFire : " + err);
               } 
            }