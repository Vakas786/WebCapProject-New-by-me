﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.IO.Compression;
using CtsWebCoreOutward.Authorize;
using Microsoft.AspNetCore.Mvc;
using CtsWebCoreOutward.ViewModel;
using CtsWebCoreOutward.Models;
using System.Data.SqlClient;
using CtsWebCoreOutward.Filter;
using Microsoft.EntityFrameworkCore;
using CtsWebCoreOutward.ComonUtility;
using System.Data;
using Microsoft.AspNetCore.Http;

namespace CtsWebCoreOutward.Controllers
{

    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class DownloadFileController : Controller
    {
        private readonly DownloadFileDataContext _DBContext;
        public DownloadFileController(DownloadFileDataContext dbContext) { _DBContext = dbContext; }

        int iFuntionNumber = 0;
        //[OutputCacheAttribute(NoStore = true, Duration = 0)]
        public ActionResult DownloadFile(int? id)
        {
            DownloadFileViewModel.WrapperDownloadFile loWrapperDownloadFile = new DownloadFileViewModel.WrapperDownloadFile();
            //DownloadFileDataContext loDownloadFileDataContext = new DownloadFileDataContext();

            //loDownloadFileDataContext = new DownloadFileDataContext();
            //int iFuntionNumber = 100;
            if (id != null)
            {

                iFuntionNumber = Convert.ToInt16(id);

            }
            loWrapperDownloadFile.iFuntionNo = iFuntionNumber;
            string sBOFD = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stPhBRNo;
            loWrapperDownloadFile.loFileDetailsList = getFileDetailsList("temp", sBOFD);
            loWrapperDownloadFile.loDownloadedSummaryList = getDownloadedSummary(sBOFD);
            return View(loWrapperDownloadFile);
        }

        public FileResult AllFilesDownload(string FileTypeID)
        {
            string sFolder4Image = "HostFiles";
            try
            {
                string sToday = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").sToday;
                string sBOFD = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stPhBRNo;
                string sLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;
                //DownloadFileDataContext loDownloadFileDataContext = new DownloadFileDataContext();
                List<DownloadFileViewModel.DownloadFileConfigure> loDownloadFileConfigureList = new List<DownloadFileViewModel.DownloadFileConfigure>();
                loDownloadFileConfigureList = getDownloadFileConfigureList(sBOFD);

                DownloadFileViewModel.DownloadFileConfigure loDownloadFileConfigure = new DownloadFileViewModel.DownloadFileConfigure();
                loDownloadFileConfigure = loDownloadFileConfigureList.Where(x => x.FileTypeID == Convert.ToInt16(FileTypeID)).FirstOrDefault();

                string sOutputFileName = loDownloadFileConfigure.FileNamingConvention;
                string sOutFilePath = loDownloadFileConfigure.FilePath;
                string sFileNameWithPath = "";

                string sPath = "HostFile" + "_" + sToday.Replace("/", "") + "_" + String.Format("{0:d9}", (DateTime.Now.Ticks / 10) % 1000000000);
                string sServerPath4HostFile = Path.Combine(CommonFunctions.AppTempPath, sPath);
                //string sServerPath4HostFile = Path.Combine(sOutFilePath, sPath);
                if (!Directory.Exists(sServerPath4HostFile))
                {
                    Directory.CreateDirectory(sServerPath4HostFile);
                }

                if (!Directory.Exists(sOutFilePath))
                {
                    Directory.CreateDirectory(sOutFilePath);
                }

                List<DownloadFileViewModel.FileDownloadBOFD> loBOFDList = new List<DownloadFileViewModel.FileDownloadBOFD>();
                loBOFDList = GetBOFDList(DateTime.Now, Convert.ToInt32(FileTypeID), sLoginName, sBOFD);

                foreach (var loBOFD in loBOFDList)
                {
                    sOutputFileName = loDownloadFileConfigure.FileNamingConvention;
                    sOutputFileName = sOutputFileName.Replace("<DD>", DateTime.Now.Day.ToString());
                    sOutputFileName = sOutputFileName.Replace("<MM>", DateTime.Now.Month.ToString());
                    sOutputFileName = sOutputFileName.Replace("<YYYY>", DateTime.Now.Year.ToString());
                    sOutputFileName = sOutputFileName.Replace("<YY>", DateTime.Now.Year.ToString().Substring(2, 2));
                    sOutputFileName = sOutputFileName.Replace("<HH>", DateTime.Now.ToString("HH"));
                    sOutputFileName = sOutputFileName.Replace("<mm>", DateTime.Now.ToString("mm"));
                    sOutputFileName = sOutputFileName.Replace("<ss>", DateTime.Now.ToString("ss"));
                    sOutputFileName = sOutputFileName.Replace("<BranchName>", loBOFD.BranchName);
                    List<DownloadFileViewModel.FileDownloadData> loFileDownloadDataList = new List<DownloadFileViewModel.FileDownloadData>();
                    loFileDownloadDataList = getDownloadFileData(DateTime.Now, Convert.ToInt32(FileTypeID), sLoginName, loBOFD.BOFD);
                    sOutputFileName = sOutputFileName.Replace("<INSTCOUNT>", "_" + (loFileDownloadDataList.Count.ToString()));
                    UPDATE_DownloadFileName(sOutputFileName, loFileDownloadDataList[0].DownloadID);
                    sFileNameWithPath = sServerPath4HostFile + "\\" + sOutputFileName;
                    StreamWriter sw = new StreamWriter(sFileNameWithPath, false);
                    foreach (var loData in loFileDownloadDataList)
                    {
                        sw.Write(loData.DownloadData);
                        sw.Write(sw.NewLine);
                    }
                    sw.Close();
                }
                if (loBOFDList.Count == 1)
                {
                    sFolder4Image = sPath + ".txt";
                    byte[] finalresult = System.IO.File.ReadAllBytes(sFileNameWithPath);
					if (System.IO.File.Exists(sFileNameWithPath))
					{
                        System.IO.File.Delete(sFileNameWithPath);
                    }

                    return File(finalresult, "application/text", sOutputFileName);
                   // return File(sFileNameWithPath, "application/text", sOutputFileName);
                    
                }
                else
                {
                    sFolder4Image = sPath + ".zip";
                    var archive = Path.Combine(CommonFunctions.AppTempPath, sFolder4Image);
                    var temp = Path.Combine(CommonFunctions.AppTempPath, sPath);
                    ZipFile.CreateFromDirectory(temp, archive);
                    byte[] finalresult = System.IO.File.ReadAllBytes(archive);
                    if (System.IO.File.Exists(archive))
                    {
                        System.IO.File.Delete(archive);
                    }
                    return File(finalresult, "application/zip", sFolder4Image);
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public ActionResult ExportToCSV(string FileTypeID)
        {
            try
            {
                string sBOFD = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stPhBRNo;
                string sLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;
                //DownloadFileDataContext loDownloadFileDataContext = new DownloadFileDataContext();
                List<DownloadFileViewModel.DownloadFileConfigure> loDownloadFileConfigureList = new List<DownloadFileViewModel.DownloadFileConfigure>();
                loDownloadFileConfigureList = getDownloadFileConfigureList(sBOFD);

                DownloadFileViewModel.DownloadFileConfigure loDownloadFileConfigure = new DownloadFileViewModel.DownloadFileConfigure();
                loDownloadFileConfigure = loDownloadFileConfigureList.Where(x => x.FileTypeID == Convert.ToInt16(FileTypeID)).FirstOrDefault();

                string sOutputFileName = loDownloadFileConfigure.FileNamingConvention;
                string sOutFilePath = loDownloadFileConfigure.FilePath;
                string sFileNameWithPath = "";


                if (!Directory.Exists(sOutFilePath))
                {
                    Directory.CreateDirectory(sOutFilePath);
                }


                sOutputFileName = sOutputFileName.Replace("<DD>", DateTime.Now.Day.ToString());
                sOutputFileName = sOutputFileName.Replace("<MM>", DateTime.Now.Month.ToString());
                sOutputFileName = sOutputFileName.Replace("<YYYY>", DateTime.Now.Year.ToString());
                sOutputFileName = sOutputFileName.Replace("<YY>", DateTime.Now.Year.ToString().Substring(2, 2));
                sOutputFileName = sOutputFileName.Replace("<HH>", DateTime.Now.ToString("HH"));
                sOutputFileName = sOutputFileName.Replace("<mm>", DateTime.Now.ToString("mm"));
                sOutputFileName = sOutputFileName.Replace("<ss>", DateTime.Now.ToString("ss"));

                // string sFileNameWithPath = "C:\\GenFile\\text.CSV";
                //  string sOutFileName = Path.GetFileName(sFileNameWithPath);
                List<DownloadFileViewModel.FileDownloadData> loFileDownloadDataList = new List<DownloadFileViewModel.FileDownloadData>();
                loFileDownloadDataList = getDownloadFileData(DateTime.Now, Convert.ToInt32(FileTypeID), sLoginName, sBOFD);



                sOutputFileName = sOutputFileName.Replace("<INSTCOUNT>", "_" + (loFileDownloadDataList.Count.ToString()));

                UPDATE_DownloadFileName(sOutputFileName, loFileDownloadDataList[0].DownloadID);
                sFileNameWithPath = sOutFilePath + "\\" + sOutputFileName;
                StreamWriter sw = new StreamWriter(sFileNameWithPath, false);
                foreach (var loData in loFileDownloadDataList)
                {
                    sw.Write(loData.DownloadData);
                    sw.Write(sw.NewLine);
                }


                sw.Close();

                var memory = new MemoryStream();
                using (var stream = new FileStream(sFileNameWithPath, FileMode.Open))
                {
                    stream.CopyToAsync(memory);
                }
                memory.Position = 0;
                return File(memory, "text/csv", sOutputFileName);

                //Response.Clear();
                //Response.ContentType = "application/csv";
                //Response.AddHeader("Content-Disposition", "attachment; filename=" + sOutputFileName);
                //Response.WriteFile(sFileNameWithPath);
                //Response.Flush();
                //Response.End();

                //return RedirectToRoute("DownloadFile", new { controller = "DownloadFile", action = "DownloadFile", id = iFuntionNumber });
            }
            catch (Exception)
            {
                return null;
            }
        }

        public ActionResult ExportToCSV_Redownload(string DownloadID)
        {
            try
            {
                string sBOFD = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stPhBRNo;

                //DownloadFileDataContext loDownloadFileDataContext = new DownloadFileDataContext();
                List<DownloadFileViewModel.DownloadFileConfigure> loDownloadFileConfigureList = new List<DownloadFileViewModel.DownloadFileConfigure>();
                loDownloadFileConfigureList = getDownloadFileConfigureList(sBOFD);
                List<DownloadFileViewModel.FileDownloadData> loFileDownloadDataList = new List<DownloadFileViewModel.FileDownloadData>();
                loFileDownloadDataList = get_ReDownloadFileData(Convert.ToInt32(DownloadID));
                int ifiletypeID = loFileDownloadDataList[0].FileTypeID;
                DownloadFileViewModel.DownloadFileConfigure loDownloadFileConfigure = new DownloadFileViewModel.DownloadFileConfigure();
                loDownloadFileConfigure = loDownloadFileConfigureList.Where(x => x.FileTypeID == Convert.ToInt32(ifiletypeID)).FirstOrDefault();
                string sOutputFileName = loFileDownloadDataList[0].FileName;
                string sOutFilePath = loDownloadFileConfigure.FilePath;
                string sFileNameWithPath = "";
                if (!Directory.Exists(sOutFilePath))
                {
                    Directory.CreateDirectory(sOutFilePath);
                }
                sFileNameWithPath = sOutFilePath + "\\" + sOutputFileName;

                if (System.IO.File.Exists(sFileNameWithPath))
                {
                    sOutputFileName = "Copy_" + DateTime.Now.TimeOfDay.ToString("hhmmss") + "_" + sOutputFileName;
                }

                sFileNameWithPath = sOutFilePath + "\\" + sOutputFileName;

                StreamWriter sw = new StreamWriter(sFileNameWithPath, false);
                foreach (var loData in loFileDownloadDataList)
                {
                    sw.Write(loData.DownloadData);
                    sw.Write(sw.NewLine);
                }
                sw.Close();

                var memory = new MemoryStream();
                using (var stream = new FileStream(sFileNameWithPath, FileMode.Open))
                {
                    stream.CopyToAsync(memory);
                }
                memory.Position = 0;

                return File(memory, "text/csv", sOutputFileName);

                //Response.Clear();
                //Response.ContentType = "application/csv";
                //Response.AddHeader("Content-Disposition", "attachment; filename=" + sOutputFileName);
                //Response.WriteFile(sFileNameWithPath);
                //Response.Flush();
                //Response.End();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public ActionResult DownloadDelete(int? FileTypeID, int? DownloadID)
        {
            DownloadFileViewModel.WrapperDownloadFile loWrapperDownloadFile = new DownloadFileViewModel.WrapperDownloadFile();
            // DownloadFileDataContext loDownloadFileDataContext = new DownloadFileDataContext();

            //loDownloadFileDataContext = new DownloadFileDataContext();
            UPDATE_DownloadDATA(FileTypeID, DownloadID);

            return Json(loWrapperDownloadFile);

        }


        public IEnumerable<dynamic> getFileDetailsList(string fsFunctionNo, string sBOFD)
        {
            var cmd = new SqlCommand();
            var con = new SqlConnection(CommonFunctions.ConStr);
            cmd.Connection = con;
            //using (var ctx = new DownloadFileDataContext())
            //using (var cmd = ctx.Database.Connection.CreateCommand())
            //{
            con.Open();
            cmd.CommandText = "getDownloadFileList";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("BOFD", sBOFD.handleDBNull()));
            using (var reader = cmd.ExecuteReader())
            {
                var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
                return model;
            }
            //}
        }

        public IEnumerable<dynamic> getDownloadedSummary(string sBOFD)
        {
            var cmd = new SqlCommand();
            var con = new SqlConnection(CommonFunctions.ConStr);
            cmd.Connection = con;
            //using (var ctx = new DownloadFileDataContext())
            //using (var cmd = ctx.Database.Connection.CreateCommand())
            //{
            con.Open();
            cmd.CommandText = "getDownloadedSummary";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("BOFD", sBOFD.handleDBNull()));
            using (var reader = cmd.ExecuteReader())
            {
                var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
                return model;
            }
            //}
        }

        public List<DownloadFileViewModel.DownloadFileConfigure> getDownloadFileConfigureList(string sBOFD)
        {
            try
            {
                List<SqlParameter> loSqlParameters = new List<SqlParameter>();
                loSqlParameters.Add(new SqlParameter("BOFD", sBOFD.handleDBNull()));
                return _DBContext.DBSet_DownloadFileConfigure.FromSql("getDownloadFileConfigure".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public List<DownloadFileViewModel.FileDownloadData> getDownloadFileData(DateTime dDate, int FileTypeID, string User, string sBOFD)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("dDate", dDate.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iFileTypeID", FileTypeID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("UserName", User.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("BOFD", sBOFD.handleDBNull()));
            return _DBContext.DBSet_FileDownloadData.FromSql("CMSP_ProcessDownloadFile".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }
        public List<DownloadFileViewModel.FileDownloadBOFD> GetBOFDList(DateTime dDate, int FileTypeID, string User, string sBOFD)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("dDate", dDate.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iFileTypeID", FileTypeID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("UserName", User.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("BOFD", sBOFD.handleDBNull()));
            return _DBContext.DBSet_FileDownloadBOFD.FromSql("CMSP_ProcessDownloadBOFDList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<DownloadFileViewModel.FileDownloadData> get_ReDownloadFileData(int DownloadID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("DownloadID", DownloadID.handleDBNull()));
            return _DBContext.DBSet_FileDownloadData.FromSql("CMSP_ReDownloadFile".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public bool UPDATE_DownloadFileName(string sFileName, int? DownLoadId)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("sFileName", sFileName.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iDownloadID", DownLoadId.handleDBNull()));

            _DBContext.Database.ExecuteSqlCommand("USP_UPDATE_DownloadFileName".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());

            return true;
        }

        public bool UPDATE_DownloadDATA(int? FiletypeID, int? DownLoadId)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("iFileTypeID", FiletypeID.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("iDownloadID", DownLoadId.handleDBNull()));

            _DBContext.Database.ExecuteSqlCommand("USP_UPDATE_DownloadCompleted".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray());

            return true;
        }
    }
}
