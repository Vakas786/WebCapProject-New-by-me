﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.IO.Compression;
using Microsoft.AspNetCore.Mvc;
using CtsWebCoreOutward.ViewModel;
using System.Data.SqlClient;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using Microsoft.EntityFrameworkCore;
using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.ComonUtility;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    public class CHIGatewayOutwardController : Controller
    {
        //
        // GET: /CHIGatewayOutward/CHIGatewayOutward/
        private readonly CHIGatewayOutwardDataContext _DBContext;
        public CHIGatewayOutwardController(CHIGatewayOutwardDataContext dbContext) { _DBContext = dbContext; }
        public ActionResult CHIGatewayOutward(int? id)
        {
            try
            {
                CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
                //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();
                loCHIGatewayOutwardViewModel.loCXFItemList = GetCXFItemList();
                loCHIGatewayOutwardViewModel.loCXFGeneratedStatusList = GetCXFGeneratedStatusList();
                //loCHIGatewayOutwardViewModel.loInwardReturnFileDetailsList = loCHIGatewayOutwardDataContext.GetInwardReturnFileDetailsList();

                loCHIGatewayOutwardViewModel.loInHouseInstrumentsDtlList = GetInHouseInstrumentsDetailsList();
                loCHIGatewayOutwardViewModel.loInHouseInstrumentsDtlReturnList = GetInHouseInstrumentsDetailsReturnList();

                loCHIGatewayOutwardViewModel.loInwardReturnFileReturnFileList = GetInwardReturnFileReturnFileList();
                loCHIGatewayOutwardViewModel.loSessionDetailsList = GetSessionDetailsList();
                // loCHIGatewayOutwardViewModel.loSessionReturnSessionList = loCHIGatewayOutwardDataContext.GetSessionReturnSessionList();
                return View(loCHIGatewayOutwardViewModel);
            }
            catch (Exception ex)
            {
                return View();
            }
        }


        public ActionResult GETData_CXF_Avl()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            // CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();

            loCHIGatewayOutwardViewModel.loCXFItemList = GetCXFItemList();

            return View("~/Views/CHIGatewayOutward/AvailCXFcreationList.cshtml", loCHIGatewayOutwardViewModel);

        }

        public ActionResult GETData_CXF_Gen()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            // CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();

            loCHIGatewayOutwardViewModel.loCXFGeneratedStatusList = GetCXFGeneratedStatusList();

            return View("~/Views/CHIGatewayOutward/CXFGeneratedStatusList.cshtml", loCHIGatewayOutwardViewModel);

        }

        //public ActionResult GETData_INWARD_DETAILS()
        //{
        //    CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
        //    CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();
        //    loCHIGatewayOutwardViewModel.loInwardReturnFileDetailsList = loCHIGatewayOutwardDataContext.GetInwardReturnFileDetailsList();
        //    return View("~/Areas/CHIGatewayOutward/Views/CHIGatewayOutward/InwardDetailsList.cshtml", loCHIGatewayOutwardViewModel);
        //}
        //public ActionResult GetInHouseInstrumentsDtl()
        //{
        //    CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
        //    CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();
        //    loCHIGatewayOutwardViewModel.loInHouseInstrumentsDtlList = loCHIGatewayOutwardDataContext.GetInHouseInstrumentsDetailsList();
        //    return View("~/Areas/CHIGatewayOutward/Views/CHIGatewayOutward/InHouseDetailsList.cshtml", loCHIGatewayOutwardViewModel);
        //}
        public ActionResult GETData_INWARD_Return_Files()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();

            loCHIGatewayOutwardViewModel.loInwardReturnFileReturnFileList = GetInwardReturnFileReturnFileList();

            return View("~/Views/CHIGatewayOutward/InwardReturnFileList.cshtml", loCHIGatewayOutwardViewModel);

        }

        public ActionResult GETData_Session_Details()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();

            loCHIGatewayOutwardViewModel.loSessionDetailsList = GetSessionDetailsList();

            return View("~/Views/CHIGatewayOutward/SessionDetailsList.cshtml.cshtml", loCHIGatewayOutwardViewModel);

        }


        public IActionResult GenerteAllCXF()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();
            loCHIGatewayOutwardViewModel.loCXFItemList = GetCXFItemList();
            string sToday = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").sToday;
            string sLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;

            CXFGenerate cXF = new CXFGenerate();
            string sCXFFilePath = cXF.GetConfigValues("OUTPUTFILEPATH") + "\\" + sToday.Replace("/", "");
            int iCXFCreatedItem = 0;
            int iCXFFileCreated = 0;
            if (Directory.Exists(sCXFFilePath))
            {
                Directory.Delete(sCXFFilePath, true);
            }

            var sSourcePath = sCXFFilePath;
            foreach (var loData in loCHIGatewayOutwardViewModel.loCXFItemList)
            {
                int? iNoOfFiles = 0;
                int iFileCount = 250;
                iNoOfFiles = (loData.iCount / iFileCount);

                if ((loData.iCount % iFileCount) != 0)
                    iNoOfFiles = iNoOfFiles + 1;
                for (int iCount = 0; iCount < iNoOfFiles; iCount++)
                {
                    if (cXF.CreateFiles("", loData.CLGType, loData.TBRN, sCXFFilePath, sLoginName, ref iCXFCreatedItem))
                    {
                        iCXFFileCreated++;
                    }
                }
            }
            var sTargetPath = Path.Combine(CommonFunctions.AppTempPath, "CXF_" + sToday.Replace("/", "") + ".zip");
            if (System.IO.File.Exists(sTargetPath))
            {
                System.IO.File.Delete(sTargetPath);
            }
            ZipFile.CreateFromDirectory(sSourcePath, sTargetPath);

            return File(new FileStream(sTargetPath, FileMode.Open), "application/zip", "CXF_" + sToday.Replace("/", "") + ".zip");

            //return Json(new { inStatus = liStatus, stMessage = lsSuccessMessage, inCXFCreatedCount = iCXFFileCreated, stOutFilePath = sTargetPath }, JsonRequestBehavior.AllowGet);
        }

        public FileResult CXFFileReDownload(string CXFFileName)
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();
            string sLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;
            string sToday = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").sToday;
            CXFGenerate cXF = new CXFGenerate();
            string sCXFFilePath = cXF.GetConfigValues("CXFArchivePath") + "\\" + sToday.Replace("/", "");
            string sFileNameOnly = Path.GetFileNameWithoutExtension(sCXFFilePath + @"\" + CXFFileName);

            string sTempPath = cXF.GetConfigValues("OUTPUTFILEPATH") + "\\" + sToday.Replace("/", "");
            if (Directory.Exists(sTempPath))
            {
                Directory.Delete(sTempPath, true);
            }
            Directory.CreateDirectory(sTempPath);
            string[] files = Directory.GetFiles(sCXFFilePath, sFileNameOnly + "*.*");
            foreach (string file in files)
            {
                FileInfo file_info = new FileInfo(file);
                System.IO.File.Copy(file, sTempPath + "\\" + file_info.Name, true);
            }

            files = Directory.GetFiles(sCXFFilePath, sFileNameOnly.Replace("CXF", "CIBF") + "*.*");
            foreach (string file in files)
            {
                FileInfo file_info = new FileInfo(file);
                System.IO.File.Copy(file, sTempPath + "\\" + file_info.Name, true);
            }

            var sSourcePath = sTempPath;
            var sTargetPath = Path.Combine(CommonFunctions.AppTempPath, sFileNameOnly + ".zip");
            if (System.IO.File.Exists(sTargetPath))
            {
                System.IO.File.Delete(sTargetPath);
            }
            ZipFile.CreateFromDirectory(sSourcePath, sTargetPath);
            return File(new FileStream(sTargetPath, FileMode.Open), "application/zip", sFileNameOnly + ".zip");
        }

        public ActionResult GenerateCXFFile(string CLGType, string sTBRN)
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();
            string sBOFD = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stPhBRNo;
            string sLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;
            string sToday = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").sToday;
            CXFGenerate cXF = new CXFGenerate();
            string sCXFFilePath = cXF.GetConfigValues("OUTPUTFILEPATH") + "\\" + sToday.Replace("/", "");
            int iCXFCreatedItem = 0;
            if (Directory.Exists(sCXFFilePath))
            {
                Directory.Delete(sCXFFilePath, true);
            }

            if (cXF.CreateFiles("", CLGType, sTBRN, sCXFFilePath, sLoginName, ref iCXFCreatedItem))
            {
                var sSourcePath = sCXFFilePath;
                var sTargetPath = Path.Combine(CommonFunctions.AppTempPath, "CXF_" + sToday.Replace("/", "") + ".zip");
                if (System.IO.File.Exists(sTargetPath))
                {
                    System.IO.File.Delete(sTargetPath);
                }
                ZipFile.CreateFromDirectory(sSourcePath, sTargetPath);
                return File(sTargetPath, "application/zip", "CXF_" + sToday.Replace("/", "") + ".zip");
                //return Json(new { inStatus = liStatus, stMessage = lsSuccessMessage, stOutFilePath = sTargetPath }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                loCHIGatewayOutwardViewModel.loCXFItemList = GetCXFItemList();
                return RedirectToAction("GETData_CXF_Avl");
                //return View("~/Areas/CHIGatewayOutward/Views/CHIGatewayOutward/AvailCXFcreationList.cshtml", loCHIGatewayOutwardViewModel);
            }
        }
        public ActionResult RES_OACK()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();

            loCHIGatewayOutwardViewModel.loInwardReturnFileReturnFileList = GetInwardReturnFileReturnFileList();

            return View("~/Views/CHIGatewayOutward/InwardReturnFileList.cshtml", loCHIGatewayOutwardViewModel);

        }
        public ActionResult PROCESS_PF_EF_FILE()
        {
            CHIGatewayOutwardViewModel loCHIGatewayOutwardViewModel = new CHIGatewayOutwardViewModel();
            //CHIGatewayOutwardDataContext loCHIGatewayOutwardDataContext = new CHIGatewayOutwardDataContext();

            loCHIGatewayOutwardViewModel.loInwardReturnFileReturnFileList = GetInwardReturnFileReturnFileList();

            return View("~/Views/CHIGatewayOutward/InwardReturnFileList.cshtml", loCHIGatewayOutwardViewModel);

        }

        [HttpPost]
        public ActionResult UploadFiles(IEnumerable<IFormFile> files)
        {
            CXFGenerate cXF = new CXFGenerate();
            string sPath = Path.Combine(CommonFunctions.AppTempPath, "RES_OACK");
            foreach (var file in files)
            {
                if (file != null && file.Length > 0)
                {
                    string sRESFileName = Path.GetFileName(file.FileName);
                    //string filePath = sPath + Path.GetFileName(file.FileName);
                    string extension = Path.GetExtension(file.FileName);
                    if (!Directory.Exists(sPath))
                    {
                        Directory.CreateDirectory(sPath);
                    }
                    //file.SaveAsAsync(filePath);
                    var filePath = Path.Combine(sPath, file.FileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(fileStream);
                    }

                    if (sRESFileName.Contains("RES"))
                        cXF.ProcessRES(sPath, sRESFileName, _DBContext);
                    else if (sRESFileName.Contains("OACK"))
                        cXF.ProcessOACK(sPath, sRESFileName, _DBContext);
                    else if (sRESFileName.Contains("BRF"))
                        cXF.ProcessRF(sPath, sRESFileName, _DBContext);
                }
            }
            return GETData_CXF_Gen();
        }

        public List<CHIGatewayOutwardViewModel.CXFInformation> GetCXFItemList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_CXFInformation.FromSql("USP_CXFAvlsummary".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<CHIGatewayOutwardViewModel.CXFInformation> GetCXFGeneratedStatusList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_CXFInformation.FromSql("USP_CXFFileStatus".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        //public List<CHIGatewayOutwardViewModel.CXFInformation> GetInwardReturnFileDetailsList()
        //{
        //    List<SqlParameter> loSqlParameters = new List<SqlParameter>();

        //    return new CHIGatewayOutwardDataContext().Database.SqlQuery<CHIGatewayOutwardViewModel.CXFInformation>("USP_InwardReturnFileDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        //}
        public List<CHIGatewayOutwardViewModel.InHouseInstrumentsDtl> GetInHouseInstrumentsDetailsList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_InHouseInstrumentsDtl.FromSql("USP_InHouseInstrumentDtl".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }
        public List<CHIGatewayOutwardViewModel.InHouseInstrumentsDtl> GetInHouseInstrumentsDetailsReturnList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_InHouseInstrumentsDtl.FromSql("USP_InHouseInstrumentDtlRet".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<CHIGatewayOutwardViewModel.CXFInformation> GetInwardReturnFileReturnFileList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_CXFInformation.FromSql("USP_InwardReturnFile".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<CHIGatewayOutwardViewModel.CXFInformation> GetSessionDetailsList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_CXFInformation.FromSql("USP_SessionDetails".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<CHIGatewayOutwardViewModel.CXFInformation> GetSessionReturnSessionList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_CXFInformation.FromSql("USP_SessionReturn".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }
    }
}
