﻿using CtsWebCoreOutward.Authorize;
using Microsoft.AspNetCore.Mvc;
using System;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class CaptureController : Controller
    {
        //
        // GET: /Capture/Capture/

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public ActionResult Capture(int? id)
        {
            try
            {
                int iFuntionNumber = 10;
                if (id != null)
                {
                    iFuntionNumber = Convert.ToInt16(id);
                }
                return View();
            }
            catch (Exception)
            {
                return null;

            }
        }
    }
}
