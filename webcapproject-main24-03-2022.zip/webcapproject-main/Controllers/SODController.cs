﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.IO;
using Microsoft.AspNetCore.Mvc;
using CtsWebCoreOutward.ViewModel;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.Authorize;
using System.Data.SqlClient;
using CtsWebCoreOutward.Filter;
using FACoreDAC;
using CtsWebCoreOutward.ComonUtility;
using System.Reflection;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    public class SODController : Controller
    {
        
        SqlConnection conn;
        private readonly SODDataContext _DBContext;
        public SODController(SODDataContext dbContext) { _DBContext = dbContext; }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public ActionResult SOD(int? id)
        {
            return View();
        }

        [HttpPost]
        public ActionResult SubmitSOD(string SODDATE)
        {
            //SODDataContext loSODContext = new SODDataContext();
            var loWrapperSODList = submitSOD(SODDATE);
            //bool lbStatus = loSODContext.submitSOD(SODDATE);
            //((AdminLoginViewModel)Session["WebCTSAdmin"]).sToday = SODDATE;
            return Json(new { msg= loWrapperSODList.Msg, status=loWrapperSODList.Status });//, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Upload(IFormFile postedFile)
        {
            SODViewModel loSODViewModel = new SODViewModel();
            //SODDataContext loSODDataContext = new SODDataContext();

            try
            {
                string filePath = string.Empty;
                string stLoginName = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO").stLoginName;

                if (postedFile != null)
                {
                    string path = Path.Combine(CommonFunctions.AppTempPath, "CHM");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    string sFileName = Path.GetFileName(postedFile.FileName);
                    //filePath = path + Path.GetFileName(postedFile.FileName);
                    string extension = Path.GetExtension(postedFile.FileName);

                    if (extension.ToUpper() == ".XML" || sFileName.ToUpper().Substring(1, 4) == "CHM_")
                    {
                        //postedFile.SaveAs(filePath);
                        var saveFilePath = Path.Combine(path, postedFile.FileName);
                        using (var fileStream = new FileStream(saveFilePath, FileMode.Create))
                        {
                            postedFile.CopyTo(fileStream);
                        }
                        
                        ProcessCHMFile(saveFilePath);
                    }
                }

                //loSODViewModel.SODDate = ((AdminLoginViewModel)Session["WebCTSAdmin"]).sToday;
                return View("SOD", loSODViewModel);

            }
            catch (Exception)
            {
                //loSODViewModel.SODDate = ((AdminLoginViewModel)Session["WebCTSAdmin"]).sToday;
                return View("SOD", loSODViewModel);
            }
        }

        private void ProcessCHMFile(string sFileNameWithPath)
        {
            DataSet dsCHMFile = GetDataSetFromXML(sFileNameWithPath);
            foreach (DataTable dtCHM in dsCHMFile.Tables)
            {
                if (dtCHM.TableName == "CHMaster" || dtCHM.TableName == "CHMasterHeader" || dtCHM.TableName == "CHMasterBody" || dtCHM.TableName == "ClearingHouse" || dtCHM.TableName == "ClearingHouseInterface")
                {
                    continue;
                }
                //rValue.Tables.Add(
                UploadToMasterTable(dtCHM);
            }

        }
        public DataSet GetDataSetFromXML(string XmlFilePath)
        {
            DataSet ds = new DataSet();
            ds.ReadXml(XmlFilePath);
            return ds;
        }
        private DataTable UploadToMasterTable(System.Data.DataTable tblTableName)
        {
            DataTable tblReturnValue = tblTableName.Clone();
            //SODDataContext loSODDataContext = new SODDataContext();

            //  DB = new DALAccess();
            _DBContext.Database.ExecuteSqlCommand("Truncate Table " + tblTableName.TableName, "TRUNCATE" + tblTableName.TableName);
            tblReturnValue.TableName = tblTableName.TableName;
            var strColDef = string.Empty;
            var strValueDef = string.Empty;
            try
            {
                strColDef = "Insert Into " + tblTableName.ToString() + "(";

                // Creating Insert Statement
                for (int y = 0; y < tblTableName.Columns.Count; y++)
                {
                    if (y == tblTableName.Columns.Count - 1)
                    {
                        strColDef += tblTableName.Columns[y].Caption + ") Values (";
                        strValueDef += "@" + tblTableName.Columns[y].Caption + ") ";
                    }
                    else
                    {
                        strColDef += tblTableName.Columns[y].Caption + ",";
                        strValueDef += "@" + tblTableName.Columns[y].Caption + ",";
                    }
                }

                // Setting Table / Column Values to Command Parameter;

                for (int z = 0; z < tblTableName.Rows.Count; z++)
                {
                    SqlConnection Con = new SqlConnection(CommonFunctions.ConStr);
                    System.Data.SqlClient.SqlCommand sCmd = new System.Data.SqlClient.SqlCommand();
                    sCmd.Connection = Con;
                    sCmd.CommandText = strColDef + strValueDef;

                    for (int y = 0; y < tblTableName.Columns.Count; y++)
                    {
                        if (tblTableName.Columns[y].Caption.ToLower().Contains("date"))
                        {
                            if (Convert.ToString(tblTableName.Rows[z][y]).Length != 8)
                            {
                                sCmd.Parameters.AddWithValue(tblTableName.Columns[y].Caption, DateTime.MaxValue);
                            }
                            else
                            {
                                string day = Convert.ToString(tblTableName.Rows[z][y]).Substring(0, 2);
                                string Month = Convert.ToString(tblTableName.Rows[z][y]).Substring(2, 2);
                                string Year = Convert.ToString(tblTableName.Rows[z][y]).Substring(4, 4);
                                sCmd.Parameters.AddWithValue(tblTableName.Columns[y].Caption, Convert.ToDateTime(Year + "-" + Month + "-" + day));
                            }
                        }
                        else
                        {
                            sCmd.Parameters.AddWithValue(tblTableName.Columns[y].Caption, Convert.ToString(tblTableName.Rows[z][y]));
                        }
                    }
                    Con.Open();
                    var recordaffected = sCmd.ExecuteNonQuery();
                    if (recordaffected == 0)
                    {
                        tblReturnValue.Rows.Add(tblTableName.Rows[z]);
                    }
                    sCmd.Parameters.Clear();
                    sCmd = null;
                    Con.Close();
                }
            }
            catch (Exception ex)
            {
                //objLogClient.AddExceptionToLog("MasterSyncronizer", "RBIMasterFileUpload", MethodBase.GetCurrentMethod().Name, ex.Message);
                //objLogClient = null;
            }
            return tblReturnValue;
        }

        public SODViewModel.WrapperSOD submitSOD(string SOD_Date)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("SODDate", SOD_Date.handleDBNull()));

            return _DBContext.DBSet_SODViewModel.FromSql("Proc_SOD".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();

        }

        public DataTable GetDataTableFromSqlStrTbl(string sSql, string sFunctionName4Log)
        {
            conn = _DBContext.Database.GetDbConnection() as SqlConnection;
            conn.Open();

            DataTable tmp = new DataTable();
            try
            {
                using (SqlDataAdapter a = new SqlDataAdapter(sSql, conn))
                {
                    a.Fill(tmp);
                    return tmp;
                }
            }
            catch (Exception ex)
            {
                return tmp;
            }
            finally
            {
                conn.Close();
            }
        }

        public int ExecuteNonQueryStr(string sSql, string sFunctionName4Log)
        {
            conn = this._DBContext.Database.GetDbConnection() as SqlConnection;
            conn.Open();
            try
            {
                using (SqlCommand command = new SqlCommand(sSql, conn))
                {
                    return command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                //WriteLog(sError + sFunctionName4Log + " Error " + ex.Message);
                return -1;
            }
            finally
            {
                conn.Close();
            }
        }

        public int ExecuteNonQuery(SqlCommand cmd)
        {
            int iCntAffectedRows = 0;
            conn = this._DBContext.Database.GetDbConnection() as SqlConnection;
            conn.Open();
            try
            {
                cmd.Connection = conn;
                // sqlOpen();
                iCntAffectedRows = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //throw odbe;
            }
            finally
            {
                conn.Close();
            }
            return iCntAffectedRows;
        }
    }
}
