﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CtsWebCoreOutward.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace CtsWebCoreOutward
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });

            /* Database Setiings */
            services.AddDbContext<SODDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<LoginDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<DataEntryDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<BatchBalancingDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<UserGroupManagerDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<StatusViewerDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<GLAUserManagerDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<CHIGatewayOutwardDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<DownloadFileDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<ReportsDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));
            services.AddDbContext<ScannerInfoDataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("MsSqlConStr")));

            /* Session Settings */
            services.AddSession(options => { options.IdleTimeout = TimeSpan.FromMinutes(20); });
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseHttpsRedirection();
            app.UseSession();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Login}/{action=dologin}/{id?}");
            });
        }
    }
}
