﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CtsWebCoreOutward.Filter
{
    public static class Helper
    {
        /// </summary>
        /// <param name="foValue">object which may have DBNUll</param>  
        public static object handleDBNull(this object foValue)
        {
            if (foValue == null)
            {
                return DBNull.Value;
            }
            return foValue;
        }

        /// <summary>
        /// Generate SQL Statement from all it's parameter and procedure name
        /// </summary>
        /// <param name="foStoreProcedureName">Database procedure name</param> 
        /// <param name="foParameters">List of Sql Parameters</param> 
        public static string getSql(this string foStoreProcedureName, List<SqlParameter> foParameters = null)
        {
            string lsSPParameter = string.Empty;
            if (foParameters != null)
            {
                for (int liIndex = 0; liIndex < foParameters.Count; liIndex++)
                {

                    if (liIndex > 0)
                    {
                        lsSPParameter += ", @" + foParameters[liIndex].ParameterName; ;
                    }
                    else
                    {
                        lsSPParameter += " @" + foParameters[liIndex].ParameterName;
                    }
                    if (foParameters[liIndex].Direction == System.Data.ParameterDirection.Output)
                    {
                        lsSPParameter += " OUT ";
                    }
                }
            }

            return "EXEC [" + foStoreProcedureName + "]" + lsSPParameter;
        }

        /// <summary>
        /// Replacement for Convert.ToInt32 with Null & Empty As 0
        /// </summary>
        /// <param name="fsValue">Source string (can be Null or Empty).</param> 
        public static int toInt(this string fsValue)
        {
            if (string.IsNullOrEmpty(fsValue))
            {
                fsValue = "0";
            }
            return Convert.ToInt32(fsValue);
        }

        /// <summary>
        /// Replacement for Convert.ToString 
        /// </summary>
        /// <param name="fsValue">Source string (can be Null or Empty).</param> 
        public static string toSafeString(this string fsValue)
        {
            if (string.IsNullOrEmpty(fsValue))
            {
                fsValue = "";
            }
            return Convert.ToString(fsValue);
        }

        /// <summary>
        /// Replacement for Convert.ToString 
        /// </summary>
        /// <param name="fsValue">Source string (can be Null or Empty).</param> 
        public static string toSafeTrim(this string fsValue)
        {
            return fsValue.toSafeString().Trim();
        }


        /// <summary>
        /// Replacement for String.Split with null handling
        /// </summary>
        /// <param name="fsValue">Source string (can be Null or Empty).</param> 
        /// <param name="foSeparator">An array of Unicode characters that delimit the substrings in this instance.</param> 
        public static string[] splitNullSafe(this string fsValues, params char[] foSeparator)
        {
            if (fsValues == null)
                return new string[0];

            return fsValues.Split(foSeparator);
        }

        /// <summary>
        /// Trim all the element of string array
        /// </summary> 
        /// <param name="fsValues">An array of string which need to be trimmed</param> 
        public static string[] trimAll(this string[] fsValues)
        {
            for (int i = 0; i < fsValues.Count(); i++)
            {
                fsValues[i] = fsValues[i].Trim();
            }
            return fsValues;
        }

        /// <summary>
        /// Skip null or empty Element from string array
        /// </summary> 
        /// <param name="fsValues">An array of string which need to be skipped for Null Or Empty</param> 
        public static string[] skipNullOrEmpty(this string[] fsValues)
        {
            List<string> loList = fsValues.ToList();
            loList.RemoveAll(str => String.IsNullOrEmpty(str));
            return loList.ToArray();
        }

        /// <summary>
        /// Split with trimmed string array without null or empty element 
        /// </summary> 
        /// <param name="fsValues">An array of string which need to be skipped for Null Or Empty</param> 
        public static string[] splitToTrimmedNonEmptyStringList(this string str, params char[] separators)
        {
            return str.splitNullSafe(separators).trimAll().skipNullOrEmpty();
        }

        /// <summary>
        /// Split with trimmed string array without null or empty element 
        /// </summary> 
        /// <param name="fsValue">Source string (can be Null or Empty).</param> 
        /// <param name="foSeparator">An array of Unicode characters that delimit the substrings in this instance.</param> 
        public static IList<int> splitToInts(this string fsValue, params char[] foSeparator)
        {
            return (from x in fsValue.splitToTrimmedNonEmptyStringList(foSeparator)
                    let id = x.toInt()
                    select id).ToList();
        }

        /// <summary>
        /// Convert to Json Serialized data
        /// </summary> 
        /// <param name="fsValue">Source object.</param> 
        //public static string toJSON(this object foValue)
        //{
        //    JavaScriptSerializer loJavaScriptSerializer = new JavaScriptSerializer();
        //    return loJavaScriptSerializer.Serialize(foValue);
        //}

        /// <summary>
        /// Convert to Json Serialized data with Recursion Limit
        /// </summary> 
        /// <param name="fsValue">Source object.</param> 
        /// <param name="fiRecursionLimit">Recursion Limit</param> 
        //public static string toJSON(this object foValue, int fiRecursionLimit = 0)
        //{
        //    JavaScriptSerializer loJavaScriptSerializer = new JavaScriptSerializer();
        //    loJavaScriptSerializer.RecursionLimit = fiRecursionLimit;
        //    return loJavaScriptSerializer.Serialize(foValue);
        //}

        /// <summary>
        /// Convert to Json Serialized data from List<object>
        /// </summary> 
        /// <param name="fsValue">Source List<object></param>
        //public static string toJSON(List<object> foValue)
        //{
        //    JavaScriptSerializer loJavaScriptSerializer = new JavaScriptSerializer();
        //    return loJavaScriptSerializer.Serialize(foValue);
        //}
    }
}