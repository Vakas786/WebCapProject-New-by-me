﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using CtsWebCoreOutward.ViewModel;
using CtsWebCoreOutward.Filter;
using Microsoft.EntityFrameworkCore;

namespace CtsWebCoreOutward.Models
{
    public class LoginDataContext : DbContext
    {
        public LoginDataContext(DbContextOptions<LoginDataContext> options)
            : base(options)
        { }
        public DbSet<AdminLoginViewModel> DBSet_AdminLoginViewModel { get; set; }
        public DbSet<AdminLoginCheckViewModel> DBSet_AdminLoginCheckViewModel { get; set; }
    }
}