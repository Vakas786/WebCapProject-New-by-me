﻿using CtsWebCoreOutward.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;


namespace CtsWebCoreOutward.Models
{
    public class StatusViewerDataContext : DbContext
    {
        public StatusViewerDataContext(DbContextOptions<StatusViewerDataContext> options)
            : base(options)
        { }
        public DbSet<StatusViewerViewModel.StatusViewerGridColumnsString> DBSet_StatusViewerGridColumnsString { get; set; }
        

    }
}