﻿using System;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using System.Globalization;
using CtsWebCoreOutward.ComonUtility;
using Microsoft.AspNetCore.Mvc;
using FACoreDAC;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Http;
using CtsWebCoreOutward.Authorize;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;
using System.Collections.Generic;
using CtsWebCoreOutward.Filter;
using System.Linq;

namespace CtsWebCoreOutward.Controllers
{
    public class LoginController : Controller
    {
        private readonly LoginDataContext _DBContext;
        public LoginController(LoginDataContext dbContext) { _DBContext = dbContext; }
        //
        // GET: /Login/Login/
        public IActionResult dologin()
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            if (appUserInfo != null)
            {
                return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
            }
            else
            {
                ViewModel.AdminLoginViewModel loAdminLoginViewModel = new ViewModel.AdminLoginViewModel();
                //LoginDataContext loLoginDataContext = new LoginDataContext();
                //loAdminLoginViewModel = loLoginDataContext.GetLogoAndCMPName();
                //loAdminLoginViewModel.logo = Convert.ToBase64String(loAdminLoginViewModel.imglogo);
                ViewData["UserInProgress"] = "0";
                return View(loAdminLoginViewModel);
            }
        }

        [HttpPost]
        public IActionResult dologin(AdminLoginViewModel foAdminLoginViewModel)
        {
            if (foAdminLoginViewModel != null)
            {
                ViewData["UserInProgress"] = "0";

				AdminLoginCheckViewModel foAdminLoginCheckViewModel;
				foAdminLoginCheckViewModel = CheckWorkingUser(foAdminLoginViewModel);
				if (foAdminLoginCheckViewModel != null && foAdminLoginCheckViewModel.stUserName != null)
				{

					ViewData["UserInProgress"] = "1";
					return View(foAdminLoginViewModel);
				}


				string cPwd = foAdminLoginViewModel.stUserPWD;
                foAdminLoginViewModel = authenticateUser(foAdminLoginViewModel);

                if (foAdminLoginViewModel != null && foAdminLoginViewModel.stUserPWD == cPwd)
                {
                    string loginKey = Guid.NewGuid().ToString();
                    MsSQL.ExecuteNonQuery("UPDATE UserInfo SET loginKey='" + loginKey + "', lastTimeActive='" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture) + "' WHERE UserName='" + foAdminLoginViewModel.stUserName + "';", CommonFunctions.ConStr, Path.Combine(CommonFunctions.AppLogPath, MethodBase.GetCurrentMethod().Name));
                    Insert_DeleteLoginUser(foAdminLoginViewModel.stUserName, loginKey, "I");
                    foAdminLoginViewModel.loginKey = loginKey;
                    HttpContext.Session.SetObjectAsJson("LOGIN_USER_INFO", foAdminLoginViewModel);
                    var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");

                    return RedirectToRoute("default", new { controller = "Dashboard", action = "Dashboard" });
                }
                else
                {
                    foAdminLoginViewModel = new ViewModel.AdminLoginViewModel();
                    ModelState.Clear();
                    ViewData["LoginFailed"] = true;
                    return View(foAdminLoginViewModel);
                }
            }
            else
            {
                foAdminLoginViewModel = new ViewModel.AdminLoginViewModel();
                ModelState.Clear();
                ViewData["LoginFailed"] = true;
                return View(foAdminLoginViewModel);
            }
        }
        public ActionResult LogOut(string logout)
        {
            var appUserInfo = HttpContext.Session.GetObjectFromJson<AdminLoginViewModel>("LOGIN_USER_INFO");
            if (logout == "normal")
                MsSQL.ExecuteNonQuery("UPDATE UserInfo SET loginKey=NULL, lastTimeActive='" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture) + "' WHERE UserName='" + appUserInfo.stUserName + "';", CommonFunctions.ConStr, Path.Combine(CommonFunctions.AppLogPath, MethodBase.GetCurrentMethod().Name));
            Insert_DeleteLoginUser(appUserInfo.stUserName, "", "D");
            HttpContext.Session.Remove("LOGIN_USER_INFO");
            return RedirectToRoute("default", new { controller = "Login", action = "dologin" });
        }


        // DataBase Context
        public AdminLoginViewModel authenticateUser(AdminLoginViewModel foAdminLoginViewModel)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stUserName", foAdminLoginViewModel.stUserName.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stUserPWD", foAdminLoginViewModel.stUserPWD.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stLoginOTP", foAdminLoginViewModel.stLoginOTP.handleDBNull()));
            return _DBContext.DBSet_AdminLoginViewModel.FromSql("Proc_UserLogin".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }
        public AdminLoginCheckViewModel CheckWorkingUser(AdminLoginViewModel foAdminLoginViewModel)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stUserName", foAdminLoginViewModel.stUserName.handleDBNull()));
            return _DBContext.DBSet_AdminLoginCheckViewModel.FromSql("Proc_CheckWorkingUser".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }
        public AdminLoginCheckViewModel Insert_DeleteLoginUser(string sUserName, string sLoginkey, string sFlag)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("stUserName", sUserName.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stLoginKey", sLoginkey.handleDBNull()));
            loSqlParameters.Add(new SqlParameter("stFlag", sFlag.handleDBNull()));
            return _DBContext.DBSet_AdminLoginCheckViewModel.FromSql("Proc_DeleteWorkingUser".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }
    }
}