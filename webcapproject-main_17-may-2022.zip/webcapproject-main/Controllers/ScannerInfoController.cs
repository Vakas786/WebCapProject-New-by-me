﻿using CtsWebCoreOutward.Authorize;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;


namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    //[CommonSessionExpireFilterAttribute]
    public class ScannerInfoController : Controller
    {

        private readonly ScannerInfoDataContext _DBContext;
        public ScannerInfoController(ScannerInfoDataContext dbContext) { _DBContext = dbContext; }
        public ActionResult ScannerInfoListMain(int? id)
        {
            try
            {
                ScannerInfoViewModel.AddScannerInfo loAddScannerInfo = new ScannerInfoViewModel.AddScannerInfo();
                loAddScannerInfo.iFuntionNo = id;
                loAddScannerInfo.ScannerInfolList = getScannerList();
                return View(loAddScannerInfo);
            }
            catch (Exception ex)
            {
                return View();
            }

        }

        public ActionResult ScannerInfo(int? id)
        {
            try
            {
                ScannerInfoViewModel.AddScannerInfo loAddScannerInfo = new ScannerInfoViewModel.AddScannerInfo();
                loAddScannerInfo.iFuntionNo = id;
                //loAddScannerInfo.ScannerInfolList = getModuleFunctionList();
                return View(loAddScannerInfo);
            }
            catch (Exception ex)
            {
                return View();
            }

        }

        public ActionResult ScannerInfoEdit(int? id, string SorterID)
        {
            try
            {
                ScannerInfoViewModel.AddScannerInfo loAddScannerInfo = new ScannerInfoViewModel.AddScannerInfo();
                loAddScannerInfo.ScannerInfolList = getScannerInfo_EditById(SorterID);
                loAddScannerInfo.iFuntionNo = id;
                loAddScannerInfo.SorterID = loAddScannerInfo.ScannerInfolList[0].SorterID;
                loAddScannerInfo.SorterNo = loAddScannerInfo.ScannerInfolList[0].SorterNo;
                return View(loAddScannerInfo);
            }
            catch (Exception)
            {
                return View();
            }

        }

        public ActionResult InsertData(string SorterID, string SorterNo)
        {
            ScannerInfoViewModel.AddScannerInfo loScannerInfoViewModel = new ScannerInfoViewModel.AddScannerInfo();
            loScannerInfoViewModel.ScannerInfolList = InsertScannerData(SorterID, SorterNo);
            return View("~/Views/ScannerInfo/ScannerInfoListMain.cshtml", loScannerInfoViewModel);
        }

        public ActionResult UpdateDetail(string sSorterID, string sSorterNo)
        {
            ScannerInfoViewModel.AddScannerInfo loScannerInfoViewModel = new ScannerInfoViewModel.AddScannerInfo();
            loScannerInfoViewModel.ScannerInfolList = UpdateScannerData(sSorterID, sSorterNo);
            return View("~/Views/ScannerInfo/ScannerInfoListMain.cshtml", loScannerInfoViewModel);
        }


        public ActionResult GETData(string sSorterID)
        {
            ScannerInfoViewModel.AddScannerInfo loScannerInfoViewModel = new ScannerInfoViewModel.AddScannerInfo();
            loScannerInfoViewModel.ScannerInfolList = GetScannerInfoData(sSorterID);
            return View("~/Views/ScannerInfo/ScannerInfoList.cshtml", loScannerInfoViewModel);
        }

        public ActionResult DeleteDetailByID(string sSorterID)
        {
            ScannerInfoViewModel.AddScannerInfo loScannerInfoViewModel = new ScannerInfoViewModel.AddScannerInfo();
            loScannerInfoViewModel.ScannerInfolList = DeleteScannerBySorterID(sSorterID);
            loScannerInfoViewModel.ScannerInfolList = getScannerList();
            return View("~/Views/ScannerInfo/ScannerInfoList.cshtml", loScannerInfoViewModel);
        }

        public List<ScannerInfoViewModel.ScannerInfo> DeleteScannerBySorterID(string sSorterID)
        {

            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("sSorterID", sSorterID.handleDBNull()));
            return _DBContext.DBSet_Scanner.FromSql("DeleteScannerInfo".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public ActionResult EditDetailByID(string SorterID)
        {
            ScannerInfoViewModel.AddScannerInfo loScannerInfoViewModel = new ScannerInfoViewModel.AddScannerInfo();
            loScannerInfoViewModel.ScannerInfolList = getScannerInfo_EditById(SorterID);
            return Json(loScannerInfoViewModel.ScannerInfolList);
        }

        public List<ScannerInfoViewModel.ScannerInfo> getScannerList()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            return _DBContext.DBSet_Scanner.FromSql("GetScannerInfoDetail".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<ScannerInfoViewModel.ScannerInfo> getScannerInfo_EditById(string SorterID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("sSorterID", SorterID.handleDBNull()));
            return _DBContext.DBSet_Scanner.FromSql("EditScannerInfoByID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<ScannerInfoViewModel.ScannerInfo> InsertScannerData(string SorterID, string SorterNo)
        {
            try
            {
                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("SorterID", SorterID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("SorterNo", SorterNo.handleDBNull()));

                _DBContext.DBSet_Scanner.FromSql("InsertScannerInfo ".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

                return getScannerInfo_EditById("");


            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<ScannerInfoViewModel.ScannerInfo> UpdateScannerData(string sSorterID, string sSorterNo)
        {
            try
            {
                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("sSorterID", sSorterID.handleDBNull()));
                loSqlParametersDoc.Add(new SqlParameter("sSorterNo", sSorterNo.handleDBNull()));
                return _DBContext.DBSet_Scanner.FromSql("UpdateScannerData".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<ScannerInfoViewModel.ScannerInfo> GetScannerInfoData(string SorterID)
        {
            try
            {
                List<SqlParameter> loSqlParametersDoc = new List<SqlParameter>();
                loSqlParametersDoc.Add(new SqlParameter("SorterID", SorterID.handleDBNull()));
                return _DBContext.DBSet_Scanner.FromSql("GetScannerInfoDetail_Search".getSql(loSqlParametersDoc), loSqlParametersDoc.Cast<object>().ToArray()).ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
