﻿using AspNetCore.Reporting;
using CtsWebCoreOutward.ComonUtility;
using CtsWebCoreOutward.Filter;
using CtsWebCoreOutward.Models;
using CtsWebCoreOutward.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using CtsWebCoreOutward.Authorize;
using System.Drawing;

namespace CtsWebCoreOutward.Controllers
{
    [AuthorizeRole]
    public class ReportsController : Controller
    {
        private SqlConnection conn;
        private readonly ReportsDataContext _DBContext;
        public ReportsController(ReportsDataContext dbContext) { _DBContext = dbContext; }
        //[OutputCacheAttribute(NoStore = true, Duration = 0)]
        public ActionResult Reports(int? id)
        {
            ReportsViewModel.WrapperReports loWrapperReports = new ReportsViewModel.WrapperReports();
            try
            {
                //ReportsDataContext loReportsDataContext = new ReportsDataContext();
                int iFuntionNumber = 100;
                if (id != null)
                {
                    iFuntionNumber = Convert.ToInt16(id);
                }
                loWrapperReports.iFuntionNo = iFuntionNumber;
                //List<ReportsViewModel.ReportDetails> loReportDetailsDBList = new List<ReportsViewModel.ReportDetails>();
                loWrapperReports.loReportsList = getReturnReasonForDropdown();
                return View(loWrapperReports);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public ActionResult GetReport(int? id, string ReportID, string sWhere)
        {
            ViewBag.id = id;
            ViewBag.ReportID = ReportID;
            ViewBag.sWhere = sWhere;

            ReportsViewModel.WrapperReports loWrapperReports = new ReportsViewModel.WrapperReports();
            try
            {

                //Session["ReportID"] = ReportID;
                //Session["WHERE"] = sWhere;

                //ReportsDataContext loReportsDataContext = new ReportsDataContext();
                int iFuntionNumber = 100;
                if (id != null)
                {
                    iFuntionNumber = Convert.ToInt16(id);
                }
                loWrapperReports.iFuntionNo = iFuntionNumber;
                loWrapperReports.iReportId = Convert.ToInt16(ReportID);
                loWrapperReports.sWhere = sWhere;


                List<ReportsViewModel.ReportDetails> loReportDetailsDBList = new List<ReportsViewModel.ReportDetails>();
                loWrapperReports.loReportsList = getReturnReasonForDropdown();

                ReportsViewModel.ReportsGridColumnsString loReportGridColumnsString = new ReportsViewModel.ReportsGridColumnsString();
                loReportGridColumnsString = getReportsGridDisplayColumns(Convert.ToInt32(ReportID));

                loWrapperReports.sReportName = loReportGridColumnsString.ReportName;
                loWrapperReports.sGroupFieldColumns = loReportGridColumnsString.GroupFieldColumns;
                loWrapperReports.sTotalFieldColumns = loReportGridColumnsString.TotalFieldColumns;
                loWrapperReports.RDLCName = loReportGridColumnsString.RDLCName;
                loWrapperReports.IsRDLCRep = loReportGridColumnsString.IsRDLCRep;
                loWrapperReports.sPDFFileName = loReportGridColumnsString.PDFFileName;
                loWrapperReports.FooterTotalFields = loReportGridColumnsString.FooterTotalFields;

                if (loWrapperReports.IsRDLCRep == true)
                {

                    DataTable dt = DT_getReportsList(Convert.ToInt16(ReportID), sWhere);
                    string sFileName = loWrapperReports.sPDFFileName + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".pdf";
                    DataSet dataSet = new DataSet();
                    dataSet.Tables.Add(dt);

                    /* Load report from path */
                    string _ReportPath = Path.Combine(CommonFunctions.AppReportPath, loWrapperReports.RDLCName);
                    LocalReport _ReportViewer = new LocalReport(_ReportPath);
                    
                    /* Assign Data to report */
                    _ReportViewer.AddDataSource("DataSet1", dataSet.Tables[0]);

                    string mimeType = string.Empty;
                    int extension = 1;
                    ReportResult reportResult = _ReportViewer.Execute(RenderType.Pdf, extension, parameters: null, mimeType);
                    byte[] bytes = reportResult.MainStream;

                    /* Download In Browser */
                    return File(bytes, "application/octet-stream", sFileName);
                }

                loWrapperReports.loReportsGridColumnsList = new List<ReportsViewModel.ReportGridColumns>();
                string[] lsGridColumnMainArray = loReportGridColumnsString.ReportsGridDisplayColumns.Split('|');
                foreach (var loData in lsGridColumnMainArray)
                {
                    string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();
                    ReportsViewModel.ReportGridColumns loReportsGridColumns = new ReportsViewModel.ReportGridColumns();
                    loReportsGridColumns.stFieldName = lsGridValues[0];
                    loReportsGridColumns.stWidth = lsGridValues[1];
                    loReportsGridColumns.stDisplayCaption = lsGridValues[2];
                    loWrapperReports.loReportsGridColumnsList.Add(loReportsGridColumns);
                }
                //loWrapperReports.loChequeDetailList = getReportsList(Convert.ToInt16(ReportID), sWhere);
                return View(loWrapperReports);
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public ActionResult getFieldByReportID(Int32 fiReportID)
        {
            // ReportsDataContext loReportsDataContext = new ReportsDataContext();
            List<ReportsViewModel.ReportCriteria> loReportCriteria_List = getReportCriteria(fiReportID);
            return Json(new { loReportCriteria_List });
        }

        //public void GetExcel()
        //{
        //    try
        //    {
        //        if (Session["WebCTSAdmin"] == null)
        //        {

        //            RedirectToRoute("Login", new { controller = "Login", action = "LogOut" });
        //        }
        //        string ReportID = Session["ReportID"].ToString();
        //        string sWhere = Session["WHERE"].ToString();

        //        DateTime dtime = DateTime.Now;
        //        string sGroupValue = string.Empty;
        //        double dTotal = 0;
        //        int iTotalColPos = 0;
        //        ReportsDataContext loReportsDataContext = new ReportsDataContext();
        //        List<ReportsViewModel.ReportDetails> loReportDetailsDBList = new List<ReportsViewModel.ReportDetails>();
        //        ReportsViewModel.WrapperReports loWrapperReports = new ReportsViewModel.WrapperReports();
        //        ReportsViewModel.ReportsGridColumnsString loReportGridColumnsString = new ReportsViewModel.ReportsGridColumnsString();


        //        loReportGridColumnsString = loReportsDataContext.getReportsGridDisplayColumns(Convert.ToInt32(ReportID));
        //        loWrapperReports.sReportName = loReportGridColumnsString.ReportName;
        //        loWrapperReports.sReportPath = loReportGridColumnsString.ReportPath;
        //        loWrapperReports.sPDFFileName = loReportGridColumnsString.PDFFileName;
        //        loWrapperReports.sGroupFieldColumns = loReportGridColumnsString.GroupFieldColumns;
        //        loWrapperReports.sTotalFieldColumns = loReportGridColumnsString.TotalFieldColumns;

        //        loWrapperReports.loReportsGridColumnsList = new List<ReportsViewModel.ReportGridColumns>();
        //        string[] lsGridColumnMainArray = loReportGridColumnsString.ReportsGridDisplayColumns.Split('|');

        //        foreach (var loData in lsGridColumnMainArray)
        //        {
        //            string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();

        //            ReportsViewModel.ReportGridColumns loReportsGridColumns = new ReportsViewModel.ReportGridColumns();
        //            loReportsGridColumns.stFieldName = lsGridValues[0];
        //            loReportsGridColumns.stWidth = lsGridValues[1];
        //            loReportsGridColumns.stDisplayCaption = lsGridValues[2];

        //            loWrapperReports.loReportsGridColumnsList.Add(loReportsGridColumns);
        //        }

        //        loWrapperReports.loChequeDetailList = loReportsDataContext.getReportsList(Convert.ToInt16(ReportID), sWhere);

        //        string sFileName = loWrapperReports.sPDFFileName + dtime.ToString("ddMMyyyyhhmmss") + ".xls";
        //        string spdfPath = loWrapperReports.sReportPath + sFileName;
        //        string sHeader = loWrapperReports.sReportName;

        //        if (!Directory.Exists(loWrapperReports.sReportPath))
        //        {
        //            Directory.CreateDirectory(loWrapperReports.sReportPath);
        //        }


        //        if (loWrapperReports.loChequeDetailList != null && loWrapperReports.loChequeDetailList.Count() > 0)
        //        {
        //            FileStream stream = new FileStream(spdfPath, FileMode.OpenOrCreate);
        //            ExcelWriter writer = new ExcelWriter(stream);
        //            try
        //            {
        //                writer.BeginWrite();
        //                string sColHeader = "";
        //                for (int i = 0; i < lsGridColumnMainArray.Count(); i++)
        //                {
        //                    sColHeader = loWrapperReports.loReportsGridColumnsList[i].stDisplayCaption;
        //                    writer.WriteCell(0, i, Convert.ToString(sColHeader));
        //                    if (loWrapperReports.loReportsGridColumnsList[i].stFieldName == loWrapperReports.sTotalFieldColumns)
        //                    {
        //                        iTotalColPos = i;
        //                    }
        //                }

        //                string colName = "";
        //                string colVal = "";
        //                int row = 0;
        //                foreach (var loData in loWrapperReports.loChequeDetailList)
        //                {
        //                    if (loWrapperReports.sGroupFieldColumns != string.Empty)
        //                    {
        //                        if (sGroupValue != Convert.ToString(loData[loWrapperReports.sGroupFieldColumns]))
        //                        {
        //                            if (dTotal > 0)
        //                            {
        //                                writer.WriteCell(row + 1, iTotalColPos - 1, "TOTAL");
        //                                writer.WriteCell(row + 1, iTotalColPos, dTotal);
        //                                dTotal = 0;
        //                                row++;
        //                            }
        //                            writer.WriteCell(row + 1, 0, loWrapperReports.sGroupFieldColumns + " : " + Convert.ToString(loData[loWrapperReports.sGroupFieldColumns]));
        //                            row++;
        //                        }
        //                    }
        //                    for (int j = 0; j < lsGridColumnMainArray.Count(); j++)
        //                    {
        //                        colName = loWrapperReports.loReportsGridColumnsList[j].stFieldName;
        //                        colVal = Convert.ToString(loData[colName]);
        //                        if (colName.ToUpper() == loWrapperReports.sTotalFieldColumns.ToUpper())
        //                        {
        //                            writer.WriteCell(row + 1, j, Convert.ToDouble(colVal));
        //                        }
        //                        else
        //                        {
        //                            writer.WriteCell(row + 1, j, Convert.ToString(colVal));
        //                        }
        //                    }
        //                    if (loWrapperReports.sTotalFieldColumns != string.Empty)
        //                    {
        //                        dTotal = dTotal + Convert.ToDouble(loData[loWrapperReports.sTotalFieldColumns]);
        //                    }
        //                    if (loWrapperReports.sGroupFieldColumns != string.Empty)
        //                    {
        //                        sGroupValue = Convert.ToString(loData[loWrapperReports.sGroupFieldColumns]);
        //                    }
        //                    row++;
        //                }
        //                if (loWrapperReports.sGroupFieldColumns != string.Empty)
        //                {
        //                    if (dTotal > 0)
        //                    {
        //                        writer.WriteCell(row + 1, iTotalColPos - 1, "TOTAL");
        //                        writer.WriteCell(row + 1, iTotalColPos, dTotal);
        //                        dTotal = 0;
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                writer.EndWrite();
        //                stream.Close();
        //            }
        //            finally
        //            {
        //                writer.EndWrite();
        //                stream.Close();

        //            }

        //            Response.Clear();
        //            Response.ContentType = "application/octet-stream";
        //            Response.AddHeader("Content-Disposition", "attachment; filename=" + sFileName);
        //            Response.WriteFile(spdfPath);
        //            Response.Flush();
        //            Response.End();


        //        }

        //    }
        //    catch (Exception)
        //    {

        //    }


        //}

        #region EXCEL WRITER CLASS
        public class ExcelWriter
        {
            private Stream stream;
            private BinaryWriter writer;

            private ushort[] clBegin = { 0x0809, 8, 0, 0x10, 0, 0 };
            private ushort[] clEnd = { 0x0A, 00 };

            private void WriteUshortArray(ushort[] value)
            {
                for (int i = 0; i < value.Length; i++)
                    writer.Write(value[i]);
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ExcelWriter"/> class.
            /// </summary>
            /// <param name="stream">The stream.</param>
            public ExcelWriter(Stream stream)
            {
                this.stream = stream;
                writer = new BinaryWriter(stream);
            }

            /// <summary>
            /// Writes the text cell value.
            /// </summary>
            /// <param name="row">The row.</param>
            /// <param name="col">The col.</param>
            /// <param name="value">The string value.</param>
            public void WriteCell(int row, int col, string value)
            {
                ushort[] clData = { 0x0204, 0, 0, 0, 0, 0 };
                int iLen = value.Length;
                byte[] plainText = Encoding.ASCII.GetBytes(value);
                clData[1] = (ushort)(8 + iLen);
                clData[2] = (ushort)row;
                clData[3] = (ushort)col;
                clData[5] = (ushort)iLen;
                WriteUshortArray(clData);
                writer.Write(plainText);
            }

            /// <summary>
            /// Writes the integer cell value.
            /// </summary>
            /// <param name="row">The row number.</param>
            /// <param name="col">The column number.</param>
            /// <param name="value">The value.</param>
            public void WriteCell(int row, int col, int value)
            {
                ushort[] clData = { 0x027E, 10, 0, 0, 0 };
                clData[2] = (ushort)row;
                clData[3] = (ushort)col;
                WriteUshortArray(clData);
                int iValue = (value << 2) | 2;
                writer.Write(iValue);
            }

            /// <summary>
            /// Writes the double cell value.
            /// </summary>
            /// <param name="row">The row number.</param>
            /// <param name="col">The column number.</param>
            /// <param name="value">The value.</param>
            public void WriteCell(int row, int col, double value)
            {
                ushort[] clData = { 0x0203, 14, 0, 0, 0 };
                clData[2] = (ushort)row;
                clData[3] = (ushort)col;
                WriteUshortArray(clData);
                writer.Write(value);
            }

            /// <summary>
            /// Writes the empty cell.
            /// </summary>
            /// <param name="row">The row number.</param>
            /// <param name="col">The column number.</param>
            public void WriteCell(int row, int col)
            {
                ushort[] clData = { 0x0201, 6, 0, 0, 0x17 };
                clData[2] = (ushort)row;
                clData[3] = (ushort)col;
                WriteUshortArray(clData);
            }

            /// <summary>
            /// Must be called once for creating XLS file header
            /// </summary>
            public void BeginWrite()
            {
                WriteUshortArray(clBegin);
            }

            /// <summary>
            /// Ends the writing operation, but do not close the stream
            /// </summary>
            public void EndWrite()
            {
                WriteUshortArray(clEnd);
                writer.Flush();
            }
        }
        #endregion

        //public ActionResult loaddata(int iReportId, string sWhere)
        //{
        //    // ReportsDataContext loReportsDataContext = new ReportsDataContext();
        //    ReportsViewModel.WrapperReports loWrapperReportViewer = new ReportsViewModel.WrapperReports();


        //    loWrapperReportViewer.loChequeDetailList = getReportsList(iReportId, sWhere);
        //    var data = loWrapperReportViewer.loChequeDetailList;
        //    return Json(new { data = data });

        //}

        #region PDF Report
        //public ActionResult generateReport(int? id, string ReportID, string sWhere)
        //{
        //    ReportsViewModel.WrapperReports loWrapperReports = new ReportsViewModel.WrapperReports();

        //    string sReportID = Session["ReportID"].ToString();
        //    string sWhereClause = Session["WHERE"].ToString();

        //    if (Session["WebCTSAdmin"] == null)
        //    {
        //        return RedirectToRoute("Login", new { controller = "Login", action = "LogOut" });
        //    }
        //    //Session["ReportID"] = ReportID;
        //    //Session["WHERE"] = sWhere;

        //    ReportsDataContext loReportsDataContext = new ReportsDataContext();
        //    //int iFuntionNumber = 100;
        //    //if (id != null)
        //    //{
        //    //    iFuntionNumber = Convert.ToInt16(id);
        //    //}
        //    //loWrapperReports.iFuntionNo = iFuntionNumber;
        //    loWrapperReports.iReportId = Convert.ToInt16(sReportID);
        //    loWrapperReports.sWhere = sWhere;

        //    List<ReportsViewModel.ReportDetails> loReportDetailsDBList = new List<ReportsViewModel.ReportDetails>();
        //    loWrapperReports.loReportsList = loReportsDataContext.getReturnReasonForDropdown();

        //    ReportsViewModel.ReportsGridColumnsString loReportGridColumnsString = new ReportsViewModel.ReportsGridColumnsString();
        //    loReportGridColumnsString = loReportsDataContext.getReportsGridDisplayColumns(Convert.ToInt32(sReportID));

        //    loWrapperReports.sReportName = loReportGridColumnsString.ReportName;
        //    loWrapperReports.sGroupFieldColumns = loReportGridColumnsString.GroupFieldColumns;
        //    loWrapperReports.sTotalFieldColumns = loReportGridColumnsString.TotalFieldColumns;
        //    loWrapperReports.RDLCName = loReportGridColumnsString.RDLCName;
        //    loWrapperReports.IsRDLCRep = loReportGridColumnsString.IsRDLCRep;
        //    loWrapperReports.sPDFFileName = loReportGridColumnsString.PDFFileName;
        //    loWrapperReports.IsLandscap = loReportGridColumnsString.IsLandscap;
        //    loWrapperReports.FooterTotalFields = loReportGridColumnsString.FooterTotalFields;

        //    if (loWrapperReports.IsRDLCRep == true)
        //    {
        //        Warning[] warnings;
        //        string mimeType;
        //        string[] streamids;
        //        string encoding;
        //        string filenameExtension;
        //        var viewer = new ReportViewer();
        //        DataTable dt = loReportsDataContext.DT_getReportsList(Convert.ToInt16(sReportID), sWhereClause);
        //        viewer.ProcessingMode = ProcessingMode.Local;
        //        //viewer.LocalReport.ReportPath = Server.MapPath("BatchDetail.rdlc");
        //        viewer.LocalReport.ReportPath = @"Reports\" + loWrapperReports.RDLCName;
        //        ReportDataSource datasource = new ReportDataSource("DataSet1", dt);
        //        viewer.LocalReport.DataSources.Clear();
        //        viewer.LocalReport.DataSources.Add(datasource);
        //        viewer.LocalReport.Refresh();
        //        var bytes = viewer.LocalReport.Render("PDF", null, out mimeType, out encoding, out filenameExtension, out streamids, out warnings);
        //        DateTime dtime = DateTime.Now;
        //        string sFileName = loWrapperReports.sPDFFileName + dtime.ToString("ddMMyyyyhhmmss") + ".pdf";
        //        string sFileNameWithPath = Server.MapPath("~/GeneratedFiles/" + sFileName);
        //        FileStream newFile = new FileStream(sFileNameWithPath, FileMode.OpenOrCreate);
        //        newFile.Write(bytes, 0, bytes.Length);
        //        newFile.Close();
        //        Response.Clear();
        //        Response.ContentType = "application/octet-stream";
        //        Response.AddHeader("Content-Disposition", "attachment; filename=" + sFileName);
        //        Response.WriteFile(sFileNameWithPath);
        //        Response.Flush();
        //        Response.End();
        //        return new FileContentResult(bytes, mimeType);
        //    }

        //    loWrapperReports.loReportsGridColumnsList = new List<ReportsViewModel.ReportGridColumns>();
        //    string[] lsGridColumnMainArray = loReportGridColumnsString.ReportsGridDisplayColumns.Split('|');
        //    foreach (var loData in lsGridColumnMainArray)
        //    {
        //        string[] lsGridValues = loData.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries).trimAll();
        //        ReportsViewModel.ReportGridColumns loReportsGridColumns = new ReportsViewModel.ReportGridColumns();
        //        loReportsGridColumns.stFieldName = lsGridValues[0];
        //        loReportsGridColumns.stWidth = lsGridValues[1];
        //        loReportsGridColumns.stDisplayCaption = lsGridValues[2];
        //        loWrapperReports.loReportsGridColumnsList.Add(loReportsGridColumns);
        //    }

        //    loWrapperReports.loChequeDetailList = loReportsDataContext.getReportsList(Convert.ToInt16(sReportID), sWhereClause);

        //    #region generate Report
        //    int liStatus = 0;
        //    bool lbIsPortraitOrientation = loWrapperReports.IsLandscap;
        //    string lsSuccessMessage = string.Empty;
        //    string lsHtmlCode = string.Empty;
        //    string lsViewPagePath = "~/Areas/Reports/Views/Reports/_GetReport.cshtml";
        //    string lsPDFFilePath = ConfigurationManager.AppSettings["ReportFileRootPath"] + "InwardReport/";

        //    #region Get HTML Report
        //    if (loWrapperReports == null || !(loWrapperReports.loChequeDetailList.Count() > 0))
        //        return Json(new { inStatus = liStatus, stMessage = "Report not generated! Please try later.", stOutFilePath = string.Empty, loViewObject = string.Empty }, JsonRequestBehavior.AllowGet);

        //    if (string.IsNullOrEmpty(lsHtmlCode)) //Re-generate HTML
        //    {
        //        ///Render HTML from CSHTML Page
        //        lsHtmlCode = renderRazorViewToString(@lsViewPagePath, loWrapperReports);
        //    }
        //    #endregion

        //    #region Render HTML and Generate PDF
        //    if (!System.IO.Directory.Exists(Server.MapPath(@lsPDFFilePath.Replace(" ", "_"))))
        //        System.IO.Directory.CreateDirectory(Server.MapPath(@lsPDFFilePath.Replace(" ", "_")));

        //    string lsFileTime = DateTime.Now.ToFileTime().ToString();

        //    lsPDFFilePath += lsFileTime + ".pdf";
        //    lsPDFFilePath = lsPDFFilePath.Replace(" ", "_");

        //    ///****** Start Write Temporary HTML File ************
        //    string lsHTMLFooterFilePath = string.Empty;
        //    string lsHTMLFilePath = Server.MapPath(System.IO.Path.GetDirectoryName(lsPDFFilePath)) + "\\" + lsFileTime + ".html";
        //    lsHTMLFilePath = lsHTMLFilePath.Replace(" ", "_");
        //    using (System.IO.FileStream loFileStream = new System.IO.FileStream(lsHTMLFilePath, System.IO.FileMode.Create))
        //    {
        //        using (System.IO.StreamWriter loStreamWriter = new System.IO.StreamWriter(loFileStream, System.Text.Encoding.UTF8))
        //        {
        //            loStreamWriter.WriteLine(lsHtmlCode);
        //            loStreamWriter.Close();
        //            loStreamWriter.Dispose();
        //        }
        //    }
        //    ///******* End Write Temporary HTML File *************

        //    ///get Page Footer
        //    int liIsPDGGenerated = CommonFunctions.generateWkhtmltopdf(lsHTMLFilePath, lsPDFFilePath, lbIsPortraitOrientation, lsHTMLFooterFilePath);

        //    ///****** Start Remove Temporary HTML file ************
        //    CommonFunctions.removeTemporaryHTMlFile((Server.MapPath(System.IO.Path.GetDirectoryName(lsPDFFilePath)) + "\\") + System.IO.Path.GetFileName(lsHTMLFilePath));
        //    CommonFunctions.removeTemporaryHTMlFile(lsHTMLFooterFilePath);  //Remove Footer HTML File
        //    ///****** End Remove Temporary HTML file ************

        //    if (System.IO.File.Exists(Server.MapPath(lsPDFFilePath)))
        //        liStatus = 1;

        //    lsPDFFilePath = CommonFunctions.getApplicationHostURI(Request) + Url.Content(lsPDFFilePath);
        //    #endregion
        //    #endregion
        //    return Json(new { inStatus = liStatus, stMessage = lsSuccessMessage, stOutFilePath = lsPDFFilePath }, JsonRequestBehavior.AllowGet);
        //}

        ///// <summary>
        ///// RenderCSHTML page and get html string
        ///// </summary>
        ///// <param name="fsViewName"> CSHTML Page Name </param>
        ///// <param name="foModelObject"> Model Object </param>
        ///// <returns> HTML String </returns>
        //public string renderRazorViewToString(string fsViewName, object foModelObject)
        //{
        //    ViewData.Model = foModelObject;
        //    using (var loStringWriter = new System.IO.StringWriter())
        //    {
        //        var loViewResult = System.Web.Mvc.ViewEngines.Engines.FindPartialView(ControllerContext, fsViewName);
        //        var loViewContext = new System.Web.Mvc.ViewContext(ControllerContext, loViewResult.View, ViewData, TempData, loStringWriter);
        //        loViewResult.View.Render(loViewContext, loStringWriter);
        //        loViewResult.ViewEngine.ReleaseView(ControllerContext, loViewResult.View);
        //        return loStringWriter.GetStringBuilder().ToString();
        //    }
        //}
        //private void WriteLog(string sLogText)
        //{

        //}
        #endregion

        public List<ReportsViewModel.ReportDetails> getReturnReasonForDropdown()
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();

            return _DBContext.DBSet_ReportDetails.FromSql("getReportDetailsList".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }

        public List<ReportsViewModel.ReportCriteria> getReportCriteria(Int32 fiReportID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("inReportID", fiReportID.handleDBNull()));

            return _DBContext.DBSet_ReportCriteria.FromSql("getReportCriteriaByReportID".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).ToList();
        }
        public ReportsViewModel.ReportsGridColumnsString getReportsGridDisplayColumns(Int32 fiReportID)
        {
            List<SqlParameter> loSqlParameters = new List<SqlParameter>();
            loSqlParameters.Add(new SqlParameter("inReportID", fiReportID.handleDBNull()));
            return _DBContext.DBSet_ReportsGridColumnsString.FromSql("getReportsGridDisplayColumns".getSql(loSqlParameters), loSqlParameters.Cast<object>().ToArray()).FirstOrDefault();
        }

        public IEnumerable<dynamic> getReportsList(int iReportId, string sWhere)
        {
            conn = _DBContext.Database.GetDbConnection() as SqlConnection;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandText = "EXEC USP_GetReportList " + iReportId + "," + "'" + sWhere + "'";
            using (var reader = cmd.ExecuteReader())
            {
                var model = CommonFunctions.getDynamicDataFromDB(reader).ToList();
                return model;
            }
        }

        public DataTable DT_getReportsList(int iReportId, string sWhere)
        {
            try
            {
                conn = _DBContext.Database.GetDbConnection() as SqlConnection;
                conn.Open();
                SqlCommand sCMD = new SqlCommand("EXEC USP_GetReportList " + iReportId + "," + "'" + sWhere + "'", conn);
                SqlDataAdapter ada = new SqlDataAdapter(sCMD);
                DataTable dt = new DataTable();
                ada.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
